"""Людська логіка порядку контуру.

1. Силует: штрихи, що лежать на зовнішній межі фігури, малюються першими одним безперервним обходом
   (старт зверху зліва, далі по найближчому кінцю - перо «обходить» фігуру, а не стрибає).
2. Деталі: внутрішні штрихи групуються за близькістю (око + зіниця + блік = одна група; рот; плями) і малюються
   група за групою у порядку читання (зверху вниз, зліва направо); всередині групи спершу лінії, потім штрихування.
Нічого не відкидається й не змінюється в самих штрихах - лише порядок і напрямок.
"""
import cv2
import numpy as np
from scipy.spatial import cKDTree


def _len(p):
    return float(np.hypot(*np.diff(p, axis=0).T).sum()) if len(p) > 1 else 0.0


def _chain(strokes, start):
    """найближчий сусід від кінчика пера, з розворотом штриха за потреби"""
    rest = list(strokes)
    out, tip = [], np.asarray(start, float)
    while rest:
        best, bi, brev = None, None, False
        for k, s in enumerate(rest):
            a = np.hypot(*(s['pts'][0] - tip))
            b = np.hypot(*(s['pts'][-1] - tip))
            c, rev = (a, False) if a <= b else (b, True)
            if best is None or c < best:
                best, bi, brev = c, k, rev
        s = rest.pop(bi)
        if brev:
            s['pts'] = s['pts'][::-1].copy()
        out.append(s)
        tip = s['pts'][-1]
    return out


def order_human(strokes, ink_mask, ink_width):
    if len(strokes) < 3:
        return list(strokes)
    H, W = ink_mask.shape
    solid = cv2.dilate((ink_mask > 0).astype(np.uint8), np.ones((3, 3), np.uint8))
    n, lab = cv2.connectedComponents((solid == 0).astype(np.uint8), connectivity=4)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    outside = np.isin(lab, list(border))
    dt = cv2.distanceTransform((~outside).astype(np.uint8), cv2.DIST_L2, 3)
    thr = 1.3 * ink_width + 2.0
    outer, inner = [], []
    for s in strokes:
        p = np.rint(s['pts']).astype(int)
        p[:, 0] = np.clip(p[:, 0], 0, W - 1)
        p[:, 1] = np.clip(p[:, 1], 0, H - 1)
        frac = float((dt[p[:, 1], p[:, 0]] <= thr).mean())
        (outer if frac >= 0.6 and s.get('style') != 'hatch' else inner).append(s)
    out = []
    pen = None
    if outer:
        allo = np.vstack([np.asarray(q['pts']) for q in outer])
        c0 = allo.mean(0)

        def ang(q):                                  # кут середини штриха навколо центру: 0 = вгорі, за годинниковою
            m = np.asarray(q['pts'])[len(q['pts']) // 2] - c0
            return float(np.arctan2(m[0], -m[1]) % (2 * np.pi))
        a0 = ang(min(outer, key=lambda q: (np.asarray(q['pts'])[:, 1].min() + 0.35 * np.asarray(q['pts'])[:, 0].mean())))
        seq = sorted(outer, key=lambda q: (ang(q) - a0 + 1e-6) % (2 * np.pi))
        tip = None
        for q in seq:
            if tip is not None and np.hypot(*(q['pts'][-1] - tip)) < np.hypot(*(q['pts'][0] - tip)):
                q['pts'] = q['pts'][::-1].copy()
            tip = q['pts'][-1]
        out += seq
        pen = tip
    if inner:
        # групи за близькістю (single linkage по точках штрихів)
        gap = 3.4 * ink_width
        samp = [np.asarray(s['pts'])[::max(1, int(ink_width))] for s in inner]
        allp = np.vstack(samp)
        owner = np.concatenate([np.full(len(a), k) for k, a in enumerate(samp)])
        parent = list(range(len(inner)))

        def f(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        for i, j in cKDTree(allp).query_pairs(gap):
            a, b = f(int(owner[i])), f(int(owner[j]))
            if a != b:
                parent[a] = b
        groups = {}
        for k, s in enumerate(inner):
            groups.setdefault(f(k), []).append(s)
        allpts = np.vstack([np.asarray(s['pts']) for s in inner])
        y0, y1 = allpts[:, 1].min(), allpts[:, 1].max()
        glist = list(groups.values())
        cen = [np.vstack([np.asarray(q['pts']) for q in g]).mean(0) for g in glist]
        tol = 0.12 * (y1 - y0)                      # групи з близькою висотою = один «рядок» (обидва ока), у рядку - зліва направо
        rows, rid = [], {}
        for k in sorted(range(len(glist)), key=lambda k: cen[k][1]):
            if rows and cen[k][1] - rows[-1][0] <= tol:
                rows[-1][1].append(k)
            else:
                rows.append([cen[k][1], [k]])
            rid[k] = len(rows) - 1
        order_idx = [k for r in rows for k in sorted(r[1], key=lambda k: cen[k][0])]
        for g in [glist[k] for k in order_idx]:
            lines = [s for s in g if s.get('style') != 'hatch']
            hatch = [s for s in g if s.get('style') == 'hatch']
            lines.sort(key=lambda s: -_len(s['pts']))
            first = lines[0] if lines else hatch[0]
            seq = []
            tip = pen if pen is not None else first['pts'][0]
            # групу починаємо з найдовшої лінії (кільце ока), далі найближчі; штрихування (зіниця) - наприкінці групи
            if lines:
                a, b = np.hypot(*(first['pts'][0] - tip)), np.hypot(*(first['pts'][-1] - tip))
                if b < a:
                    first['pts'] = first['pts'][::-1].copy()
                seq.append(first)
                seq += _chain([s for s in lines if s is not first], first['pts'][-1])
            if hatch:
                seq += _chain(hatch, seq[-1]['pts'][-1] if seq else tip)
            out += seq
            pen = seq[-1]['pts'][-1]
    return out
