"""Людська логіка порядку контуру («зростання від намальованого»).

* Штрихи об'єднуються в групи за близькістю (око = кільце + зіниця; метелик; квітка; тулуб з крилами = одна велика група).
* Спершу найбільша група (головна фігура), далі групи, що лежать усередині її силуету (обличчя, деталі) - у порядку
  читання, далі решта окремих предметів - від більших до менших.
* Усередині групи малюємо СУМІЖНО: наступним береться штрих, що торкається вже намальованого; пріоритет -
  силует (зовнішня межа) над внутрішніми лініями, лінії над штрихуванням, далі найближчий до пера.
  Тому перо не «стрибає» по фігурі: контур росте безперервно, як у людини.
Нічого не відкидається й не змінюється в самих штрихах - лише порядок і напрямок.
"""
import cv2
import numpy as np
from scipy.spatial import cKDTree


def _len(p):
    return float(np.hypot(*np.diff(p, axis=0).T).sum()) if len(p) > 1 else 0.0


class _UF:
    def __init__(self, n):
        self.p = list(range(n))

    def f(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def u(self, a, b):
        a, b = self.f(a), self.f(b)
        if a != b:
            self.p[a] = b


def order_human(strokes, ink_mask, ink_width):
    n = len(strokes)
    if n < 3:
        return list(strokes)
    H, W = ink_mask.shape
    # --- зовнішній силует: штрихи біля межі з «зовнішнім» папером ---
    solid = cv2.dilate((ink_mask > 0).astype(np.uint8), np.ones((3, 3), np.uint8))
    nl, lab = cv2.connectedComponents((solid == 0).astype(np.uint8), connectivity=4)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    outside = np.isin(lab, list(border))
    dt = cv2.distanceTransform((~outside).astype(np.uint8), cv2.DIST_L2, 3)
    thr = 1.3 * ink_width + 2.0
    outer = []
    for s in strokes:
        p = np.rint(s['pts']).astype(int)
        p[:, 0] = np.clip(p[:, 0], 0, W - 1)
        p[:, 1] = np.clip(p[:, 1], 0, H - 1)
        outer.append(float((dt[p[:, 1], p[:, 0]] <= thr).mean()) >= 0.6 and s.get('style') != 'hatch')
    # --- суміжність (для зростання) і групи (для послідовності) ---
    step = max(1, int(ink_width // 2))
    samp = [np.asarray(s['pts'])[::step] for s in strokes]
    allp = np.vstack(samp)
    own = np.concatenate([np.full(len(a), k) for k, a in enumerate(samp)])
    tree = cKDTree(allp)
    rj, gap = 1.5 * ink_width + 3.0, 3.4 * ink_width
    adj = [set() for _ in range(n)]
    for i, j in tree.query_pairs(rj):
        a, b = int(own[i]), int(own[j])
        if a != b:
            adj[a].add(b)
            adj[b].add(a)
    uf = _UF(n)
    for i, j in tree.query_pairs(gap):
        uf.u(int(own[i]), int(own[j]))
    groups = {}
    for k in range(n):
        groups.setdefault(uf.f(k), []).append(k)
    glist = list(groups.values())
    glen = [sum(_len(strokes[k]['pts']) for k in g) for g in glist]
    main = int(np.argmax(glen))
    # --- порядок груп ---
    mpts = [np.rint(strokes[k]['pts']).astype(np.int32).reshape(-1, 1, 2) for k in glist[main]]
    lay = np.zeros((H, W), np.uint8)
    cv2.polylines(lay, mpts, False, 255, max(3, int(ink_width)))
    cl = cv2.dilate(lay, np.ones((5, 5), np.uint8))
    nl2, lab2 = cv2.connectedComponents((cl == 0).astype(np.uint8), connectivity=4)
    bd = set(np.unique(np.concatenate([lab2[0], lab2[-1], lab2[:, 0], lab2[:, -1]]))) - {0}
    inside_main = ~np.isin(lab2, list(bd))                       # усередині силуету головної фігури (і сам контур)

    def cen(g):
        return np.vstack([np.asarray(strokes[k]['pts']) for k in g]).mean(0)

    inner_g, other_g = [], []
    for gi, g in enumerate(glist):
        if gi == main:
            continue
        c = cen(g)
        (inner_g if inside_main[int(np.clip(c[1], 0, H - 1)), int(np.clip(c[0], 0, W - 1))] else other_g).append(gi)
    if inner_g:                                                  # читання: рядки зверху вниз, у рядку зліва направо
        ys = [cen(glist[g])[1] for g in inner_g]
        tol = 0.12 * (max(ys) - min(ys) + 1)
        rows = []
        for g in sorted(inner_g, key=lambda g: cen(glist[g])[1]):
            if rows and cen(glist[g])[1] - rows[-1][0] <= tol:
                rows[-1][1].append(g)
            else:
                rows.append([cen(glist[g])[1], [g]])
        inner_g = [g for r in rows for g in sorted(r[1], key=lambda g: cen(glist[g])[0])]
    other_g.sort(key=lambda g: -glen[g])
    order_g = [main] + inner_g + other_g
    # --- зростання всередині групи ---
    out, pen = [], None

    def grow(idx, pen):
        rem = set(idx)
        done = set()
        seq = []
        if pen is None:                                          # старт: силует зверху (трохи лівіше)
            cand = [k for k in rem if outer[k]] or list(rem)
            first = min(cand, key=lambda k: np.asarray(strokes[k]['pts'])[:, 1].min() + 0.05 * np.asarray(strokes[k]['pts'])[:, 0].mean())
            e = np.asarray(strokes[first]['pts'])
            pen = e[np.argmin(e[:, 1] + 0.05 * e[:, 0])]
        while rem:
            att = [k for k in rem if adj[k] & done] if done else []
            pool = att or list(rem)

            def key(k):
                p = strokes[k]['pts']
                d = min(np.hypot(*(p[0] - pen)), np.hypot(*(p[-1] - pen)))
                hatch = strokes[k].get('style') == 'hatch'
                return ((not outer[k]) if att else 0, hatch, d)
            k = min(pool, key=key)
            s = strokes[k]
            if np.hypot(*(s['pts'][-1] - pen)) < np.hypot(*(s['pts'][0] - pen)):
                s['pts'] = s['pts'][::-1].copy()
            seq.append(s)
            rem.discard(k)
            done.add(k)
            pen = s['pts'][-1]
        return seq, pen

    for gi in order_g:
        seq, pen = grow(glist[gi], pen if out else None)
        out += seq
    return _merge_smooth(out, rj)


def _unit(v):
    n = float(np.hypot(*v))
    return v / n if n > 1e-9 else v


def _merge_smooth(seq, rj, max_turn=55.0):
    """Послідовні штрихи, що плавно продовжують один одного (кінець A ≈ початок B, поворот < max_turn), зливаємо в один:
    без стику, де кінець одного штриха «рветься» об початок іншого, і з меншою кількістю відривів руки."""
    out = []
    for s in seq:
        if out and s.get('style') == 'line' and out[-1].get('style') == 'line' and s['kind'] == out[-1]['kind'] \
                and len(s['pts']) > 6 and len(out[-1]['pts']) > 6:
            A, B = np.asarray(out[-1]['pts']), np.asarray(s['pts'])
            g = B[0] - A[-1]
            ka, kb = min(8, len(A) - 1), min(8, len(B) - 1)
            ta, tb = _unit(A[-1] - A[-1 - ka]), _unit(B[kb] - B[0])
            ang = lambda u, v: float(np.degrees(np.arccos(np.clip(np.dot(u, v), -1, 1))))
            if float(np.hypot(*g)) <= rj and ang(ta, tb) < max_turn and (float(np.hypot(*g)) < 2 or ang(ta, _unit(g)) < 70):
                out[-1] = dict(out[-1], pts=np.vstack([A, B]))
                continue
        out.append(s)
    return out
