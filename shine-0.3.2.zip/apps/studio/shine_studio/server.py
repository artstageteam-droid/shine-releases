"""Локальний API (127.0.0.1) + статичний інтерфейс.

Захист: сервер слухає лише localhost; усі /api/* (крім health) вимагають токен запуску
в заголовку X-Shine-Token (токен вбудовується в сторінку), та дозволений Host лише localhost —
це закриває запити з інших вебсторінок і DNS rebinding.
"""
import json
import re
import secrets
from pathlib import Path
import sys
from typing import Optional

from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import __version__, intake, jobs, packs, paths, project, settings
from .updater import UpdateError, Updater

MAX_PACK_UPLOAD = 400 * 1024 * 1024
MAX_UPLOAD = 40 * 1024 * 1024
ALLOWED_HOSTS = {"127.0.0.1", "localhost", "testserver"}


class NewProject(BaseModel):
    name: str
    kind: str = "character"
    request: Optional[dict] = None


class PromptReq(BaseModel):
    kind: str
    subject: str
    count: int = 1
    style: str = "flat sticker"
    palette: str = "bright, saturated, child friendly"
    extra: str = ""
    variants: list[str] = ["base"]


class ImportReq(BaseModel):
    path: str


class RenderReq(BaseModel):
    project: str
    object: str
    quality: str = "preview"
    background: Optional[str] = None


def _promptgen():
    paths.add_engine_to_path()
    import promptgen
    return promptgen


def create_app(token: Optional[str] = None, updater: Optional[Updater] = None) -> FastAPI:
    token = token or secrets.token_urlsafe(24)
    upd = updater or Updater()
    app = FastAPI(title="SHINE Creator Studio", version=__version__, docs_url=None, redoc_url=None)
    app.state.token = token

    @app.middleware("http")
    async def guard(request: Request, call_next):
        host = (request.headers.get("host") or "").split(":")[0]
        if host not in ALLOWED_HOSTS:
            return JSONResponse({"error": "host not allowed"}, status_code=403)
        p = request.url.path
        if p.startswith("/api/") and p != "/api/health":
            tk = request.headers.get("x-shine-token", "")
            if p.startswith("/api/render/") and p.endswith("/video"):      # <video> не вміє слати заголовки
                tk = tk or request.query_params.get("t", "")
            if not secrets.compare_digest(tk, token):
                return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)

    @app.exception_handler(project.ProjectError)
    async def perr(_, e):
        return JSONResponse({"error": str(e)}, status_code=400)

    @app.exception_handler(packs.PackError)
    async def packerr(_, e):
        return JSONResponse({"error": str(e)}, status_code=400)

    @app.exception_handler(jobs.JobError)
    async def joberr(_, e):
        return JSONResponse({"error": str(e)}, status_code=400)

    @app.exception_handler(UpdateError)
    async def uerr(_, e):
        return JSONResponse({"error": str(e)}, status_code=409)

    @app.get("/api/health")
    def health():
        return {"ok": True, "version": __version__}

    @app.get("/api/info")
    def info():
        return {"version": __version__, "home": str(paths.home()), "settings": settings.load()}

    @app.get("/api/selftest")
    def selftest():
        """Діагностика: чи завантажуються бібліотеки й модулі рушія (корисно після встановлення/оновлення)."""
        res = {}
        for m in ("numpy", "scipy", "cv2", "skimage", "PIL"):
            try:
                mod = __import__(m)
                res[m] = getattr(mod, "__version__", "ok")
            except Exception as e:
                res[m] = f"ПОМИЛКА: {e}"
        paths.add_engine_to_path()
        for m in ("sets", "puppet", "promptgen", "planner", "render", "sound2"):
            try:
                __import__(m)
                res["engine." + m] = "ok"
            except Exception as e:
                res["engine." + m] = f"ПОМИЛКА: {e}"
        res["ok"] = all(not str(v).startswith("ПОМИЛКА") for v in res.values())
        return res

    @app.post("/api/settings")
    def set_settings(patch: dict):
        return settings.save(patch)

    @app.get("/api/projects")
    def projects():
        return project.list_projects()

    @app.post("/api/projects")
    def new_project(body: NewProject):
        return project.create(body.name, body.kind, body.request).model_dump()

    @app.get("/api/projects/{pid}")
    def get_project(pid: str):
        return project.load(pid).model_dump()

    @app.post("/api/projects/{pid}/sources")
    async def upload(pid: str, file: UploadFile = File(...)):
        data = await file.read(MAX_UPLOAD + 1)
        if len(data) > MAX_UPLOAD:
            raise HTTPException(413, "Файл завеликий (ліміт 40 МБ)")
        return project.add_source(pid, file.filename or "", data).model_dump()

    @app.post("/api/projects/{pid}/analyze")
    def analyze(pid: str):
        return intake.analyze(pid)

    @app.get("/api/projects/{pid}/files/{sub}/{name}")
    def project_file(pid: str, sub: str, name: str):
        if sub not in ("source", "objects") or "/" in name or "\\" in name or name.startswith("."):
            raise HTTPException(404)
        base = (project.project_path(pid) / sub).resolve()
        f = (base / name).resolve()
        if base not in f.parents or not f.is_file() or f.suffix.lower() != ".png":
            raise HTTPException(404)      # SVG навмисно не віддаємо (недовірений вміст)
        return FileResponse(f, media_type="image/png")

    # ---- ресурси (рука, звуки, фон) ----
    @app.get("/api/packs")
    def packs_status():
        return packs.status()

    @app.get("/api/packs/find")
    def packs_find():
        return {"candidates": packs.find_candidates()}

    @app.post("/api/packs/import")
    def packs_import(body: ImportReq):
        return packs.import_from(body.path)

    @app.post("/api/packs/upload")
    async def packs_upload(files: list[UploadFile] = File(...)):
        """Завантаження ресурсів з браузера: zip (до 400 МБ) або окремі PNG/WAV/JSON. Пишемо у тимчасову папку, далі звичайний імпорт."""
        import shutil
        import tempfile
        tmp = Path(tempfile.mkdtemp(prefix="shine_up_"))
        try:
            total = 0
            for i, f in enumerate(files):
                name = Path(f.filename or f"f{i}").name
                if not re.match(r"^[A-Za-z0-9_. -]{1,120}$", name):
                    name = f"f{i}" + Path(name).suffix.lower()
                dest = tmp / name
                with open(dest, "wb") as out:
                    while True:
                        chunk = await f.read(1 << 20)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_PACK_UPLOAD:
                            raise HTTPException(413, "Завелике (ліміт 400 МБ)")
                        out.write(chunk)
            zips = [p for p in tmp.iterdir() if p.suffix.lower() == ".zip"]
            results = [packs.import_from(str(z)) for z in zips] if zips else [packs.import_from(str(tmp))]
            imported = sorted({x for r in results for x in r["imported"]})
            return dict(imported=imported, status=packs.status())
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @app.post("/api/packs/background")
    async def packs_background(file: UploadFile = File(...)):
        data = await file.read(MAX_UPLOAD + 1)
        if len(data) > MAX_UPLOAD:
            raise HTTPException(413, "Файл завеликий (ліміт 40 МБ)")
        if not (file.filename or "").lower().endswith(".png") or data[:8] != b"\x89PNG\r\n\x1a\n":
            raise HTTPException(400, "Фон має бути PNG")
        name = re.sub(r"[^A-Za-z0-9_.-]+", "_", Path(file.filename).name)[:60] or "bg.png"
        (packs.pack_dir() / "background" / name).write_bytes(data)
        return packs.status()

    # ---- рендер ----
    @app.post("/api/render")
    def render_start(body: RenderReq):
        return jobs.start(body.project, body.object, body.quality, body.background)

    @app.get("/api/render/{jid}")
    def render_get(jid: str):
        return jobs.get(jid)

    @app.post("/api/render/{jid}/cancel")
    def render_cancel(jid: str):
        return jobs.cancel(jid)

    @app.get("/api/render/{jid}/video")
    def render_video(jid: str):
        return FileResponse(jobs.video_path(jid), media_type="video/mp4", filename="SHINE_clip.mp4")

    @app.post("/api/prompt")
    def prompt(body: PromptReq):
        pg = _promptgen()
        try:
            req = pg.make_request(body.kind, body.subject, body.count, body.style, body.palette, body.extra,
                                  tuple(body.variants))
        except ValueError as e:
            raise HTTPException(400, str(e))
        return {"request": req, "chatgpt_text": pg.chatgpt_text(req)}

    @app.get("/api/update/check")
    def update_check():
        return upd.check()

    @app.post("/api/update/download")
    def update_download():
        return upd.download()

    @app.post("/api/update/apply")
    def update_apply():
        upd.apply()
        return {"restarting": True}

    @app.post("/api/update/rollback")
    def update_rollback():
        upd.rollback()
        return {"restarting": True}

    index = (paths.ui_dir() / "index.html").read_text(encoding="utf-8") if (paths.ui_dir() / "index.html").exists() else ""

    @app.get("/", response_class=HTMLResponse)
    def root():
        return index.replace("__SHINE_TOKEN__", token).replace("__SHINE_VERSION__", __version__)

    app.mount("/static", StaticFiles(directory=str(paths.ui_dir())), name="static")
    return app
