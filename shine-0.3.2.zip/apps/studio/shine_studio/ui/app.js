"use strict";
const TOKEN = document.querySelector('meta[name="shine-token"]').content;
const $ = (s, r = document) => r.querySelector(s);
const h = (html) => { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstChild; };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, opts = {}) {
  const o = { method: "GET", headers: {}, ...opts };
  o.headers["X-Shine-Token"] = TOKEN;
  if (o.json !== undefined) { o.body = JSON.stringify(o.json); o.headers["Content-Type"] = "application/json"; o.method = o.method === "GET" ? "POST" : o.method; }
  const r = await fetch(path, o);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || data.detail || "Помилка " + r.status);
  return data;
}

const KINDS = { character: "Один персонаж", set: "Набір персонажів", objects: "Набір предметів (машинки, їжа…)", scene: "Сцена (лише малювання)" };
const view = $("#view");
let current = { request: null };

/* ---------- оновлення ---------- */
async function checkUpdate(manual) {
  const b = $("#banner");
  try {
    const s = await api("/api/update/check");
    if (s.available) {
      b.hidden = false; b.className = "banner";
      b.innerHTML = `<div><b>Є оновлення ${esc(s.version)}</b><div class="note">${esc((s.notes || "").slice(0, 300))}</div></div>
        <div class="row"><button id="upd">Оновити</button><button class="sec" id="later">Пізніше</button></div>`;
      $("#later").onclick = () => (b.hidden = true);
      $("#upd").onclick = async () => {
        $("#upd").disabled = true; $("#upd").textContent = "Завантаження…";
        try { await api("/api/update/download", { method: "POST" }); $("#upd").textContent = "Перезапуск…"; await api("/api/update/apply", { method: "POST" }); }
        catch (e) { b.className = "banner err"; b.innerHTML = esc(e.message); }
      };
    } else if (manual) {
      b.hidden = false; b.className = "banner";
      b.innerHTML = s.installed ? "У вас остання версія." : esc(s.reason || "Оновлення недоступні в цьому режимі запуску.");
    }
  } catch (e) { if (manual) { b.hidden = false; b.className = "banner err"; b.textContent = e.message; } }
}

/* ---------- екрани ---------- */
async function viewProjects() {
  const list = await api("/api/projects");
  view.innerHTML = `<h1>Проєкти</h1><p class="sub">Один проєкт = одне відео (або набір малюнків).</p>
    <div class="card"><div class="row">
      <label>Назва нового проєкту<input id="pname" placeholder="Напр.: Веселі монстрики"></label>
      <label>Тип<select id="pkind">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
      <button id="padd">Створити</button></div><div id="perr" class="bad note"></div></div>
    <div class="card list">${list.length ? list.map((p) => `<div class="item"><div><a href="#/project/${esc(p.id)}">${esc(p.name)}</a><span class="tag">${esc(KINDS[p.kind] || p.kind)}</span></div><span class="note">малюнків: ${p.sources}</span></div>`).join("") : `<div class="empty">Проєктів ще немає. Створіть перший.</div>`}</div>`;
  $("#padd").onclick = async () => {
    try { const p = await api("/api/projects", { json: { name: $("#pname").value, kind: $("#pkind").value, request: current.request } }); current.request = null; location.hash = "#/project/" + p.id; }
    catch (e) { $("#perr").textContent = e.message; }
  };
}

const blobCache = new Map();
async function imgUrl(path) {
  if (blobCache.has(path)) return blobCache.get(path);
  const r = await fetch(path, { headers: { "X-Shine-Token": TOKEN } });
  if (!r.ok) return "";
  const u = URL.createObjectURL(await r.blob());
  blobCache.set(path, u);
  return u;
}
async function fillImgs(root) {
  for (const im of root.querySelectorAll("img[data-src]")) { im.src = await imgUrl(im.dataset.src); }
}

function objCard(pid, o) {
  const real = o.kind === "object";
  const badge = !real ? `<span class="tag">деталь</span>` : o.plan.blink ? `<span class="tag ok">оживлення: так</span>` : `<span class="tag warn">лише малювання</span>`;
  return `<div class="obj"><img data-src="/api/projects/${encodeURIComponent(pid)}/files/objects/${encodeURIComponent(o.id)}.png" alt="${esc(o.id)}">
    <div><b>${esc(o.id)}</b> ${badge}</div><div class="note">${esc(o.plan.reason)}</div>${real ? `<button class="sec" data-draw="${esc(o.id)}" style="margin-top:8px">Намалювати</button>` : ""}</div>`;
}

async function viewProject(pid) {
  const p = await api("/api/projects/" + encodeURIComponent(pid));
  const exp = p.request ? p.request.count : null;
  const analyzed = p.objects.length > 0;
  const real = p.objects.filter((o) => o.kind === "object");
  view.innerHTML = `<h1>${esc(p.name)}</h1><p class="sub">${esc(KINDS[p.kind] || p.kind)}${exp ? " · очікується об'єктів: " + exp : ""}</p>
    <div class="card"><div class="drop" id="drop">Перетягніть сюди PNG (або SVG) чи <button class="sec" id="pick">оберіть файл</button><input id="file" type="file" accept=".png,.svg" hidden multiple></div>
      <div id="uerr" class="bad note"></div>
      <div class="thumbs">${p.sources.map((s) => `<div><b>${esc(s.id)}</b> · ${esc(s.file)}${s.file.endsWith(".png") ? `<br><img data-src="/api/projects/${encodeURIComponent(pid)}/files/source/${encodeURIComponent(s.id)}.png" alt="">` : ""}</div>`).join("")}</div>
      ${p.sources.length ? `<div class="row" style="margin-top:14px"><button id="an">${analyzed ? "Проаналізувати знову" : "Проаналізувати"}</button><span id="anst" class="note"></span></div>` : ""}</div>
    <div id="res"></div>`;
  const up = async (files) => { for (const f of files) { const fd = new FormData(); fd.append("file", f); try { await api(`/api/projects/${encodeURIComponent(pid)}/sources`, { method: "POST", body: fd }); } catch (e) { $("#uerr").textContent = e.message; return; } } viewProject(pid); };
  $("#pick").onclick = () => $("#file").click(); $("#file").onchange = (e) => up(e.target.files);
  const d = $("#drop"); d.ondragover = (e) => { e.preventDefault(); d.classList.add("over"); }; d.ondragleave = () => d.classList.remove("over");
  d.ondrop = (e) => { e.preventDefault(); d.classList.remove("over"); up(e.dataTransfer.files); };

  const showResult = (objects, plan, reports) => {
    const rs = $("#res"); const rp = objects.filter((o) => o.kind === "object");
    const advice = (reports || []).flatMap((r) => r.error ? [`${r.source}: ${r.error}`] : ((r.check && r.check.advice) || []).map((t) => `${r.source}: ${t}`));
    rs.innerHTML = `<div class="card"><h3 style="margin-top:0">Результат аналізу</h3>
      <p>Об'єктів: <b>${plan.objects}</b> · оживлення можливе: <b>${plan.animate}</b> · лише малювання: <b>${plan.draw_only}</b></p>
      ${advice.length ? `<div class="banner err" style="display:block">${advice.map(esc).join("<br>")}</div>` : ""}
      <div class="objs">${objects.map((o) => objCard(pid, o)).join("")}</div>
      <p class="note">Оживлення вмикається лише там, де очі знайдені впевнено — щоб не псувати малюнок.</p></div>`;
    fillImgs(rs);
    rs.querySelectorAll("[data-draw]").forEach((b) => (b.onclick = () => drawDialog(pid, b.dataset.draw)));
  };
  fillImgs(view);
  if (analyzed) showResult(p.objects, p.plan, []);
  const an = $("#an");
  if (an) an.onclick = async () => {
    an.disabled = true; $("#anst").textContent = "Аналізую…";
    try { const r = await api(`/api/projects/${encodeURIComponent(pid)}/analyze`, { method: "POST" }); $("#anst").textContent = ""; showResult(r.objects, r.plan, r.reports); }
    catch (e) { $("#anst").textContent = ""; $("#uerr").textContent = e.message; }
    an.disabled = false;
  };
}

async function drawDialog(pid, oid) {
  const pk = await api("/api/packs");
  let box = $("#drawbox");
  if (!box) { box = h(`<div id="drawbox" class="card"></div>`); $("#res").prepend(box); }
  if (!pk.hand || !pk.sound || !pk.ffmpeg) {
    box.innerHTML = `<h3 style="margin-top:0">Для малювання потрібні ресурси</h3><p class="note">${!pk.hand ? "Немає фото-рук. " : ""}${!pk.sound ? "Немає звуків. " : ""}${!pk.ffmpeg ? "Немає ffmpeg (перезапустіть інсталятор). " : ""}</p>
      <a href="#/settings"><button>Завантажити ресурси</button></a>`;
    box.scrollIntoView({ behavior: "smooth" }); return;
  }
  box.innerHTML = `<h3 style="margin-top:0">Намалювати ${esc(oid)}</h3>
    <div class="row"><label>Якість<select id="dq"><option value="preview">Швидкий тест (перші 12 с, ~1 хв)</option><option value="full">Повне відео (кілька хвилин)</option></select></label>
    <label>Фон<select id="dbg"><option value="">Білий аркуш</option>${pk.backgrounds.map((b) => `<option>${esc(b)}</option>`).join("")}</select></label>
    <button id="dgo">Намалювати</button></div><div id="dst" class="note"></div><div id="dvid"></div>`;
  box.scrollIntoView({ behavior: "smooth" });
  $("#dgo").onclick = async () => {
    $("#dgo").disabled = true; $("#dst").textContent = "Запуск…";
    try {
      let j = await api("/api/render", { json: { project: pid, object: oid, quality: $("#dq").value, background: $("#dbg").value || null } });
      while (j.state === "running") {
        const pct = Math.round(j.progress * 100);
        $("#dst").innerHTML = `<div class="bar"><i style="width:${pct}%"></i></div>${pct}%${j.eta ? " · залишилось близько " + (j.eta > 90 ? Math.round(j.eta / 60) + " хв" : j.eta + " с") : ""} <button class="sec" id="dx">Скасувати</button>`;
        $("#dx").onclick = () => api(`/api/render/${j.id}/cancel`, { method: "POST" });
        await new Promise((r) => setTimeout(r, 1500));
        j = await api("/api/render/" + j.id);
      }
      if (j.state === "done") {
        $("#dst").innerHTML = `Готово. ${j.qa ? "Тривалість " + j.qa.duration_s + " с. Безпечність руки: " + (j.qa.unsafe_hand_frames === 0 ? "ок" : j.qa.unsafe_hand_frames + " кадрів поза межами") : ""}`;
        $("#dvid").innerHTML = `<video controls style="width:100%;max-width:720px;margin-top:10px;border-radius:8px" src="/api/render/${j.id}/video?t=${encodeURIComponent(TOKEN)}"></video>
          <div class="note">Файл також лежить у папці проєкту: ${esc(pid)}/renders/</div>`;
      } else if (j.state === "cancelled") $("#dst").textContent = "Скасовано.";
      else $("#dst").innerHTML = `<span class="bad">${esc(j.error || "Помилка")}</span><pre>${esc((j.log || []).slice(-8).join("\n"))}</pre>`;
    } catch (e) { $("#dst").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
    $("#dgo").disabled = false;
  };
}

function viewPrompt() {
  view.innerHTML = `<h1>Prompt Studio</h1><p class="sub">Опишіть, що хочете намалювати. Програма складе точний запит для ChatGPT, щоб малюнки одразу підходили для малювання й оживлення.</p>
    <div class="card"><div class="row">
      <label>Тип<select id="k">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
      <label>Скільки об'єктів<input id="n" type="number" min="1" max="12" value="6"></label></div>
      <div class="row" style="margin-top:12px"><label>Що саме (англійською краще)<input id="s" placeholder="6 cute friendly monsters, each different"></label></div>
      <div class="row" style="margin-top:12px"><label>Палітра<input id="pal" value="bright, saturated, child friendly"></label>
      <label>Додатково<input id="ex" placeholder="необов'язково"></label></div>
      <div class="row" style="margin-top:12px"><label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:8px"><input id="vb" type="checkbox" style="padding:0"> кадр «моргання»</label>
      <label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:8px"><input id="vs" type="checkbox" style="padding:0"> кадр «усмішка»</label></div>
      <div class="row" style="margin-top:14px"><button id="go">Скласти запит</button></div><div id="perr" class="bad note"></div></div>
    <div id="out"></div>`;
  const kind = $("#k"), n = $("#n");
  kind.onchange = () => { n.disabled = kind.value === "character"; if (kind.value === "character") n.value = 1; };
  $("#go").onclick = async () => {
    $("#perr").textContent = "";
    if (!$("#s").value.trim()) { $("#perr").textContent = "Опишіть, що малювати."; return; }
    const variants = ["base"]; if ($("#vb").checked) variants.push("blink"); if ($("#vs").checked) variants.push("smile");
    try {
      const r = await api("/api/prompt", { json: { kind: kind.value, subject: $("#s").value, count: +n.value || 1, palette: $("#pal").value, extra: $("#ex").value, variants } });
      current.request = r.request;
      const fu = (r.request.followups || []).map((f) => `<h3>Додатковий кадр: ${esc(f.name)}</h3><pre>${esc(f.prompt)}</pre><button class="sec" data-c="${esc(f.prompt)}">Скопіювати</button>`).join("");
      $("#out").innerHTML = `<div class="card"><h3 style="margin-top:0">Вставте це в ChatGPT</h3><pre id="txt">${esc(r.chatgpt_text)}</pre>
        <div class="row"><button id="cp">Скопіювати запит</button><button class="sec" id="mk">Створити проєкт із цим запитом</button></div>
        <p class="note">Після відповіді ChatGPT збережіть картинку й завантажте її в проєкт — програма перевірить, чи вона відповідає запиту.</p>${fu}</div>`;
      $("#cp").onclick = async () => { await navigator.clipboard.writeText(r.chatgpt_text); $("#cp").textContent = "Скопійовано"; };
      $("#mk").onclick = () => { location.hash = "#/projects"; };
      document.querySelectorAll("[data-c]").forEach((b) => (b.onclick = async () => { await navigator.clipboard.writeText(b.dataset.c); b.textContent = "Скопійовано"; }));
    } catch (e) { $("#perr").textContent = e.message; }
  };
}

async function viewSettings() {
  const [i, u] = await Promise.all([api("/api/info"), api("/api/update/check")]);
  view.innerHTML = `<h1>Налаштування</h1><p class="sub">Версія ${esc(i.version)} · дані: ${esc(i.home)}</p>
    <div class="card"><h3 style="margin-top:0">Оновлення</h3>
      <p class="note">${u.installed ? (u.error ? esc(u.error) : u.available ? "Є нова версія " + esc(u.version) : "У вас остання версія.") : esc(u.reason || "")}</p>
      <div class="row"><label>Адреса каналу оновлень (необов'язково)<input id="uurl" placeholder="за замовчуванням" value="${esc(i.settings.update_url || "")}"></label>
      <button id="sv">Зберегти</button><button class="sec" id="ck">Перевірити оновлення</button>
      <button class="sec" id="rb" ${u.can_rollback ? "" : "disabled"}>Повернути попередню версію${u.previous ? " (" + esc(u.previous) + ")" : ""}</button></div></div>`;
  const pk = await api("/api/packs");
  const ok = (v) => (v ? `<span class="tag ok">є</span>` : `<span class="tag warn">немає</span>`);
  view.appendChild(h(`<div class="card"><h3 style="margin-top:0">Ресурси для малювання</h3>
    <p>Фото-рука ${ok(pk.hand)} · Звуки ${ok(pk.sound)} · ffmpeg ${ok(pk.ffmpeg)} · Фони: ${pk.backgrounds.length ? esc(pk.backgrounds.join(", ")) : "немає"}</p>
    <p class="note">Рука й звуки беруться з вашого архіву (наприклад, SHINE_Dragon_Pilot_v21….zip) і зберігаються лише на цьому комп'ютері.</p>
    <div class="row"><label>Шлях до архіву або папки<input id="ipath" placeholder="G:\\SHINE DRAWING\\SHINE_Dragon_Pilot_v21_Reproducible_2026-11-10.zip"></label>
    <button id="iimp">Імпортувати</button><button class="sec" id="ifind">Знайти автоматично</button></div>
    <div id="ires" class="note"></div>
    <div class="drop" id="pdrop" style="margin-top:12px;padding:18px">Або перетягніть сюди архів <b>.zip</b> (Dragon Pilot…) чи окремі файли: <b>overhead_*.png</b>, <b>assets.json</b>, <b>marker_active_passes.wav</b>, <b>scribbling_continuous.wav</b>
      <button class="sec" id="ppick">оберіть файли</button><input id="pfile" type="file" accept=".zip,.png,.wav,.json" multiple hidden></div>
    <div class="row" style="margin-top:12px"><label>Додати фон-стіл (PNG)<input id="bgf" type="file" accept=".png"></label></div></div>`));
  $("#ifind").onclick = async () => { $("#ires").textContent = "Шукаю…"; const r = await api("/api/packs/find"); $("#ires").innerHTML = r.candidates.length ? "Знайдено (натисніть, щоб підставити):<br>" + r.candidates.map((c) => `<a href="#" data-p="${esc(c)}">${esc(c)}</a>`).join("<br>") : "Нічого не знайдено — вкажіть шлях вручну."; $("#ires").querySelectorAll("[data-p]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); $("#ipath").value = a.dataset.p; })); };
  $("#iimp").onclick = async () => { $("#ires").textContent = "Імпортую…"; try { const r = await api("/api/packs/import", { json: { path: $("#ipath").value } }); $("#ires").textContent = "Імпортовано: " + r.imported.join(", "); setTimeout(viewSettings, 800); } catch (e) { $("#ires").innerHTML = `<span class="bad">${esc(e.message)}</span>`; } };
  const upPack = async (files) => { $("#ires").textContent = "Завантажую (великий архів може зайняти хвилину)…"; const fd = new FormData(); for (const f of files) fd.append("files", f);
    try { const r = await api("/api/packs/upload", { method: "POST", body: fd }); $("#ires").textContent = "Імпортовано: " + r.imported.join(", "); setTimeout(viewSettings, 800); } catch (e) { $("#ires").innerHTML = `<span class="bad">${esc(e.message)}</span>`; } };
  $("#ppick").onclick = () => $("#pfile").click(); $("#pfile").onchange = (e) => upPack(e.target.files);
  const pd = $("#pdrop"); pd.ondragover = (e) => { e.preventDefault(); pd.classList.add("over"); }; pd.ondragleave = () => pd.classList.remove("over");
  pd.ondrop = (e) => { e.preventDefault(); pd.classList.remove("over"); upPack(e.dataTransfer.files); };
  $("#bgf").onchange = async (e) => { const fd = new FormData(); fd.append("file", e.target.files[0]); try { await api("/api/packs/background", { method: "POST", body: fd }); viewSettings(); } catch (er) { $("#ires").innerHTML = `<span class="bad">${esc(er.message)}</span>`; } };
  $("#sv").onclick = async () => { await api("/api/settings", { json: { update_url: $("#uurl").value.trim() } }); $("#sv").textContent = "Збережено"; };
  $("#ck").onclick = () => checkUpdate(true);
  $("#rb").onclick = async () => { if (!confirm("Повернутись до попередньої версії? Програма перезапуститься. Проєкти не зачіпаються.")) return; try { await api("/api/update/rollback", { method: "POST" }); $("#rb").textContent = "Перезапуск…"; } catch (e) { alert(e.message); } };
}

/* ---------- маршрутизація ---------- */
async function route() {
  const hash = location.hash || "#/projects";
  const [, r, arg] = hash.split("/");
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("on", a.dataset.r === (r === "project" ? "projects" : r)));
  try {
    if (r === "project") await viewProject(decodeURIComponent(arg));
    else if (r === "prompt") viewPrompt();
    else if (r === "settings") await viewSettings();
    else await viewProjects();
  } catch (e) { view.innerHTML = `<div class="card bad">${esc(e.message)}</div>`; }
}
window.addEventListener("hashchange", route);
route(); checkUpdate(false);
