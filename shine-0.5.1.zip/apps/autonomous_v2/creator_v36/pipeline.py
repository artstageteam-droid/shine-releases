#!/usr/bin/env python3
"""SHINE Creator v36 - один пайплайн для будь-якого підготовленого SVG:
prepare (ролі) -> semantic clusters -> натуральний план штрихів -> рука/звук/маркери -> mp4 + QA.

usage: pipeline.py <svg> <out_dir> --assets <overhead_assets_dir> --audio <dir with original wavs>
                   [--cluster c01,c02 | all] [--box x0,y0,x1,y1] [--pace 1.0] [--ink 5] [--color 24] [--plan-only]
Приватні ассети (рука PNG, WAV) не входять у репозиторій і передаються аргументами.
"""
import argparse, json, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent / 'prepare_v36')]
import planner as pl, svg_prepare as sp, render as rd   # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('svg'); ap.add_argument('out')
    ap.add_argument('--assets'); ap.add_argument('--audio')
    ap.add_argument('--cluster', default='all'); ap.add_argument('--box', default=None)
    ap.add_argument('--pace', type=float, default=1.0); ap.add_argument('--ink', type=int, default=None)
    ap.add_argument('--color', type=int, default=24); ap.add_argument('--plan-only', action='store_true')
    ap.add_argument('--bbox', default=None, help='фрагмент: x0,y0,x1,y1 у растрових px вихідного SVG (1600 по довгій стороні)')
    ap.add_argument('--painter', default='source', choices=['source', 'mask'])
    ap.add_argument('--t-start', type=float, default=None); ap.add_argument('--t-end', type=float, default=None)
    ap.add_argument('--hand', default='golden', choices=['golden', 'v2'])
    ap.add_argument('--sound', default='golden', choices=['golden', 'granular', 'procedural'])
    ap.add_argument('--direct', action='store_true', help='об\'єктна режисура контуру')
    ap.add_argument('--style', default=None, choices=['outline_first', 'object_by_object'])
    ap.add_argument('--background', default=None, help='фон-стіл з аркушем (PNG/JPG)')
    ap.add_argument('--direction', default=None, help='direction.json (sidecar)')
    ap.add_argument('--size', default='1280x720', help='розмір кадру WxH (напр. 1920x1080)')
    ap.add_argument('--crf', type=int, default=20); ap.add_argument('--preset', default='veryfast')
    ap.add_argument('--ink-scale', type=float, default=1.0, help='множник ширини пера контуру (ширше перо = менше «пропусків»)')
    ap.add_argument('--alive', type=float, default=0.0, help='секунд оживлення (моргання очей) ПІСЛЯ малювання; 0 = без')
    ap.add_argument('--alive-test', action='store_true', help='рендер лише кінця малювання + оживлення (швидка перевірка)')
    a = ap.parse_args(argv)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    if str(a.svg).lower().endswith('.png'):
        from png_scene import PngScene
        W, H = (int(v) for v in a.size.lower().split('x'))
        f = W / 1280.0
        if a.background and not a.box:
            from background import Background
            box = Background(a.background, W, H).fit_box()
        elif a.box:
            box = tuple(float(v) for v in a.box.split(','))
        else:
            sq = 0.90 * H
            box = ((W - sq) / 2, 0.05 * H, (W + sq) / 2, 0.95 * H)
        sc = PngScene(a.svg, W=W, H=H, target_box=box, k=4)
        return _finish(a, out, sc)
    ann = sp.analyze(a.svg)
    objs = ann['objects'] if a.cluster == 'all' else [o for o in ann['objects'] if o['cluster'] in a.cluster.split(',')]
    members = [m for o in objs for m in o['members']]
    clip = None
    if a.bbox:
        clip = tuple(float(v) for v in a.bbox.split(','))
        x0, y0, x1, y1 = clip
        members = [it['id'] for it in ann['items'] if it['bbox_px'] and it['role'] not in ('paper', 'hidden')
                   and it['bbox_px'][0] <= x1 and it['bbox_px'][2] >= x0 and it['bbox_px'][1] <= y1 and it['bbox_px'][3] >= y0]
    sc = pl.Scene(a.svg, ann, members, target_box=tuple(float(v) for v in (a.box or ('300,50,960,670' if str(a.svg).lower().endswith('.png') else '330,60,1250,660')).split(',')), clip_raster=clip)
    return _finish(a, out, sc)


def _dir(a):
    d = json.load(open(a.direction)) if a.direction else ({} if (a.direct or a.style) else None)
    if d is not None:
        d['style'] = a.style or d.get('style') or 'outline_first'
    return d


def _finish(a, out, sc):
    t = time.time()
    W_scale = sc.W / 1280.0
    ink_w = a.ink
    plan = pl.build_plan(sc, ink_width=ink_w, ink_scale=a.ink_scale, color_width=int(round(a.color * W_scale)), direction=_dir(a), ink_group_order=a.direct)
    cov = pl.coverage_report(sc, plan)
    ev, _, _ = rd.build_timeline(plan, sc.W, a.pace)
    info = dict(strokes=len(plan['strokes']), chapters=len(plan['chapters']), skipped_subvisible=len(plan['skipped']),
                coverage=cov, planned_s=round(ev[-1]['t1'], 1), plan_s=round(time.time() - t, 1))
    print(json.dumps(info))
    pl.save_plan(plan, out / 'plan.json')
    pl.preview(sc, plan, str(out / 'plan_preview.png'))
    if a.plan_only:
        return plan, sc, None
    story = None
    if a.alive and a.alive > 0:
        import puppet
        sec = float(a.alive)
        story = puppet.PuppetShow(cfg=dict(seconds=sec, limbs=False, breathe=None, bounce_end=False, blink=True,
                                           blink_times=[min(0.8, sec / 3), max(1.6, sec * 0.62)]), fps=60)
        if a.alive_test and a.t_start is None:
            a.t_start = max(0.0, info['planned_s'] - 1.5)
    qa, _ = rd.render_video(sc, plan, out, a.assets, a.audio, pace=a.pace, painter_kind=a.painter,
                          t_start=a.t_start, t_end=a.t_end, hand_kind=a.hand, sound_kind=a.sound, background=a.background,
                          story=story, crf=a.crf, preset=a.preset)
    print(json.dumps({k: qa[k] for k in ('duration_s', 'unsafe_hand_frames', 'offscreen_visible_frames',
                                          'tip_anchor_error_max_px', 'final_vs_reference_gt40_ratio')}))
    return plan, sc, qa


if __name__ == '__main__':
    main()
