#!/usr/bin/env python3
"""Painter v2 - прогресивне нанесення маркера зі збереженням вигляду SVG.

Модель (замість «копіювання готових пікселів під маскою»):
  * кожен видимий член має дробове покриття cov_i (надвибірка 4x) -> краї й тонкі лінії виглядають як у SVG;
  * кожен проход пера відкладає `opacity`*форма_пера на «відкритості» rev_i (накопичення 1-(1-r)(1-t)):
    перекриття проходів помітні, як у справжнього маркера; фарба не виходить за межі видимої форми
    (контрольоване обрізання по контуру - це й є «аккуратно розфарбовано»);
  * кадр = білий*(1-Σ cov_i*rev_i) + Σ cov_i*rev_i*колір_i (видимі власники не перетинаються) - лінійне оновлення;
  * маркер певного кольору відкриває тільки членів свого кольору (контур - усі ink-члени того ж кластера;
    заливка - свій регіон + дрібні плями того ж кольору в зоні проходу).
Жодних «чорних контурів на все»: товщина/колір контуру беруться з оригіналу.
"""
import cv2
import numpy as np
from scipy.spatial import cKDTree

from render import Painter as _MaskPainter     # noqa: F401 (резервний, Golden-подібний)


def _rgb(c):
    return np.array([int(x) for x in c[4:-1].split(',')], np.float32)


class Painter2:
    def __init__(self, scene, plan, timings, opacity=0.95, cluster_tol=70, speck_tol=40):
        self.scene, self.plan, self.timings = scene, plan, timings
        self.H, self.W = scene.H, scene.W
        self.opacity = opacity
        self.cov = scene.coverage()
        self.by_id = {s['id']: s for s in plan['strokes']}
        self.done = {}
        self.rev = {i: np.zeros_like(c[4]) for i, c in self.cov.items()}
        self.col = {}
        self.role = {}
        for i, m in enumerate(scene.members):
            self.role[i] = m['role']
            self.col[i] = np.array(m['fill'], np.float32) if m.get('fill') else np.array([0, 0, 0], np.float32)
        self.canvas_f = np.full((self.H, self.W, 3), 255.0, np.float32)   # RGB
        self.cluster_tol, self.speck_tol = cluster_tol, speck_tol
        self.ids = [m['id'] for m in scene.members]
        self.idx = {m['id']: i for i, m in enumerate(scene.members)}
        self.ref_bgr = np.ascontiguousarray(scene.ref[:, :, ::-1])
        self._allowed_cache = {}
        self._build_ink_param()
        self.under = dict(getattr(scene, 'under', {}))              # {дитина: батько}: «підмальовування»
        self.ovr = np.zeros((self.H, self.W), np.float32)            # де дитина вже перекрила підмальовок

    @property
    def canvas(self):                      # BGR uint8, як очікує рендер
        return np.ascontiguousarray(np.clip(self.canvas_f + 0.5, 0, 255).astype(np.uint8)[:, :, ::-1])

    def _allowed(self, s):
        key = s['id']
        if key in self._allowed_cache:
            return self._allowed_cache[key]
        tgt = _rgb(s['fill'])
        if s['kind'] == 'ink':
            al = [i for i in self.cov if self.role[i] in ('ink_rim', 'ink_stroke')
                  and np.abs(self.col[i] - tgt).sum() <= self.cluster_tol]
        else:
            al = []
            own = self.idx.get(s.get('member'))
            if own in self.cov:
                al.append(own)
            al += [i for i in self.cov if self.role[i] == 'speck' and np.abs(self.col[i] - tgt).sum() <= self.speck_tol]
        self._allowed_cache[key] = al
        return al

    def _build_ink_param(self):
        """Контур: кожен піксель чорнила прив'язується до найближчої точки траєкторії (параметр s = довжина дуги) і
        проявляється, коли перо до неї дійшло. Форма = джерело; непройдених пікселів немає за побудовою."""
        self.pix = {}
        self.ptr = {}
        self.orphan_px = 0
        ink_strokes = [s for s in self.plan['strokes'] if s['kind'] == 'ink']
        by_fill = {}
        for s in ink_strokes:
            by_fill.setdefault(s['fill'], []).append(s)
        # локальна півширина лінії: допуск «дотягування» залежить від місця (на стиках і пальцях лінія товща за медіану)
        self._half_tree = None
        if self.plan.get('w_line'):
            try:
                from skimage.morphology import skeletonize
                ink_all = np.zeros((self.H, self.W), bool)
                for i, (cy0, cy1, cx0, cx1, cov) in self.cov.items():
                    if self.role[i] in ('ink_rim', 'ink_stroke'):
                        ink_all[cy0:cy1, cx0:cx1] |= cov > 0.5
                if ink_all.any():
                    dtm = cv2.distanceTransform(ink_all.astype(np.uint8), cv2.DIST_L2, 3)
                    sk_ = skeletonize(ink_all)
                    ys_, xs_ = np.nonzero(sk_)
                    self._half_tree = (cKDTree(np.column_stack((xs_ + 0.5, ys_ + 0.5))), dtm[ys_, xs_])
            except Exception:
                self._half_tree = None
        owner = {}
        for fill, sts in by_fill.items():
            for i in self._allowed(sts[0]):
                owner.setdefault(i, fill)
        for fill, sts in by_fill.items():
            P, S, ID = [], [], []
            for k, s in enumerate(sts):
                tm = self.timings[s['id']]
                P.append(tm.pts)
                S.append(tm.cum)
                ID.append(np.full(len(tm.pts), k))
            P, S, ID = np.vstack(P), np.concatenate(S), np.concatenate(ID)
            tree = cKDTree(P)
            reach = 0.55 * float(np.median([float(x['width']) for x in sts]))     # радіус дотягування пера
            wl = self.plan.get('w_line')
            dmax = None
            if wl:                                  # не ширше за півтовщини ВИМІРЯНОЇ лінії: широке перо не «захоплює» сусідні лінії
                reach = min(reach, max(2.0, 0.42 * float(wl)))
                dmax = max(3.0, 0.72 * float(wl))
            acc = {k: [] for k in range(len(sts))}
            for i, (cy0, cy1, cx0, cx1, cov) in self.cov.items():
                if owner.get(i) != fill:
                    continue
                yy, xx = np.nonzero(cov > 1e-3)
                if len(yy) == 0:
                    continue
                q = np.column_stack((xx + cx0 + 0.5, yy + cy0 + 0.5))
                nn = self._earliest_reach(tree, q, ID, S, reach)
                if dmax is not None:                   # чорнило ДАЛЕКО від будь-якого шляху пера не з'являється «саме»: його малює окремий штрих
                    lim = dmax
                    if self._half_tree is not None:
                        tr_, hw_ = self._half_tree
                        lim = np.maximum(dmax, 1.1 * hw_[tr_.query(q)[1]] + 2.0)
                    lim2 = lim * 0 + 2.5 * (lim if np.isscalar(lim) else (lim - 2.0) / 1.1) + 8.0        # кінчики/кути: ще «біля» шляху
                    far = np.hypot(*(q - P[nn]).T) > lim2
                    self.orphan_px += int(far.sum())
                    if far.any():
                        keep = ~far
                        nn, yy, xx = nn[keep], yy[keep], xx[keep]
                        q = q[keep]
                        if len(nn) == 0:
                            continue
                for k in np.unique(ID[nn]):
                    m = ID[nn] == k
                    acc[int(k)].append((S[nn][m], np.full(m.sum(), i), yy[m], xx[m], cov[yy[m], xx[m]]))
            for k, s in enumerate(sts):
                if not acc[k]:
                    continue
                sv = np.concatenate([a[0] for a in acc[k]]); mi = np.concatenate([a[1] for a in acc[k]])
                ys = np.concatenate([a[2] for a in acc[k]]); xs = np.concatenate([a[3] for a in acc[k]])
                cv = np.concatenate([a[4] for a in acc[k]])
                o = np.argsort(sv, kind='stable')
                self.pix[s['id']] = (sv[o], mi[o], ys[o], xs[o], cv[o])
                self.ptr[s['id']] = 0

    @staticmethod
    def _earliest_reach(tree, q, ID, S, reach):
        """Піксель чорнила проявляється, коли його ВПЕРШЕ досягає перо (будь-яка точка шляху в межах reach), а не коли
        підійде найближча точка (яка може належати штриху, що малюється значно пізніше -> «сходинки» на стиках).
        Якщо жодна точка не в межах reach - береться найближча (повнота зберігається за побудовою)."""
        kq = min(12, len(ID))
        d, nn = tree.query(q, k=kq, distance_upper_bound=reach)
        if kq == 1:
            d, nn = d[:, None], nn[:, None]
        ok = np.isfinite(d)
        order = np.where(ok, ID[np.minimum(nn, len(ID) - 1)] * 1e7 + S[np.minimum(nn, len(ID) - 1)], np.inf)
        best = np.argmin(order, axis=1)
        pick = nn[np.arange(len(q)), best]
        none = ~ok.any(axis=1)
        if none.any():
            _, nearest = tree.query(q[none])
            pick = pick.copy()
            pick[none] = nearest
        return pick

    def _deposit_ink(self, sid, d1):
        sv, mi, ys, xs, cv = self.pix[sid]
        lead = 0.0                      # піксель з'являється, коли перо ДІЙШЛО (круглий фронт радіуса reach, як у справжнього маркера)
        p0 = self.ptr[sid]
        p1 = int(np.searchsorted(sv, d1 + lead, side='right'))
        if p1 <= p0:
            return
        self.ptr[sid] = p1
        sl = slice(p0, p1)
        for i in np.unique(mi[sl]):
            m = mi[sl] == i
            cy0, cy1, cx0, cx1, cov = self.cov[int(i)]
            y, x, c = ys[sl][m], xs[sl][m], cv[sl][m]
            r = self.rev[int(i)]
            new = np.maximum(0.0, self.opacity - r[y, x])
            self.canvas_f[y + cy0, x + cx0] += (c * new)[:, None] * (self.col[int(i)] - 255.0)[None, :]
            r[y, x] = np.maximum(r[y, x], self.opacity)

    def deposit(self, sid, d0, d1):
        if d1 <= d0 + 1e-9:
            return
        s, tm = self.by_id[sid], self.timings[sid]
        if sid in self.pix:
            return self._deposit_ink(sid, d1)
        s, tm = self.by_id[sid], self.timings[sid]
        pts, cum = tm.pts, tm.cum
        i0 = max(0, int(np.searchsorted(cum, d0)) - 1)
        i1 = min(len(pts) - 1, int(np.searchsorted(cum, d1)) + 1)
        sel = pts[i0:i1 + 1]
        w = max(1.0, float(s['width']))
        x0 = int(max(0, np.floor(sel[:, 0].min() - w - 2))); x1 = int(min(self.W, np.ceil(sel[:, 0].max() + w + 3)))
        y0 = int(max(0, np.floor(sel[:, 1].min() - w - 2))); y1 = int(min(self.H, np.ceil(sel[:, 1].max() + w + 3)))
        if x1 <= x0 or y1 <= y0:
            return
        touch = np.zeros((y1 - y0, x1 - x0), np.uint8)
        # 8 бітів субпіксельності для гладких країв тонкого пера
        sh = 4
        pp = np.rint((sel - [x0, y0]) * (1 << sh)).astype(np.int32).reshape(-1, 1, 2)
        th = max(1, int(round(w)))
        if len(pp) == 1:
            cv2.circle(touch, (int(pp[0, 0, 0]) >> sh, int(pp[0, 0, 1]) >> sh), max(1, th // 2), 255, -1, cv2.LINE_AA)
        else:
            cv2.polylines(touch, [pp], False, 255, th, cv2.LINE_AA, shift=sh)
        t = touch.astype(np.float32) * (self.opacity / 255.0)
        for i in self._allowed(s):
            cy0, cy1, cx0, cx1, cov = self.cov[i]
            ay0, ay1, ax0, ax1 = max(cy0, y0), min(cy1, y1), max(cx0, x0), min(cx1, x1)
            if ay1 <= ay0 or ax1 <= ax0:
                continue
            tt = t[ay0 - y0:ay1 - y0, ax0 - x0:ax1 - x0]
            r = self.rev[i][ay0 - cy0:ay1 - cy0, ax0 - cx0:ax1 - cx0]
            c = cov[ay0 - cy0:ay1 - cy0, ax0 - cx0:ax1 - cx0]
            rn = 1.0 - (1.0 - r) * (1.0 - tt)
            da = c * (rn - r)
            sl = (slice(ay0, ay1), slice(ax0, ax1))
            if i in self.under:                                      # накладання поверх підмальовка батька
                af = da / np.maximum(1e-6, 1.0 - c * r)
                cv = self.canvas_f[sl]
                cv += af[:, :, None] * (self.col[i][None, None, :] - cv)
                self.ovr[sl] = np.maximum(self.ovr[sl], c * rn)
            else:
                da = da * (1.0 - self.ovr[sl])                       # не перефарбовувати те, що вже накрито дитиною
                self.canvas_f[sl] += da[:, :, None] * (self.col[i] - 255.0)[None, None, :]
            r[...] = rn

    # --- стан завершення (для QA / ледґера) -------------------------------------------------------
    def reveal_report(self):
        tot = rev = 0.0
        worst = []
        for i, (y0, y1, x0, x1, c) in self.cov.items():
            if self.role[i] in ('paper', 'hidden'):
                continue
            a = float(c.sum())
            b = float((c * self.rev[i]).sum())
            tot += a; rev += b
            if a > 0:
                worst.append((a - b, self.ids[i], self.role[i]))
        worst.sort(reverse=True)
        return dict(revealed=round(rev / max(tot, 1e-9), 4), missing_px=round(tot - rev, 1),
                    worst=[dict(missing_px=round(m, 1), member=n, role=r) for m, n, r in worst[:8]])

    advance = _MaskPainter.advance
