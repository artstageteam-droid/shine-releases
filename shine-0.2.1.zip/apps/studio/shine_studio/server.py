"""Локальний API (127.0.0.1) + статичний інтерфейс.

Захист: сервер слухає лише localhost; усі /api/* (крім health) вимагають токен запуску
в заголовку X-Shine-Token (токен вбудовується в сторінку), та дозволений Host лише localhost —
це закриває запити з інших вебсторінок і DNS rebinding.
"""
import json
import secrets
import sys
from typing import Optional

from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import __version__, intake, paths, project, settings
from .updater import UpdateError, Updater

MAX_UPLOAD = 40 * 1024 * 1024
ALLOWED_HOSTS = {"127.0.0.1", "localhost", "testserver"}


class NewProject(BaseModel):
    name: str
    kind: str = "character"
    request: Optional[dict] = None


class PromptReq(BaseModel):
    kind: str
    subject: str
    count: int = 1
    style: str = "flat sticker"
    palette: str = "bright, saturated, child friendly"
    extra: str = ""
    variants: list[str] = ["base"]


def _promptgen():
    paths.add_engine_to_path()
    import promptgen
    return promptgen


def create_app(token: Optional[str] = None, updater: Optional[Updater] = None) -> FastAPI:
    token = token or secrets.token_urlsafe(24)
    upd = updater or Updater()
    app = FastAPI(title="SHINE Creator Studio", version=__version__, docs_url=None, redoc_url=None)
    app.state.token = token

    @app.middleware("http")
    async def guard(request: Request, call_next):
        host = (request.headers.get("host") or "").split(":")[0]
        if host not in ALLOWED_HOSTS:
            return JSONResponse({"error": "host not allowed"}, status_code=403)
        p = request.url.path
        if p.startswith("/api/") and p != "/api/health":
            if not secrets.compare_digest(request.headers.get("x-shine-token", ""), token):
                return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)

    @app.exception_handler(project.ProjectError)
    async def perr(_, e):
        return JSONResponse({"error": str(e)}, status_code=400)

    @app.exception_handler(UpdateError)
    async def uerr(_, e):
        return JSONResponse({"error": str(e)}, status_code=409)

    @app.get("/api/health")
    def health():
        return {"ok": True, "version": __version__}

    @app.get("/api/info")
    def info():
        return {"version": __version__, "home": str(paths.home()), "settings": settings.load()}

    @app.get("/api/selftest")
    def selftest():
        """Діагностика: чи завантажуються бібліотеки й модулі рушія (корисно після встановлення/оновлення)."""
        res = {}
        for m in ("numpy", "scipy", "cv2", "skimage", "PIL"):
            try:
                mod = __import__(m)
                res[m] = getattr(mod, "__version__", "ok")
            except Exception as e:
                res[m] = f"ПОМИЛКА: {e}"
        paths.add_engine_to_path()
        for m in ("sets", "puppet", "promptgen", "planner", "render", "sound2"):
            try:
                __import__(m)
                res["engine." + m] = "ok"
            except Exception as e:
                res["engine." + m] = f"ПОМИЛКА: {e}"
        res["ok"] = all(not str(v).startswith("ПОМИЛКА") for v in res.values())
        return res

    @app.post("/api/settings")
    def set_settings(patch: dict):
        return settings.save(patch)

    @app.get("/api/projects")
    def projects():
        return project.list_projects()

    @app.post("/api/projects")
    def new_project(body: NewProject):
        return project.create(body.name, body.kind, body.request).model_dump()

    @app.get("/api/projects/{pid}")
    def get_project(pid: str):
        return project.load(pid).model_dump()

    @app.post("/api/projects/{pid}/sources")
    async def upload(pid: str, file: UploadFile = File(...)):
        data = await file.read(MAX_UPLOAD + 1)
        if len(data) > MAX_UPLOAD:
            raise HTTPException(413, "Файл завеликий (ліміт 40 МБ)")
        return project.add_source(pid, file.filename or "", data).model_dump()

    @app.post("/api/projects/{pid}/analyze")
    def analyze(pid: str):
        return intake.analyze(pid)

    @app.get("/api/projects/{pid}/files/{sub}/{name}")
    def project_file(pid: str, sub: str, name: str):
        if sub not in ("source", "objects") or "/" in name or "\\" in name or name.startswith("."):
            raise HTTPException(404)
        base = (project.project_path(pid) / sub).resolve()
        f = (base / name).resolve()
        if base not in f.parents or not f.is_file() or f.suffix.lower() != ".png":
            raise HTTPException(404)      # SVG навмисно не віддаємо (недовірений вміст)
        return FileResponse(f, media_type="image/png")

    @app.post("/api/prompt")
    def prompt(body: PromptReq):
        pg = _promptgen()
        try:
            req = pg.make_request(body.kind, body.subject, body.count, body.style, body.palette, body.extra,
                                  tuple(body.variants))
        except ValueError as e:
            raise HTTPException(400, str(e))
        return {"request": req, "chatgpt_text": pg.chatgpt_text(req)}

    @app.get("/api/update/check")
    def update_check():
        return upd.check()

    @app.post("/api/update/download")
    def update_download():
        return upd.download()

    @app.post("/api/update/apply")
    def update_apply():
        upd.apply()
        return {"restarting": True}

    @app.post("/api/update/rollback")
    def update_rollback():
        upd.rollback()
        return {"restarting": True}

    index = (paths.ui_dir() / "index.html").read_text(encoding="utf-8") if (paths.ui_dir() / "index.html").exists() else ""

    @app.get("/", response_class=HTMLResponse)
    def root():
        return index.replace("__SHINE_TOKEN__", token).replace("__SHINE_VERSION__", __version__)

    app.mount("/static", StaticFiles(directory=str(paths.ui_dir())), name="static")
    return app
