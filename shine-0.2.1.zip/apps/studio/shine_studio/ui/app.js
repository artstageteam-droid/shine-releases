"use strict";
const TOKEN = document.querySelector('meta[name="shine-token"]').content;
const $ = (s, r = document) => r.querySelector(s);
const h = (html) => { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstChild; };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, opts = {}) {
  const o = { method: "GET", headers: {}, ...opts };
  o.headers["X-Shine-Token"] = TOKEN;
  if (o.json !== undefined) { o.body = JSON.stringify(o.json); o.headers["Content-Type"] = "application/json"; o.method = o.method === "GET" ? "POST" : o.method; }
  const r = await fetch(path, o);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || data.detail || "Помилка " + r.status);
  return data;
}

const KINDS = { character: "Один персонаж", set: "Набір персонажів", objects: "Набір предметів (машинки, їжа…)", scene: "Сцена (лише малювання)" };
const view = $("#view");
let current = { request: null };

/* ---------- оновлення ---------- */
async function checkUpdate(manual) {
  const b = $("#banner");
  try {
    const s = await api("/api/update/check");
    if (s.available) {
      b.hidden = false; b.className = "banner";
      b.innerHTML = `<div><b>Є оновлення ${esc(s.version)}</b><div class="note">${esc((s.notes || "").slice(0, 300))}</div></div>
        <div class="row"><button id="upd">Оновити</button><button class="sec" id="later">Пізніше</button></div>`;
      $("#later").onclick = () => (b.hidden = true);
      $("#upd").onclick = async () => {
        $("#upd").disabled = true; $("#upd").textContent = "Завантаження…";
        try { await api("/api/update/download", { method: "POST" }); $("#upd").textContent = "Перезапуск…"; await api("/api/update/apply", { method: "POST" }); }
        catch (e) { b.className = "banner err"; b.innerHTML = esc(e.message); }
      };
    } else if (manual) {
      b.hidden = false; b.className = "banner";
      b.innerHTML = s.installed ? "У вас остання версія." : esc(s.reason || "Оновлення недоступні в цьому режимі запуску.");
    }
  } catch (e) { if (manual) { b.hidden = false; b.className = "banner err"; b.textContent = e.message; } }
}

/* ---------- екрани ---------- */
async function viewProjects() {
  const list = await api("/api/projects");
  view.innerHTML = `<h1>Проєкти</h1><p class="sub">Один проєкт = одне відео (або набір малюнків).</p>
    <div class="card"><div class="row">
      <label>Назва нового проєкту<input id="pname" placeholder="Напр.: Веселі монстрики"></label>
      <label>Тип<select id="pkind">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
      <button id="padd">Створити</button></div><div id="perr" class="bad note"></div></div>
    <div class="card list">${list.length ? list.map((p) => `<div class="item"><div><a href="#/project/${esc(p.id)}">${esc(p.name)}</a><span class="tag">${esc(KINDS[p.kind] || p.kind)}</span></div><span class="note">малюнків: ${p.sources}</span></div>`).join("") : `<div class="empty">Проєктів ще немає. Створіть перший.</div>`}</div>`;
  $("#padd").onclick = async () => {
    try { const p = await api("/api/projects", { json: { name: $("#pname").value, kind: $("#pkind").value, request: current.request } }); current.request = null; location.hash = "#/project/" + p.id; }
    catch (e) { $("#perr").textContent = e.message; }
  };
}

const blobCache = new Map();
async function imgUrl(path) {
  if (blobCache.has(path)) return blobCache.get(path);
  const r = await fetch(path, { headers: { "X-Shine-Token": TOKEN } });
  if (!r.ok) return "";
  const u = URL.createObjectURL(await r.blob());
  blobCache.set(path, u);
  return u;
}
async function fillImgs(root) {
  for (const im of root.querySelectorAll("img[data-src]")) { im.src = await imgUrl(im.dataset.src); }
}

function objCard(pid, o) {
  const real = o.kind === "object";
  const badge = !real ? `<span class="tag">деталь</span>` : o.plan.blink ? `<span class="tag ok">оживлення: так</span>` : `<span class="tag warn">лише малювання</span>`;
  return `<div class="obj"><img data-src="/api/projects/${encodeURIComponent(pid)}/files/objects/${encodeURIComponent(o.id)}.png" alt="${esc(o.id)}">
    <div><b>${esc(o.id)}</b> ${badge}</div><div class="note">${esc(o.plan.reason)}</div></div>`;
}

async function viewProject(pid) {
  const p = await api("/api/projects/" + encodeURIComponent(pid));
  const exp = p.request ? p.request.count : null;
  const analyzed = p.objects.length > 0;
  const real = p.objects.filter((o) => o.kind === "object");
  view.innerHTML = `<h1>${esc(p.name)}</h1><p class="sub">${esc(KINDS[p.kind] || p.kind)}${exp ? " · очікується об'єктів: " + exp : ""}</p>
    <div class="card"><div class="drop" id="drop">Перетягніть сюди PNG (або SVG) чи <button class="sec" id="pick">оберіть файл</button><input id="file" type="file" accept=".png,.svg" hidden multiple></div>
      <div id="uerr" class="bad note"></div>
      <div class="thumbs">${p.sources.map((s) => `<div><b>${esc(s.id)}</b> · ${esc(s.file)}${s.file.endsWith(".png") ? `<br><img data-src="/api/projects/${encodeURIComponent(pid)}/files/source/${encodeURIComponent(s.id)}.png" alt="">` : ""}</div>`).join("")}</div>
      ${p.sources.length ? `<div class="row" style="margin-top:14px"><button id="an">${analyzed ? "Проаналізувати знову" : "Проаналізувати"}</button><span id="anst" class="note"></span></div>` : ""}</div>
    <div id="res"></div>`;
  const up = async (files) => { for (const f of files) { const fd = new FormData(); fd.append("file", f); try { await api(`/api/projects/${encodeURIComponent(pid)}/sources`, { method: "POST", body: fd }); } catch (e) { $("#uerr").textContent = e.message; return; } } viewProject(pid); };
  $("#pick").onclick = () => $("#file").click(); $("#file").onchange = (e) => up(e.target.files);
  const d = $("#drop"); d.ondragover = (e) => { e.preventDefault(); d.classList.add("over"); }; d.ondragleave = () => d.classList.remove("over");
  d.ondrop = (e) => { e.preventDefault(); d.classList.remove("over"); up(e.dataTransfer.files); };

  const showResult = (objects, plan, reports) => {
    const rs = $("#res"); const rp = objects.filter((o) => o.kind === "object");
    const advice = (reports || []).flatMap((r) => r.error ? [`${r.source}: ${r.error}`] : ((r.check && r.check.advice) || []).map((t) => `${r.source}: ${t}`));
    rs.innerHTML = `<div class="card"><h3 style="margin-top:0">Результат аналізу</h3>
      <p>Об'єктів: <b>${plan.objects}</b> · оживлення можливе: <b>${plan.animate}</b> · лише малювання: <b>${plan.draw_only}</b></p>
      ${advice.length ? `<div class="banner err" style="display:block">${advice.map(esc).join("<br>")}</div>` : ""}
      <div class="objs">${objects.map((o) => objCard(pid, o)).join("")}</div>
      <p class="note">Оживлення вмикається лише там, де очі знайдені впевнено — щоб не псувати малюнок.</p></div>`;
    fillImgs(rs);
  };
  fillImgs(view);
  if (analyzed) showResult(p.objects, p.plan, []);
  const an = $("#an");
  if (an) an.onclick = async () => {
    an.disabled = true; $("#anst").textContent = "Аналізую…";
    try { const r = await api(`/api/projects/${encodeURIComponent(pid)}/analyze`, { method: "POST" }); $("#anst").textContent = ""; showResult(r.objects, r.plan, r.reports); }
    catch (e) { $("#anst").textContent = ""; $("#uerr").textContent = e.message; }
    an.disabled = false;
  };
}

function viewPrompt() {
  view.innerHTML = `<h1>Prompt Studio</h1><p class="sub">Опишіть, що хочете намалювати. Програма складе точний запит для ChatGPT, щоб малюнки одразу підходили для малювання й оживлення.</p>
    <div class="card"><div class="row">
      <label>Тип<select id="k">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
      <label>Скільки об'єктів<input id="n" type="number" min="1" max="12" value="6"></label></div>
      <div class="row" style="margin-top:12px"><label>Що саме (англійською краще)<input id="s" placeholder="6 cute friendly monsters, each different"></label></div>
      <div class="row" style="margin-top:12px"><label>Палітра<input id="pal" value="bright, saturated, child friendly"></label>
      <label>Додатково<input id="ex" placeholder="необов'язково"></label></div>
      <div class="row" style="margin-top:12px"><label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:8px"><input id="vb" type="checkbox" style="padding:0"> кадр «моргання»</label>
      <label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:8px"><input id="vs" type="checkbox" style="padding:0"> кадр «усмішка»</label></div>
      <div class="row" style="margin-top:14px"><button id="go">Скласти запит</button></div><div id="perr" class="bad note"></div></div>
    <div id="out"></div>`;
  const kind = $("#k"), n = $("#n");
  kind.onchange = () => { n.disabled = kind.value === "character"; if (kind.value === "character") n.value = 1; };
  $("#go").onclick = async () => {
    $("#perr").textContent = "";
    if (!$("#s").value.trim()) { $("#perr").textContent = "Опишіть, що малювати."; return; }
    const variants = ["base"]; if ($("#vb").checked) variants.push("blink"); if ($("#vs").checked) variants.push("smile");
    try {
      const r = await api("/api/prompt", { json: { kind: kind.value, subject: $("#s").value, count: +n.value || 1, palette: $("#pal").value, extra: $("#ex").value, variants } });
      current.request = r.request;
      const fu = (r.request.followups || []).map((f) => `<h3>Додатковий кадр: ${esc(f.name)}</h3><pre>${esc(f.prompt)}</pre><button class="sec" data-c="${esc(f.prompt)}">Скопіювати</button>`).join("");
      $("#out").innerHTML = `<div class="card"><h3 style="margin-top:0">Вставте це в ChatGPT</h3><pre id="txt">${esc(r.chatgpt_text)}</pre>
        <div class="row"><button id="cp">Скопіювати запит</button><button class="sec" id="mk">Створити проєкт із цим запитом</button></div>
        <p class="note">Після відповіді ChatGPT збережіть картинку й завантажте її в проєкт — програма перевірить, чи вона відповідає запиту.</p>${fu}</div>`;
      $("#cp").onclick = async () => { await navigator.clipboard.writeText(r.chatgpt_text); $("#cp").textContent = "Скопійовано"; };
      $("#mk").onclick = () => { location.hash = "#/projects"; };
      document.querySelectorAll("[data-c]").forEach((b) => (b.onclick = async () => { await navigator.clipboard.writeText(b.dataset.c); b.textContent = "Скопійовано"; }));
    } catch (e) { $("#perr").textContent = e.message; }
  };
}

async function viewSettings() {
  const [i, u] = await Promise.all([api("/api/info"), api("/api/update/check")]);
  view.innerHTML = `<h1>Налаштування</h1><p class="sub">Версія ${esc(i.version)} · дані: ${esc(i.home)}</p>
    <div class="card"><h3 style="margin-top:0">Оновлення</h3>
      <p class="note">${u.installed ? (u.error ? esc(u.error) : u.available ? "Є нова версія " + esc(u.version) : "У вас остання версія.") : esc(u.reason || "")}</p>
      <div class="row"><label>Адреса каналу оновлень (необов'язково)<input id="uurl" placeholder="за замовчуванням" value="${esc(i.settings.update_url || "")}"></label>
      <button id="sv">Зберегти</button><button class="sec" id="ck">Перевірити оновлення</button>
      <button class="sec" id="rb" ${u.can_rollback ? "" : "disabled"}>Повернути попередню версію${u.previous ? " (" + esc(u.previous) + ")" : ""}</button></div></div>`;
  $("#sv").onclick = async () => { await api("/api/settings", { json: { update_url: $("#uurl").value.trim() } }); $("#sv").textContent = "Збережено"; };
  $("#ck").onclick = () => checkUpdate(true);
  $("#rb").onclick = async () => { if (!confirm("Повернутись до попередньої версії? Програма перезапуститься. Проєкти не зачіпаються.")) return; try { await api("/api/update/rollback", { method: "POST" }); $("#rb").textContent = "Перезапуск…"; } catch (e) { alert(e.message); } };
}

/* ---------- маршрутизація ---------- */
async function route() {
  const hash = location.hash || "#/projects";
  const [, r, arg] = hash.split("/");
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("on", a.dataset.r === (r === "project" ? "projects" : r)));
  try {
    if (r === "project") await viewProject(decodeURIComponent(arg));
    else if (r === "prompt") viewPrompt();
    else if (r === "settings") await viewSettings();
    else await viewProjects();
  } catch (e) { view.innerHTML = `<div class="card bad">${esc(e.message)}</div>`; }
}
window.addEventListener("hashchange", route);
route(); checkUpdate(false);
