#!/usr/bin/env python3
"""SHINE Creator renderer v36 - one authoritative 60 fps timeline for ink, hand, marker changes, Foley.

This is the canvas-agnostic port of the golden v9/v13/v20/v21 behaviours:
  * the photographic overhead hand (4 original PNG poses, calibrated nib anchor) - NOT re-drawn;
  * path-directed micro-rotation about the nib (v13), exit/offscreen/return marker change (v9/v20);
  * original recorded Foley, contact-gated: absolutely zero PCM when the pen is not on paper (v6/v21);
  * natural pacing (v3 idea): slower into turns, eased stroke ends, smooth lift between strokes.
Nothing is synthesised: sounds and hand come from the user's original assets given by --assets/--audio.
"""
from __future__ import annotations

import bisect
import collections
import hashlib
import json
import math
import subprocess
import wave
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

FPS = 60
FS = 48000
OUT_S, IN_S, CHANGE_S = 0.62, 0.76, 1.8             # golden v9/v20 marker change choreography
INK_SPEED, COLOR_SPEED = 105.0, 210.0               # px/s measured on golden v20 at 800 px canvas
TRAVEL_SPEED = 380.0


def ease(u):
    u = float(np.clip(u, 0., 1.))
    return u * u * (3. - 2. * u)


# ------------------------------------------------------------------ timing ------------------------
class StrokeTiming:
    """Maps time -> distance along a stroke with v3-style pacing."""

    def __init__(self, pts, base_speed, pace=1.0):
        p = np.asarray(pts, float)
        self.pts = p
        if len(p) < 2 or np.hypot(*(np.diff(p, axis=0).T)).sum() < 1.0:
            self.cum = np.array([0.0, 1.0])
            self.pts = np.vstack([p[:1], p[:1] + [1.0, 0.0]]) if len(p) else np.zeros((2, 2))
            self.t = np.array([0.0, 0.16])
            self.length = 1.0
            return
        seg = np.hypot(*(np.diff(p, axis=0).T))
        self.cum = np.concatenate([[0.], np.cumsum(seg)])
        self.length = float(self.cum[-1])
        n = len(p)
        turn = np.zeros(n)
        k = 8
        for i in range(n):
            a, b, c = p[max(0, i - k)], p[i], p[min(n - 1, i + k)]
            v0, v1 = b - a, c - b
            if np.linalg.norm(v0) > 1e-6 and np.linalg.norm(v1) > 1e-6:
                turn[i] = abs(math.atan2(v0[0] * v1[1] - v0[1] * v1[0], float(np.dot(v0, v1))))
        f_c = np.clip(1. / (1. + 2.2 * turn), 0.35, 1.0)              # slow into curves
        ramp = min(26.0 * (base_speed / (INK_SPEED * 1.6)) ** 0.0, 0.3 * self.length)
        edge = np.minimum(self.cum, self.length - self.cum) / max(ramp, 1e-6)
        f_e = 0.10 + 0.90 * np.array([ease(e) for e in np.clip(edge, 0, 1)])   # рука м'яко сідає й м'яко відривається
        v = base_speed * pace * f_c * f_e
        from scipy.ndimage import gaussian_filter1d
        v = np.maximum(gaussian_filter1d(v, 6.0, mode='nearest'), base_speed * pace * 0.06)   # без стрибків швидкості
        dt = np.diff(self.cum) / np.maximum(0.5 * (v[:-1] + v[1:]), 1e-6)
        self.t = np.concatenate([[0.], np.cumsum(dt)])

    @property
    def duration(self):
        return float(self.t[-1])

    def dist_at(self, f):                       # f in 0..1 of the stroke's time
        return float(np.interp(f * self.t[-1], self.t, self.cum))

    def point_at(self, d):
        return (float(np.interp(d, self.cum, self.pts[:, 0])), float(np.interp(d, self.cum, self.pts[:, 1])))


def build_timeline(plan, W, pace=1.0, lead_in=0.9, tail_hold=0.7, off=None):
    S = W / 800.0
    OFF = off or (1230. * S, -195. * S)
    strokes = plan['strokes']
    timings = {}
    events = []
    t = 0.0
    if not strokes:
        return events, timings, OFF
    first = strokes[0]
    start = first['pts'][0]
    events.append(dict(kind='enter', t0=t, t1=t + lead_in, start=list(OFF), end=list(map(float, start)), color=first['fill']))
    t += lead_in
    prev = None
    for s in strokes:
        base = (INK_SPEED if s['kind'] == 'ink' else COLOR_SPEED) * S
        tm = StrokeTiming(s['pts'], base, pace)
        timings[s['id']] = tm
        a = np.asarray(s['pts'][0], float)
        if prev is not None:
            b = np.asarray(prev['pts'][-1], float)
            if prev['fill'] != s['fill']:
                events.append(dict(kind='tool_change', t0=t, t1=t + CHANGE_S, start=b.tolist(), end=a.tolist(),
                                   from_color=prev['fill'], to_color=s['fill']))
                t += CHANGE_S
            else:
                gap = float(np.hypot(*(a - b)))
                if gap > 2.0:
                    dur = float(np.clip(0.10 + gap / (TRAVEL_SPEED * S), 0.14, 0.7))
                    events.append(dict(kind='travel', t0=t, t1=t + dur, start=b.tolist(), end=a.tolist(), color=s['fill']))
                    t += dur
        events.append(dict(kind='draw', t0=t, t1=t + tm.duration, stroke_id=s['id'], color=s['fill'],
                           subtype=s['kind'], member=s.get('member')))
        t += tm.duration
        prev = s
    events.append(dict(kind='exit', t0=t, t1=t + tail_hold + OUT_S, start=prev['pts'][-1].tolist(), end=list(OFF),
                       color=prev['fill'], hold=tail_hold))
    return events, timings, OFF


# ------------------------------------------------------------------ actor --------------------------
def tint_marker(im, tip, rgb, tip_r=70.0):
    """Golden v13 tint: recolour only the dark marker body (not fingers/sleeve)."""
    arr = np.array(im.convert('RGBA'))
    p = arr[:, :, :3].astype(np.float32)
    maxi, mini = p.max(2), p.min(2)
    yy, xx = np.indices(maxi.shape)
    dark = (maxi < 120) & ((maxi - mini) < 38) & (arr[:, :, 3] > 90) & ((xx - tip[0]) ** 2 + (yy - tip[1]) ** 2 > tip_r ** 2)
    strength = np.clip(.4 + maxi / 180., .4, 1.)
    rgb = np.asarray(rgb, np.float32)
    rgb = rgb * min(1.0, 185.0 / max(1.0, float(rgb.max())))       # світлі кольори не перетворюються на «сірий» маркер
    colored = rgb[None, None, :] * strength[:, :, None]
    p[dark] = .82 * colored[dark] + .18 * p[dark]
    arr[:, :, :3] = np.uint8(np.clip(p, 0, 255))
    return Image.fromarray(arr, 'RGBA')


def premul(im):
    a = np.asarray(im, np.uint8)
    p = np.ascontiguousarray(a[:, :, [2, 1, 0, 3]])
    p[:, :, :3] = np.rint(p[:, :, :3].astype(np.float32) * p[:, :, 3:4] / 255).astype(np.uint8)
    return p


class Actor:
    def __init__(self, asset_dir, W, H, ink_actor='overhead_right_alt', color_actor='overhead_right'):
        self.W, self.H = W, H
        self.S = W / 800.0
        self.scale = 0.46 * self.S
        meta = {a['id']: a for a in json.loads((Path(asset_dir) / 'assets.json').read_text())['actors']}
        self.stage_id = {'ink': ink_actor, 'color': color_actor}
        self.nib, self.img, self.edge = {}, {}, {}
        for st, aid in self.stage_id.items():
            a = meta[aid]
            im = Image.open(Path(asset_dir).parent / a['file']).convert('RGBA')
            self.img[st] = im
            self.nib[st] = tuple(a['nib_px'])
            m = np.asarray(im)[:, :, 3] > 125
            b = np.zeros_like(m)
            b[:2, :] = b[-2:, :] = True
            b[:, :2] = b[:, -2:] = True
            yy, xx = np.where(b & m)
            self.edge[st] = np.column_stack((xx, yy)).astype(np.float32)
        self.variants = {}

    def variant(self, stage, color):
        key = (stage, color)
        if key not in self.variants:
            im = self.img[stage]
            if stage == 'color':
                r, g, b = (int(x) for x in color[4:-1].split(','))
                im = tint_marker(im, self.nib[stage], (r, g, b))
            self.variants[key] = premul(im)
        return self.variants[key]

    def draw(self, frame, stage, color, tip, ang, lift):
        nib = self.nib[stage]
        ra = math.radians(ang)
        c, s = self.scale * math.cos(ra), self.scale * math.sin(ra)
        tx = tip[0] - c * nib[0] + s * nib[1]
        ty = tip[1] - s * nib[0] - c * nib[1] - lift
        M = np.asarray([[c, -s, tx], [s, c, ty]], np.float32)
        fg = cv2.warpAffine(self.variant(stage, color), M, (self.W, self.H), flags=cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
        alpha = fg[:, :, 3:4].astype(np.float32) / 255.
        frame[:] = np.uint8(np.clip(fg[:, :, :3].astype(np.float32) + frame.astype(np.float32) * (1 - alpha), 0, 255))
        return math.hypot(c * nib[0] - s * nib[1] + tx - tip[0], s * nib[0] + c * nib[1] + ty + lift - tip[1])

    def edge_inside(self, stage, tip, ang, lift):
        nib = self.nib[stage]
        a = math.radians(ang)
        c, s = self.scale * math.cos(a), self.scale * math.sin(a)
        e = self.edge[stage]
        xx = tip[0] + c * (e[:, 0] - nib[0]) - s * (e[:, 1] - nib[1])
        yy = tip[1] + s * (e[:, 0] - nib[0]) + c * (e[:, 1] - nib[1]) - lift
        return int(np.count_nonzero((xx > 4) & (xx < self.W - 4) & (yy > 4) & (yy < self.H - 4)))

    def visible_anywhere(self, stage, color, tip, ang, lift):
        alpha = self.variant(stage, color)[:, :, 3]
        ys, xs = np.where(alpha[::20, ::20] > 160)
        if len(xs) == 0:
            return False
        x, y = xs * 20., ys * 20.
        nib = self.nib[stage]
        a = math.radians(ang)
        c, s = self.scale * math.cos(a), self.scale * math.sin(a)
        xx = tip[0] + c * (x - nib[0]) - s * (y - nib[1])
        yy = tip[1] + s * (x - nib[0]) + c * (y - nib[1]) - lift
        return bool(np.any((xx >= 0) & (xx < self.W) & (yy >= 0) & (yy < self.H)))


# ------------------------------------------------------------------ audio --------------------------
def read_wav(path):
    with wave.open(str(path)) as w:
        assert w.getframerate() == FS and w.getnchannels() == 1 and w.getsampwidth() == 2
        return np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(np.float32) / 32768.


def build_foley(audio_dir, contacts, kinds, out_path, fps=FPS):
    """Golden create_audio: real recordings, contact-gated; PCM is exactly zero off paper."""
    a = read_wav(Path(audio_dir) / 'marker_active_passes.wav')
    b = read_wav(Path(audio_dir) / 'scribbling_continuous.wav')
    n = FS // fps
    assert FS % fps == 0
    out = np.zeros(len(contacts) * n, np.float32)
    src = {'ink': a, 'color': b}
    off = {'ink': 1130, 'color': 530}
    for i, (c, k) in enumerate(zip(contacts, kinds)):
        if not c:
            continue
        s = src[k]
        block = s[(np.arange(n) + off[k]) % len(s)].copy()
        off[k] = (off[k] + n) % len(s)
        env = np.ones(n, np.float32)
        ramp = min(170, n // 4)
        if i == 0 or not contacts[i - 1]:
            env[:ramp] = np.linspace(0, 1, ramp)
        if i == len(contacts) - 1 or not contacts[i + 1]:
            env[-ramp:] = np.linspace(1, 0, ramp)
        out[i * n:(i + 1) * n] = block * env * (.13 if k == 'color' else .18)
    with wave.open(str(out_path), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(FS)
        w.writeframes((np.clip(out, -.9, .9) * 32767).astype('<i2').tobytes())
    off_mask = np.repeat(~np.asarray(contacts, bool), n)
    return dict(contact_frames=int(sum(contacts)), noncontact_frames=int(len(contacts) - sum(contacts)),
                noncontact_max_abs=float(np.max(np.abs(out[off_mask]), initial=0.0)))


# ------------------------------------------------------------------ rendering ----------------------
class Painter:
    def __init__(self, scene, plan, timings):
        self.scene, self.plan, self.timings = scene, plan, timings
        H, W = scene.H, scene.W
        self.canvas = np.full((H, W, 3), 255, np.uint8)
        self.ref_bgr = np.ascontiguousarray(scene.ref[:, :, ::-1])
        k = np.ones((3, 3), np.uint8)
        ink = np.zeros((H, W), bool)
        self.allowed_member = {}
        for i, m in enumerate(scene.members):
            mk = scene.mask(i)
            if m['role'] in ('ink_rim', 'ink_stroke'):
                ink |= mk
            else:
                self.allowed_member[m['id']] = cv2.dilate(mk.astype(np.uint8), k).astype(bool)
        self.allowed_ink = cv2.dilate(ink.astype(np.uint8), k).astype(bool)
        self.ink_bgr = np.array(self._rgb(plan.get('ink_rgb', 'rgb(30,30,30)'))[::-1], np.float32)
        self.inked = np.zeros((H, W), bool)           # піксели чистого контуру: колір їх не перекриває
        self.done = {}
        self.by_id = {s['id']: s for s in plan['strokes']}

    @staticmethod
    def _rgb(c):
        return tuple(int(x) for x in c[4:-1].split(','))

    def deposit(self, sid, d0, d1):
        if d1 <= d0 + 1e-9:
            return
        s, tm = self.by_id[sid], self.timings[sid]
        pts = tm.pts
        cum = tm.cum
        i0 = max(0, int(np.searchsorted(cum, d0)) - 1)
        i1 = min(len(pts) - 1, int(np.searchsorted(cum, d1)) + 1)
        sel = pts[i0:i1 + 1]
        touch = np.zeros(self.canvas.shape[:2], np.uint8)
        pp = np.rint(sel).astype(np.int32).reshape(-1, 1, 2)
        line = s['kind'] == 'ink' and s.get('style', 'line') == 'line'
        w = max(1, int(round(s['width'])))
        if len(pp) == 1:
            cv2.circle(touch, tuple(int(v) for v in pp[0, 0]), max(1, w // 2), 255, -1,
                       cv2.LINE_AA if line else cv2.LINE_8)
        else:
            cv2.polylines(touch, [pp], False, 255, w, cv2.LINE_AA if line else cv2.LINE_8)
        if line:
            # чистий суцільний контур маркером: його ширина = ширина маркера, колір = колір маркера
            a = (touch.astype(np.float32) / 255.)[:, :, None]
            self.canvas[:] = np.uint8(np.clip(self.ink_bgr * a + self.canvas.astype(np.float32) * (1 - a), 0, 255))
            self.inked |= touch > 127
            return
        allowed = self.allowed_ink if s['kind'] == 'ink' else self.allowed_member.get(s.get('member'), None)
        if allowed is None:
            return
        m = (touch > 0) & allowed
        if s['kind'] == 'ink':
            self.canvas[m] = self.ref_bgr[m]
            self.inked |= m
        else:
            m &= ~self.inked                           # колір ніколи не перекриває вже проведений контур
            self.canvas[m] = self.ref_bgr[m]

    def advance(self, t, events, ends, progress):
        i = progress['i']
        while i < len(events) and events[i]['t1'] <= t:
            e = events[i]
            if e['kind'] == 'draw':
                self.deposit(e['stroke_id'], self.done.get(e['stroke_id'], 0.0), self.timings[e['stroke_id']].length + 1)
                self.done[e['stroke_id']] = self.timings[e['stroke_id']].length + 1
            i += 1
        progress['i'] = i
        if i < len(events) and events[i]['kind'] == 'draw' and t >= events[i]['t0']:
            e = events[i]
            tm = self.timings[e['stroke_id']]
            f = float(np.clip((t - e['t0']) / (e['t1'] - e['t0']), 0, 1))
            goal = tm.dist_at(f)
            prev = self.done.get(e['stroke_id'], 0.0)
            if goal > prev:
                self.deposit(e['stroke_id'], prev, goal)
                self.done[e['stroke_id']] = goal


def make_pose(events, timings, strokes_by_id, OFF, S):
    ends = [e['t1'] for e in events]
    lastcol = {}

    def color_at(idx):
        for j in range(idx, -1, -1):
            if events[j]['kind'] in ('draw', 'travel', 'enter', 'exit'):
                return events[j]['color']
            if events[j]['kind'] == 'tool_change':
                return events[j]['to_color']
        return events[0]['color']

    def stage_of(col, strokes_by_id=strokes_by_id):
        return 'ink' if col == ink_color[0] else 'color'
    ink_color = [next(s['fill'] for s in strokes_by_id.values() if s['kind'] == 'ink')] if any(
        s['kind'] == 'ink' for s in strokes_by_id.values()) else ['']

    def pose(t):
        idx = min(len(events) - 1, max(0, bisect.bisect_right(ends, float(t))))
        e = events[idx]
        k = e['kind']
        if k == 'draw':
            tm = timings[e['stroke_id']]
            f = float(np.clip((t - e['t0']) / (e['t1'] - e['t0']), 0, 1))
            pt = tm.point_at(tm.dist_at(f))
            return True, pt, e['color'], 'draw', 'ink' if e['subtype'] == 'ink' else 'color', (e['stroke_id'], f)
        if k in ('travel', 'enter'):
            u = ease((t - e['t0']) / (e['t1'] - e['t0']))
            pt = [e['start'][j] * (1 - u) + e['end'][j] * u for j in (0, 1)]
            pt[1] -= (35 * S if k == 'travel' else 0) * math.sin(math.pi * u)
            col = e['color']
            return False, pt, col, k, stage_of(col), None
        if k == 'tool_change':
            u = t - e['t0']
            dur = e['t1'] - e['t0']
            if u < OUT_S:
                a = ease(u / OUT_S)
                pt = [e['start'][j] * (1 - a) + OFF[j] * a for j in (0, 1)]
                pt[1] -= 35 * S * math.sin(math.pi * a)
                return False, pt, e['from_color'], 'exit', stage_of(e['from_color']), None
            if u < dur - IN_S:
                return False, OFF, e['from_color'], 'offscreen', stage_of(e['from_color']), None
            a = ease((u - (dur - IN_S)) / IN_S)
            pt = [OFF[j] * (1 - a) + e['end'][j] * a for j in (0, 1)]
            pt[1] -= 35 * S * math.sin(math.pi * a)
            return False, pt, e['to_color'], 'return', stage_of(e['to_color']), None
        if k == 'exit':
            u = max(0.0, t - e['t0'] - e.get('hold', 0.0))
            a = ease(u / OUT_S)
            pt = [e['start'][j] * (1 - a) + OFF[j] * a for j in (0, 1)]
            pt[1] -= 35 * S * math.sin(math.pi * a)
            return False, pt, e['color'], 'exit' if a > 0 else 'hold', stage_of(e['color']), None
        return False, None, '', 'gone', 'ink', None
    return pose, ends


def steering(timings, sid, f, window=0.095):
    """v13 restrained path-directed lean about the nib (never a spinning hand)."""
    tm = timings[sid]
    D = tm.duration
    if D <= 0:
        return 0.0
    t = f * D
    lo, hi = max(0.0, t - window), min(D, t + window)
    if hi - lo < .024:
        return 0.0

    def P(tt):
        return np.asarray(tm.point_at(float(np.interp(tt, tm.t, tm.cum))))
    p0, p1, pm = P(lo), P(hi), P(t)
    d = p1 - p0
    dist = np.linalg.norm(d)
    if dist < .7:
        return 0.0
    heading = math.atan2(d[1], d[0])
    lean = 3.10 * math.sin(heading - math.pi)
    v0, v1 = pm - p0, p1 - pm
    if min(np.linalg.norm(v0), np.linalg.norm(v1)) > 1.1:
        turn = math.atan2(float(v0[0] * v1[1] - v0[1] * v1[0]), float(np.dot(v0, v1)))
        lean += 1.70 * math.tanh(turn / .52)
    return max(-4.0, min(4.0, lean * min(1., dist / 8.)))


def render_video(scene, plan, out_dir, assets_dir, audio_dir, pace=1.0, story=None, fps=FPS, crf=20, preset='veryfast',
                 painter_kind='source', t_start=None, t_end=None, hand_kind='golden', sound_kind='golden', mix=None,
                 poses=None, background=None):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    W, H = scene.W, scene.H
    S = W / 800.0
    events, timings, OFF = build_timeline(plan, W, pace)
    by_id = {s['id']: s for s in plan['strokes']}
    pose, ends = make_pose(events, timings, by_id, OFF, S)
    actor = Actor(assets_dir, W, H)
    bgc = None
    if background:
        from background import Background
        bgc = Background(background, W, H)
    _comp = (lambda cv: bgc.compose(cv)) if bgc else (lambda cv: cv)
    hand2 = None
    pose_ids = {'ink': 'overhead_right_alt', 'color': 'overhead_right'}
    if hand_kind == 'v2':
        from hand2 import HandV2
        hand2 = HandV2(assets_dir, W, H)
        pose_ids.update(poses or {})
        if not poses:                                   # автовибір: перша поза, безпечна для всіх штрихів цього маркера
            for stg, kk in (('ink', 'ink'), ('color', 'color')):
                pts = [p for st in plan['strokes'] if (st['kind'] == 'ink') == (kk == 'ink') for p in st['pts'][::4]]
                if pts:
                    for pid in [pose_ids[stg]] + [q for q in ('overhead_right_alt', 'overhead_right', 'overhead_high',
                                                              'overhead_bottomright') if q != pose_ids[stg]]:
                        if hand2.safe_for(pid, pts):
                            pose_ids[stg] = pid
                            break
    if painter_kind == 'source':
        from painter2 import Painter2
        painter = Painter2(scene, plan, timings)
    else:
        painter = Painter(scene, plan, timings)
    draw_frames = int(math.ceil(events[-1]['t1'] * fps))
    f0 = int(round((t_start or 0.0) * fps))
    if t_end is not None:
        draw_frames = min(draw_frames, int(round(t_end * fps)))
        story = None
    story_frames = story.frames if story else 0
    total = draw_frames + story_frames
    silent = out / 'video_silent.mp4'
    enc = subprocess.Popen(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'bgr24',
                            '-s', f'{W}x{H}', '-r', str(fps), '-i', 'pipe:0', '-an', '-c:v', 'libx264', '-preset', preset,
                            '-crf', str(crf), '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(silent)],
                           stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    progress = {'i': 0}
    theta = 0.
    contacts, kinds, bad, contact_err, change_vis = [], [], [], [], []
    phase_count = collections.Counter()
    snaps = {}
    marks = {int(round(f0 + p * (draw_frames - f0 - 1))): p for p in (0, .25, .5, .75, 1.0)}
    prev_tip, speeds, skinds, tips_log = None, [], [], []
    if f0:
        painter.advance((f0 + .5) / fps, events, ends, progress)
    a_k = 1. - math.exp(-1. / (fps * .135))
    for i in range(f0, total):
        t = (i + .5) / fps
        if i < draw_frames:
            painter.advance(t, events, ends, progress)
            contact, tip, color, phase, stage, info = pose(t)
            target = steering(timings, info[0], info[1]) if (contact and info) else 0.
            if hand2 is not None:
                theta = hand2.step(target, 1. / fps, t, contact)
            else:
                theta += float(np.clip(a_k * (target - theta), -.20, .20))
                theta = float(np.clip(theta, -4., 4.))
            frame = _comp(painter.canvas).copy()
            if tip is not None and phase != 'gone':
                lift = 0. if contact else 12. * S
                e = events[min(len(events) - 1, bisect.bisect_right(ends, t))]
                if phase in ('exit', 'return') and e['kind'] == 'tool_change':
                    local = t - e['t0']
                    if phase == 'exit':
                        lift = 12 * S * ease(local / .18)
                    else:
                        d = e['t1'] - e['t0']
                        lift = 12 * S * (1. - ease((local - (d - .2)) / .2)) if local > d - .2 else 12 * S
                if e['kind'] in ('travel', 'enter', 'exit'):
                    local, d = t - e['t0'], e['t1'] - e['t0']
                    up = ease(local / .14)                                   # рука плавно відривається від паперу
                    down = ease((d - local) / .14) if e['kind'] != 'exit' else 1.0   # і плавно опускається
                    lift = 12 * S * min(up, down) if e['kind'] != 'enter' else 12 * S * down
                if hand2 is not None:
                    pid = pose_ids[stage]
                    cnt = hand2.edge_inside(pid, tip, theta, lift)
                else:
                    cnt = actor.edge_inside(stage, tip, theta, lift)
                if cnt:
                    bad.append([i, round(t, 3), stage, cnt])
                if phase == 'offscreen' and (hand2.visible_anywhere(pose_ids[stage], color, stage == 'color', tip, theta, lift)
                                             if hand2 else actor.visible_anywhere(stage, color, tip, theta, lift)):
                    change_vis.append([i, round(t, 3)])
                if hand2 is not None:
                    err = hand2.draw(frame, pose_ids[stage], color, stage == 'color', tip, theta, lift, t, contact)
                else:
                    err = actor.draw(frame, stage, color, tip, theta, lift)
                if contact:
                    contact_err.append(err)
            contacts.append(bool(contact))
            kinds.append('ink' if stage == 'ink' else 'color')
            sp = 0.0
            if contact and tip is not None and prev_tip is not None:
                sp = math.hypot(tip[0] - prev_tip[0], tip[1] - prev_tip[1]) * fps / S
            prev_tip = tip if contact else None
            speeds.append(sp)
            skinds.append(by_id[info[0]].get('style') if (contact and info) else None)
            phase_count[phase] += 1
            if i in marks:
                snaps[marks[i]] = frame.copy()
        else:
            frame = _comp(story.frame(i - draw_frames, painter.canvas))
            contacts.append(False)
            kinds.append('ink')
            speeds.append(0.0)
            skinds.append(None)
        enc.stdin.write(frame.tobytes())
    enc.stdin.close()
    if enc.wait(timeout=300) != 0:
        raise RuntimeError(enc.stderr.read().decode()[-800:])
    wav = out / 'foley_contact.wav'
    if sound_kind == 'golden':
        aq = build_foley(audio_dir, contacts, kinds, wav, fps)
    else:
        from sound2 import build_foley2
        tev = [(e['t0'] - f0 / fps, e['t1'] - f0 / fps) for e in events
               if e['kind'] == 'tool_change' and e['t1'] > f0 / fps and e['t0'] < draw_frames / fps]
        m2 = dict(mix or {})
        m2['variant'] = sound_kind
        aq = build_foley2(audio_dir, contacts, kinds, speeds, tev, wav, fps, m2, skinds)
    mp4 = out / 'SHINE_Creator_clip.mp4'
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(silent), '-i', str(wav), '-c:v', 'copy', '-c:a', 'aac',
                    '-b:a', '128k', '-shortest', '-movflags', '+faststart', str(mp4)], check=True)
    final = painter.canvas
    diff = np.abs(final.astype(np.int16) - painter.ref_bgr.astype(np.int16)).max(2)
    qa = dict(schema='shine.creator_clip.v36', canvas=[W, H], fps=fps, frames=total - f0, drawing_frames=draw_frames - f0, window=[f0 / fps, total / fps],
              duration_s=round((total - f0) / fps, 3), strokes=len(plan['strokes']),
              chapters=len(plan['chapters']), tool_changes=sum(e['kind'] == 'tool_change' for e in events),
              phases=dict(phase_count), foley=aq, unsafe_hand_frames=len({b[0] for b in bad}), first_unsafe=bad[:8],
              offscreen_visible_frames=len(change_vis),
              tip_anchor_error_max_px=float(max(contact_err, default=0.)),
              painter=painter_kind, reveal=getattr(painter, 'reveal_report', lambda: None)(),
              outline_normalised=(painter_kind != 'source'), final_vs_reference_gt40_ratio=float((diff > 40).mean()), final_vs_reference_gt40_px=int((diff > 40).sum()),
              source_sha256=plan['source_sha256'], video=mp4.name,
              hand=f'{hand_kind}: ' + (str(pose_ids) if hand2 else 'golden poses right_alt/right'),
              sound=sound_kind)
    (out / 'QA.json').write_text(json.dumps(qa, indent=1))
    for p, f in snaps.items():
        cv2.imwrite(str(out / f'frame_{int(p * 100):03d}.png'), f)
    return qa, events
