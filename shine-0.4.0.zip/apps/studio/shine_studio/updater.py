"""Оновлення програми без інсталятора: маленький zip з кодом, перевірка SHA-256, перемикання версії.

Схема встановлення (див. install.ps1):
  <ROOT>/python/            вбудований Python із пакетами
  <ROOT>/boot.py            тонкий завантажувач
  <ROOT>/versions/<ver>/    код версії (apps/studio, apps/autonomous_v2/...)
  <ROOT>/current.txt        яка версія запускається;  previous.txt - для відкату
Оновлення = завантажити zip у versions/<нова>, (за потреби) доставити пакети, переписати current.txt, перезапуск.
Залежить лише від стандартної бібліотеки. Нічого не застосовується мовчки: користувач тисне «Оновити».
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable, Optional

from . import __version__, settings

DEFAULT_MANIFEST = "https://raw.githubusercontent.com/artstageteam-droid/shine-releases/main/latest.json"
MAX_MANIFEST = 1 << 20
MAX_ZIP = 300 << 20
KEEP_VERSIONS = 3


class UpdateError(RuntimeError):
    pass


def parse_version(s: str) -> tuple:
    try:
        return tuple(int(x) for x in str(s).strip().split("."))
    except ValueError:
        raise UpdateError(f"Некоректний номер версії: {s!r}")


def _check_url(url: str) -> None:
    u = urllib.parse.urlparse(url)
    local = u.hostname in ("127.0.0.1", "localhost")
    if not (u.scheme == "https" or (u.scheme == "http" and local)):
        raise UpdateError("Оновлення дозволені лише через https")


def http_get(url: str, limit: int, progress: Optional[Callable[[int, int], None]] = None, dest: Optional[Path] = None):
    """Повертає bytes (dest=None) або пише у файл і повертає sha256 hex."""
    _check_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": "SHINE-Studio-Updater"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            total = int(r.headers.get("Content-Length") or 0)
            if total > limit:
                raise UpdateError("Файл оновлення завеликий")
            h, got, buf = hashlib.sha256(), 0, []
            out = open(dest, "wb") if dest else None
            try:
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > limit:
                        raise UpdateError("Файл оновлення завеликий")
                    h.update(chunk)
                    (out.write(chunk) if out else buf.append(chunk))
                    if progress:
                        progress(got, total)
            finally:
                if out:
                    out.close()
    except UpdateError:
        raise
    except Exception as e:
        raise UpdateError(f"Немає зв'язку з каналом оновлень: {e}")
    return h.hexdigest() if dest else b"".join(buf)


def safe_extract(zf: zipfile.ZipFile, dest: Path) -> None:
    base = dest.resolve()
    for m in zf.infolist():
        target = (dest / m.filename).resolve()
        if base != target and base not in target.parents:
            raise UpdateError("Архів оновлення містить небезпечний шлях")
    zf.extractall(dest)


def _file_sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ""


def _pip(python: str, req: Path) -> None:
    r = subprocess.run([python, "-m", "pip", "install", "-r", str(req), "--no-warn-script-location", "-q"],
                       capture_output=True, text=True)
    if r.returncode:
        raise UpdateError("Не вдалося доставити бібліотеки: " + (r.stderr or r.stdout)[-300:])


def _restart() -> None:
    """Запускає boot.py заново і завершує поточний процес (після відповіді API)."""
    root = Path(os.environ["SHINE_APP_ROOT"])
    py = sys.executable
    if os.name == "nt":
        pyw = Path(py).with_name("pythonw.exe")
        py = str(pyw if pyw.exists() else py)
    def _go():
        time.sleep(0.8)                                  # дати API відповісти
        try:
            from . import launcher
            launcher.terminate_window()                  # звільнити профіль вікна для нового запуску
        except Exception:
            pass
        subprocess.Popen([py, str(root / "boot.py")], cwd=str(root), close_fds=True,
                         env=dict(os.environ, SHINE_RESTART="1"))
        time.sleep(0.3)
        os._exit(0)
    threading.Thread(target=_go, daemon=True).start()


class Updater:
    def __init__(self, root: Optional[Path] = None, fetch=http_get, pip_runner=_pip, restart=_restart,
                 manifest_url: Optional[str] = None):
        env = os.environ.get("SHINE_APP_ROOT")
        self.root = Path(root) if root else (Path(env) if env else None)
        self._fetch, self._pip, self._restart = fetch, pip_runner, restart
        self._url = manifest_url
        self._manifest = None

    # --- допоміжне ---
    def _manifest_url(self) -> str:
        return self._url or settings.load().get("update_url") or DEFAULT_MANIFEST

    def _need_root(self) -> Path:
        if not self.root or not (self.root / "current.txt").exists():
            raise UpdateError("Оновлення доступні лише у встановленій програмі (запущеній через ярлик SHINE)")
        return self.root

    def _current(self) -> str:
        return (self._need_root() / "current.txt").read_text(encoding="utf-8").strip()

    def status(self) -> dict:
        st = dict(current=__version__, installed=bool(self.root and (self.root / "current.txt").exists()),
                  available=False, can_rollback=False)
        if not st["installed"]:
            st["reason"] = "Оновлення недоступні в цьому режимі запуску (потрібна встановлена програма)."
            return st
        prev = (self.root / "previous.txt").read_text(encoding="utf-8").strip() if (self.root / "previous.txt").exists() else ""
        st["can_rollback"] = bool(prev and (self.root / "versions" / prev).is_dir())
        st["previous"] = prev
        return st

    # --- кроки ---
    def check(self) -> dict:
        st = self.status()
        if not st["installed"]:
            return st
        try:
            raw = self._fetch(self._manifest_url(), MAX_MANIFEST)
            m = json.loads(raw.decode("utf-8"))
            ver, name, sha = str(m["version"]), str(m["zip"]), str(m["sha256"]).lower()
            parse_version(ver)
            if len(sha) != 64:
                raise ValueError("sha256")
        except UpdateError as e:
            st["error"] = str(e)
            return st
        except (ValueError, KeyError, TypeError):
            st["error"] = "Канал оновлень повернув некоректні дані"
            return st
        self._manifest = dict(version=ver, zip=urllib.parse.urljoin(self._manifest_url(), name), sha256=sha,
                              size=int(m.get("size") or 0), notes=str(m.get("notes") or ""))
        if parse_version(ver) > parse_version(st["current"]):
            st.update(available=True, version=ver, notes=self._manifest["notes"], size=self._manifest["size"])
        return st

    def download(self, progress: Optional[Callable[[int, int], None]] = None) -> dict:
        root = self._need_root()
        m = self._manifest
        if not m:
            raise UpdateError("Спершу перевірте наявність оновлень")
        ver = m["version"]
        target = root / "versions" / ver
        if (target / "apps" / "studio" / "shine_studio" / "VERSION").exists():
            return dict(downloaded=True, version=ver, cached=True)
        dl = root / "downloads"
        dl.mkdir(exist_ok=True)
        part = dl / f"shine-{ver}.zip.part"
        got = self._fetch(m["zip"], MAX_ZIP, progress, part)
        if got != m["sha256"]:
            part.unlink(missing_ok=True)
            raise UpdateError("Контрольна сума не збігається: оновлення пошкоджене, нічого не змінено")
        tmp = root / "versions" / f"{ver}.tmp"
        shutil.rmtree(tmp, ignore_errors=True)
        try:
            with zipfile.ZipFile(part) as zf:
                safe_extract(zf, tmp)
            v = (tmp / "apps" / "studio" / "shine_studio" / "VERSION")
            if not v.exists() or v.read_text(encoding="utf-8").strip() != ver:
                raise UpdateError("Архів не відповідає заявленій версії")
            old_req = root / "versions" / self._current() / "apps" / "studio" / "requirements.txt"
            new_req = tmp / "apps" / "studio" / "requirements.txt"
            if _file_sha(old_req) != _file_sha(new_req):          # змінились бібліотеки: доставляємо ДО перемикання
                self._pip(sys.executable, new_req)
            shutil.rmtree(target, ignore_errors=True)
            os.replace(tmp, target)
        except BaseException:
            shutil.rmtree(tmp, ignore_errors=True)
            raise
        finally:
            part.unlink(missing_ok=True)
        return dict(downloaded=True, version=ver)

    def _switch(self, new: str, old: str) -> None:
        root = self._need_root()
        for name, val in (("previous.txt", old), ("current.txt", new)):
            tmp = root / (name + ".tmp")
            tmp.write_text(val, encoding="utf-8")
            os.replace(tmp, root / name)

    def apply(self) -> None:
        """Перемикає версію й перезапускає програму. Викликати лише після збереження проєктів."""
        root = self._need_root()
        m = self._manifest
        if not m or not (root / "versions" / m["version"]).is_dir():
            raise UpdateError("Спершу перевірте та завантажте оновлення")
        old = self._current()
        self._switch(m["version"], old)
        self._cleanup(keep={m["version"], old})
        self._restart()

    def rollback(self) -> None:
        root = self._need_root()
        prev = (root / "previous.txt").read_text(encoding="utf-8").strip() if (root / "previous.txt").exists() else ""
        if not prev or not (root / "versions" / prev).is_dir():
            raise UpdateError("Попередньої версії немає")
        self._switch(prev, self._current())
        self._restart()

    def _cleanup(self, keep: set) -> None:
        vers = self._need_root() / "versions"
        dirs = sorted([d for d in vers.iterdir() if d.is_dir() and not d.name.endswith(".tmp")],
                      key=lambda d: parse_version(d.name) if d.name.replace(".", "").isdigit() else (0,), reverse=True)
        for d in dirs[KEEP_VERSIONS:]:
            if d.name not in keep:
                shutil.rmtree(d, ignore_errors=True)
