"""Запуск: сервер на localhost + вікно програми (Edge у режимі --app, є в кожному Windows 10/11).

Одна копія: якщо програма вже працює, просто відкриваємо ще одне вікно до неї.
Закриття вікна = завершення програми.
"""
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _setup_logging() -> None:
    """pythonw.exe не має консолі (stdout=None): пишемо у файл, інакше uvicorn може впасти."""
    from . import paths
    log = paths.home() / "logs"
    log.mkdir(exist_ok=True)
    if sys.stdout is None or sys.stderr is None:
        f = open(log / "studio.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or f
        sys.stderr = sys.stderr or f


def _browser_cmd(url: str):
    """Команда для вікна-застосунку. Окремий профіль змушує Edge запустити власний процес, який можна дочекатись."""
    if os.name != "nt":
        return None
    from . import paths
    profile = str(paths.home() / "window-profile")
    for env in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if not base:
            continue
        for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
            exe = Path(base) / rel
            if exe.exists():
                return [str(exe), f"--app={url}", f"--user-data-dir={profile}", "--no-first-run",
                        "--window-size=1360,860"]
    return None


def _alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1) as r:
            return json.loads(r.read()).get("ok") is True
    except Exception:
        return False


_WINDOW = None


def terminate_window() -> None:
    """Закриває вікно програми (потрібно перед перезапуском після оновлення: той самий профіль браузера)."""
    if _WINDOW is not None and _WINDOW.poll() is None:
        _WINDOW.terminate()
        try:
            _WINDOW.wait(3)
        except Exception:
            _WINDOW.kill()


def _open_window(url: str) -> None:
    global _WINDOW
    cmd = _browser_cmd(url)
    if cmd:
        _WINDOW = subprocess.Popen(cmd)
        _WINDOW.wait()
        return
    webbrowser.open(url)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass


def main() -> None:
    from . import paths
    _setup_logging()
    portfile = paths.home() / "running.port"
    if portfile.exists() and not os.environ.get("SHINE_HEADLESS") and not os.environ.get("SHINE_RESTART"):
        try:
            old = int(portfile.read_text())
            if _alive(old):                                   # вже запущена: лише нове вікно
                _open_window(f"http://127.0.0.1:{old}/")
                return
        except (ValueError, OSError):
            pass
    import uvicorn
    from .server import create_app

    app = create_app()
    port = int(os.environ.get("SHINE_PORT") or _free_port())
    srv = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", log_config=None))
    threading.Thread(target=srv.run, daemon=True).start()
    for _ in range(200):
        if srv.started:
            break
        time.sleep(0.05)
    if not srv.started:
        raise RuntimeError("Не вдалося запустити локальний сервер")
    portfile.write_text(str(port))
    url = f"http://127.0.0.1:{port}/"
    try:
        if os.environ.get("SHINE_HEADLESS"):                  # для тестів: без вікна
            print("READY", url, flush=True)
            while True:
                time.sleep(1)
        _open_window(url)
    except KeyboardInterrupt:
        pass
    finally:
        srv.should_exit = True
        try:
            portfile.unlink()
        except OSError:
            pass


if __name__ == "__main__":
    main()
