"""Налаштування користувача (канал оновлень тощо)."""
import json
from . import paths

# update_url порожній = стандартний канал (див. updater.DEFAULT_MANIFEST).
DEFAULTS = {"update_url": "", "language": "uk"}


def load() -> dict:
    f = paths.settings_file()
    data = dict(DEFAULTS)
    try:
        data.update(json.loads(f.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return data


def save(patch: dict) -> dict:
    data = load()
    for k in DEFAULTS:
        if k in patch:
            data[k] = patch[k]
    paths.settings_file().write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return load()
