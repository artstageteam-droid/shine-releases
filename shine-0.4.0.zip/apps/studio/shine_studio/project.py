"""Проєкт = папка з project.json (єдине джерело істини). Схема версіонується, є міграції.

Папка:  source/ objects/ analysis/ cache/ renders/ + project.json
Збереження атомарне (temp -> replace) із резервною копією попередньої версії.
"""
import hashlib
import json
import os
import re
import shutil
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from . import paths

SCHEMA_VERSION = 1
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
SUBDIRS = ("source", "objects", "analysis", "cache", "renders")


class Source(BaseModel):
    id: str
    file: str                      # відносно папки проєкту
    sha256: str
    added: float = Field(default_factory=time.time)


class Project(BaseModel):
    schema_version: int = SCHEMA_VERSION
    id: str
    name: str
    created: float = Field(default_factory=time.time)
    updated: float = Field(default_factory=time.time)
    kind: str = "character"        # character | set | objects | scene
    request: Optional[Dict[str, Any]] = None     # JSON з Prompt Studio
    sources: List[Source] = Field(default_factory=list)
    objects: List[Dict[str, Any]] = Field(default_factory=list)   # заповнює Intake (M1)
    plan: Dict[str, Any] = Field(default_factory=dict)
    timeline: Dict[str, Any] = Field(default_factory=dict)
    style: Dict[str, Any] = Field(default_factory=dict)           # tool/hand/background/music (packs)


class ProjectError(ValueError):
    pass


# --- міграції: {з_версії: функція(dict)->dict}; поки лише v1 ---
MIGRATIONS: Dict[int, Any] = {}


def migrate(data: dict) -> dict:
    v = int(data.get("schema_version", 1))
    if v > SCHEMA_VERSION:
        raise ProjectError(f"Проєкт створено новішою версією програми (схема {v}). Оновіть програму.")
    while v < SCHEMA_VERSION:
        data = MIGRATIONS[v](data)
        v += 1
        data["schema_version"] = v
    return data


def check_id(pid: str) -> str:
    if not isinstance(pid, str) or not ID_RE.match(pid):
        raise ProjectError("Некоректний ідентифікатор проєкту")
    return pid


def project_path(pid: str) -> Path:
    base = paths.projects_dir().resolve()
    p = (base / check_id(pid)).resolve()
    if base not in p.parents:
        raise ProjectError("Некоректний шлях проєкту")
    return p


def slugify(name: str) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", name.strip().lower()).strip("-")[:32]
    return s or "project"


def create(name: str, kind: str = "character", request: Optional[dict] = None) -> Project:
    name = (name or "").strip()
    if not name:
        raise ProjectError("Вкажіть назву проєкту")
    pid = f"{slugify(name)}-{uuid.uuid4().hex[:6]}"
    root = project_path(pid)
    root.mkdir(parents=True)
    for d in SUBDIRS:
        (root / d).mkdir()
    pr = Project(id=pid, name=name, kind=kind, request=request)
    save(pr)
    return pr


def save(pr: Project) -> None:
    root = project_path(pr.id)
    pr.updated = time.time()
    f = root / "project.json"
    tmp = root / "project.json.tmp"
    tmp.write_text(pr.model_dump_json(indent=2), encoding="utf-8")
    if f.exists():
        shutil.copy2(f, root / "project.json.bak")
    os.replace(tmp, f)


def load(pid: str) -> Project:
    f = project_path(pid) / "project.json"
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise ProjectError("Проєкт не знайдено")
    except ValueError:
        bak = f.with_name("project.json.bak")      # пошкоджений файл: пробуємо резервну копію
        if not bak.exists():
            raise ProjectError("project.json пошкоджено і резервної копії немає")
        data = json.loads(bak.read_text(encoding="utf-8"))
    return Project(**migrate(data))


def list_projects() -> List[dict]:
    out = []
    for d in sorted(paths.projects_dir().iterdir()):
        if (d / "project.json").exists() and ID_RE.match(d.name):
            try:
                p = load(d.name)
                out.append(dict(id=p.id, name=p.name, kind=p.kind, updated=p.updated, sources=len(p.sources)))
            except ProjectError:
                out.append(dict(id=d.name, name=d.name, kind="?", updated=0, sources=0, broken=True))
    out.sort(key=lambda x: -x["updated"])
    return out


def add_source(pid: str, filename: str, data: bytes) -> Source:
    """Додає оригінал у source/ (незмінний, SHA-256). Дублікат за хешем не додається."""
    ext = Path(filename).suffix.lower()
    if ext not in (".png", ".svg"):
        raise ProjectError("Підтримуються лише PNG та SVG")
    pr = load(pid)
    sha = hashlib.sha256(data).hexdigest()
    for s in pr.sources:
        if s.sha256 == sha:
            return s
    sid = f"s{len(pr.sources) + 1:03d}"
    rel = f"source/{sid}{ext}"
    (project_path(pid) / rel).write_bytes(data)
    src = Source(id=sid, file=rel, sha256=sha)
    pr.sources.append(src)
    save(pr)
    return src
