"""Де лежать дані користувача. Окремо від програми, щоб оновлення їх не чіпало."""
import os
import sys
from pathlib import Path


def home() -> Path:
    """Корінь даних: SHINE_HOME (для тестів) або Документи/SHINE."""
    env = os.environ.get("SHINE_HOME")
    base = Path(env) if env else Path.home() / "Documents" / "SHINE"
    base.mkdir(parents=True, exist_ok=True)
    return base


def projects_dir() -> Path:
    p = home() / "Projects"
    p.mkdir(parents=True, exist_ok=True)
    return p


def settings_file() -> Path:
    return home() / "settings.json"


def engine_dir() -> Path:
    """Каталог рушія creator_v36 (у збірці PyInstaller лежить поруч із програмою)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent)) / "creator_v36"
    return Path(__file__).resolve().parents[2] / "autonomous_v2" / "creator_v36"


def ui_dir() -> Path:
    return Path(__file__).with_name("ui")


def prepare_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "autonomous_v2" / "prepare_v36"


def add_engine_to_path() -> None:
    """В розробці модулі рушія лежать плоскими файлами; у збірці вони вже всередині пакета."""
    import sys as _s
    if not getattr(_s, "frozen", False):
        for d in (engine_dir(), prepare_dir()):
            if str(d) not in _s.path:
                _s.path.insert(0, str(d))
