"""Запуск із вихідного коду / точка входу для PyInstaller."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from shine_studio.launcher import main

if __name__ == "__main__":
    main()
