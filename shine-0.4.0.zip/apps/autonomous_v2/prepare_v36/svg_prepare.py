#!/usr/bin/env python3
"""SHINE SVG Preparation v36 - generic, source-locked, explainable.

Why this exists
---------------
Anonymous high-quality vector art (e.g. Recraft/Illustrator export) has no semantic markup.
The v23/v24 importer is label-driven and, correctly, refuses to guess from darkness, so every
element is 'unclassified' and no drawing plan is produced.  This module supplies the missing
*preparation* step without touching the source file:

1. Hardened load (no DOCTYPE/entities/external refs/scripts) - reuses the v23 safety loader.
2. Exact painter-order visibility: every drawable is rendered with a unique flat id colour by the
   real renderer (CairoSVG), so transforms, nested groups, fill rules and clipping behave as in
   the final picture.  No hand-written path geometry.
3. Per-element *visible* measurements (area, thinness, components, luminance).
4. Role hypotheses with confidence + human-readable reasons.  Roles are SUGGESTIONS; anything
   uncertain is flagged for review and nothing is invented.
5. Outputs: sidecar `annotations.json` (source SHA-256 keyed) and an annotated COPY that only adds
   `data-shine-*` attributes (verified reversible), so the existing v24 planner can consume it.

Nothing here knows about foxes, dragons or any specific path number.
"""
from __future__ import annotations

import argparse
import colorsys
import copy
import hashlib
import io
import json
import re
import sys
from collections import Counter
from pathlib import Path


def _cairosvg():
    """Ледачий імпорт: Cairo потрібна лише для SVG-шляху (на Windows її окремо ставлять)."""
    import cairosvg
    return cairosvg

import cv2
import numpy as np
from lxml import etree
from PIL import Image

THIS = Path(__file__).resolve().parent
V23 = THIS.parent / 'recovered_v27' / 'drawing_v24' / 'v23_lib'
sys.path.insert(0, str(V23))
from svg_scene import DRAWABLE, SVG_NS, load_svg, local, size_of  # noqa: E402

SCHEMA = 'shine.svg_annotations.v1'
RENDER_LONG_SIDE = 1600           # px; thresholds below are expressed relative to the canvas
THIN_FRAC = 0.0045                # a visible region narrower than 0.45% of the short side is "line-like"
SPECK_FRAC = 0.00004              # visible area below 0.004% of the canvas is a speck
DARK_LUM = 0.32
INK_LUM = 0.20                    # "майже чорний" для правила товстого контуру
LINE_W_MAX = 0.009                # середня товщина (частка короткої сторони), до якої темна форма = лінія
BACKGROUND_COVER = 0.45           # fraction of canvas the bottom-most light shape must visibly cover
UNSUPPORTED_ATTRS = ('opacity', 'fill-opacity', 'stroke-opacity', 'filter', 'mask', 'clip-path')


def _flat_paint(value):
    class _N:  # tiny adapter so _flat_fill can parse any colour string
        def __init__(self, v):
            self.v = v

        def get(self, k):
            return self.v
    return _flat_fill(_N(value))


def _flat_fill(node):
    """Return (r,g,b) for a flat rgb()/#hex fill, else None."""
    f = (node.get('fill') or '').strip()
    m = re.fullmatch(r'rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', f)
    if m:
        return tuple(int(x) for x in m.groups())
    m = re.fullmatch(r'#([0-9a-fA-F]{6})', f)
    if m:
        h = m.group(1)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = re.fullmatch(r'#([0-9a-fA-F]{3})', f)
    if m:
        return tuple(int(c * 2, 16) for c in m.group(1))
    return None


INHERIT = ('fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'fill-rule')


def _effective(node, attr, default=None):
    n = node
    while n is not None and isinstance(n.tag, str):
        v = n.get(attr)
        if v is not None:
            return v
        n = n.getparent()
    return default


def normalize(root):
    """Return a deep copy where every drawable has explicit paint and fill+stroke elements are split.

    A painted+stroked element renders as fill then stroke.  Splitting it into a fill-only element and a
    directly following stroke-only element is pixel-identical and lets the planner treat the stroke as
    outline ink and the fill as colour.  Done on a COPY only; equivalence is verified by `raster_equal`.
    """
    r = copy.deepcopy(root)
    for e in list(_drawables(r)):
        fill = _effective(e, 'fill', '#000000')
        stroke = _effective(e, 'stroke', 'none')
        for a in INHERIT:
            if a not in ('fill', 'stroke'):
                v = _effective(e, a)
                if v is not None:
                    e.set(a, v)
        e.set('fill', fill)
        e.set('stroke', stroke)
        if fill.strip().lower() != 'none' and stroke.strip().lower() != 'none':
            st = copy.deepcopy(e)
            st.set('fill', 'none')
            st.set('data-shine-split', 'stroke')
            e.set('stroke', 'none')
            e.set('data-shine-split', 'fill')
            e.addnext(st)
    return r


def _drawables(root):
    return [e for e in root.iter() if local(e.tag) in DRAWABLE and not any(
        local(p.tag) in {'defs', 'clipPath', 'mask', 'symbol', 'pattern', 'marker'} for p in e.iterancestors())]


def _id_map(root, nodes, W, H, viewbox=None):
    """Render every drawable in a unique flat colour, no anti-aliasing -> exact visible-owner map."""
    r2 = copy.deepcopy(root)
    for e in list(r2.iter()):
        if local(e.tag) in {'metadata', 'title', 'desc'}:
            e.getparent().remove(e)
    n2 = _drawables(r2)
    assert len(n2) == len(nodes)
    for i, e in enumerate(n2):
        n = i + 1
        col = f'rgb({(n >> 16) & 255},{(n >> 8) & 255},{n & 255})'
        if (e.get('fill') or '').strip().lower() == 'none' and (e.get('stroke') or 'none').strip().lower() != 'none':
            e.set('stroke', col)
        else:
            e.set('fill', col)
            e.set('stroke', 'none')
        e.set('shape-rendering', 'crispEdges')
        for a in ('opacity', 'fill-opacity', 'stroke-opacity', 'style'):
            if a in e.attrib:
                del e.attrib[a]
    r2.set('width', str(W))
    r2.set('height', str(H))
    if viewbox is not None:
        r2.set('viewBox', ' '.join(str(float(v)) for v in viewbox))
        r2.set('preserveAspectRatio', 'none')   # caller guarantees the aspect ratio matches
    else:
        r2.set('preserveAspectRatio', 'xMidYMid meet')
    png = _cairosvg().svg2png(bytestring=etree.tostring(r2), output_width=W, output_height=H)
    a = np.array(Image.open(io.BytesIO(png)).convert('RGBA'))
    n = (a[:, :, 0].astype(np.int64) << 16) | (a[:, :, 1].astype(np.int64) << 8) | a[:, :, 2].astype(np.int64)
    n[a[:, :, 3] < 128] = 0
    return n  # 0 = nothing painted, k = nodes[k-1]


def analyze(svg_path):
    svg_path = Path(svg_path)
    raw = svg_path.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    root0, _ = load_svg(svg_path)                # raises on unsafe input (fail-closed)
    vx, vy, vw, vh = size_of(root0)
    root = normalize(root0)
    scale = RENDER_LONG_SIDE / max(vw, vh)
    W, H = max(1, round(vw * scale)), max(1, round(vh * scale))
    nodes = _drawables(root)
    warnings = []
    for e in root.iter():
        for a in UNSUPPORTED_ATTRS:
            if a in e.attrib:
                warnings.append(f'attribute {a} on <{local(e.tag)}> is not modelled; element is sent to review')
                break
    ids = _id_map(root, nodes, W, H)
    canvas_px = W * H
    short = min(W, H)
    thin_w = THIN_FRAC * short
    items = []
    cover_of_light_bottom = None
    for i, e in enumerate(nodes):
        k = i + 1
        m = (ids == k)
        vis = int(m.sum())
        stroke_only = (e.get('fill') or '').strip().lower() == 'none' and (e.get('stroke') or 'none').strip().lower() != 'none'
        rgb = _flat_fill(e) if not stroke_only else _flat_paint(e.get('stroke'))
        feats = {'id': e.get('id'), 'stroke_only': stroke_only, 'index': i, 'tag': local(e.tag), 'fill': rgb, 'visible_px': vis,
                 'visible_frac': round(vis / canvas_px, 6)}
        review = []
        if rgb is None:
            review.append('non-flat or unrecognised paint (gradient/pattern/named colour)')
        elif any(a in e.attrib for a in UNSUPPORTED_ATTRS):
            review.append('opacity/filter/clip/mask not modelled')
        if vis:
            mu = m.astype(np.uint8)
            cs, _ = cv2.findContours(mu, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
            per = float(sum(cv2.arcLength(c, True) for c in cs)) or 1.0
            dist = cv2.distanceTransform(mu, cv2.DIST_L2, 3)
            ys, xs = np.where(m)
            k = int(round(thin_w)) | 1
            thick = cv2.morphologyEx(mu, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
            feats.update(thin_frac=round(1 - float(thick.sum()) / vis, 3))
            feats.update(components=len(cs), mean_width_px=round(2 * vis / per, 2),
                         max_width_px=round(float(dist.max()) * 2, 2),
                         bbox_px=[int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())])
        else:
            feats.update(components=0, mean_width_px=0.0, max_width_px=0.0, bbox_px=None)
        if rgb is not None:
            h, l, s = colorsys.rgb_to_hls(*[c / 255 for c in rgb])
            feats.update(lum=round(l, 3), sat=round(s, 3))
        feats['review'] = review
        items.append(feats)

    # --- role hypotheses -------------------------------------------------------------------
    for it in items:
        reasons = []
        role, conf = 'region', 0.7
        vis = it['visible_px']
        lum = it.get('lum')
        if it['review']:
            role, conf = 'unsupported', 0.0
            reasons.append('; '.join(it['review']))
        elif vis == 0:
            role, conf = 'hidden', 1.0
            reasons.append('fully covered by later shapes: nothing visible to draw')
        else:
            bb = it['bbox_px']
            covers = vis / canvas_px
            if it['stroke_only']:
                role, conf = 'ink_stroke', 0.95
                reasons.append('stroke-only element: an explicit pen line')
                it['role'], it['confidence'], it['reasons'] = role, conf, reasons
                continue
            spans = (bb[2] - bb[0] + 1) >= 0.95 * W and (bb[3] - bb[1] + 1) >= 0.95 * H
            if it['index'] == _first_visible_index(items) and spans and covers >= BACKGROUND_COVER and lum is not None and lum > 0.85:
                role, conf = 'paper', 0.9
                reasons.append(f'lowest visible shape, spans canvas, light ({covers:.0%} of canvas): treated as paper, not drawn')
            elif vis < SPECK_FRAC * canvas_px:
                role, conf = 'speck', 0.8
                reasons.append(f'visible area {vis}px is below speck threshold; drawn as a tiny dot or dropped by the planner')
            elif lum is not None and lum < DARK_LUM and it['thin_frac'] >= 0.5 and vis > 3 * thin_w:
                # An outline made by a dark under-layer peeking out around lighter shapes: most of its visible
                # pixels are narrower than a line.  Confidence grows with thinness share and darkness.
                dn = 1 - lum / DARK_LUM
                conf = round(min(0.95, 0.5 + 0.35 * it['thin_frac'] + 0.1 * dn), 2)
                role = 'ink_rim'
                reasons.append(f'dark (L={lum}); {it["thin_frac"]:.0%} of its visible pixels are line-thin '
                               f'(mean width {it["mean_width_px"]}px): outline from an under-layer')
                if it['thin_frac'] < 0.8:
                    it['review'].append('mixed: part line, part fill (thick pieces will be traced as outline)')
            elif (lum is not None and lum <= INK_LUM and it.get('sat', 1) < 0.5 and it['mean_width_px'] <= LINE_W_MAX * short
                  and vis > 3 * thin_w):
                # Масштабно-незалежне правило: майже чорна форма, що в середньому має товщину лінії (товстий контур
                # Dragon ~0.55% короткої сторони, а не 0.17% як у Fox). Чорні плями (зіниці) ширші -> лишаються заливкою.
                role, conf = 'ink_rim', 0.7
                reasons.append(f'near-black (L={lum}) with mean width {it["mean_width_px"]}px <= {LINE_W_MAX:.2%} of short side: '
                               f'a bold outline, not a blob')
                it['review'].append('bold outline detected by width rule (not by thin-pixel share)')
            else:
                reasons.append('visible area wider than a line: a fill region')
                conf = 0.8
                if lum is not None and lum < DARK_LUM and it['thin_frac'] >= 0.2:
                    conf = 0.5
                    it['review'].append('dark and partly line-thin: ink or shadow shape?')
        it['role'] = role
        it['confidence'] = conf
        it['reasons'] = reasons
    objects = _cluster_objects(items, ids)
    n_review = sum(1 for it in items if it['confidence'] < 0.6 or it['review'])
    paint_map = {'ink_rim': 'outline', 'ink_stroke': 'outline', 'region': 'color', 'speck': 'color', 'paper': 'paper', 'hidden': 'hidden'}
    for it in items:
        it['v24_paint'] = paint_map.get(it['role'])
    ann = {
        'schema': SCHEMA,
        'source': {'file': svg_path.name, 'sha256': sha, 'bytes': len(raw)},
        'canvas': {'viewBox': [vx, vy, vw, vh], 'raster': [W, H]},
        'thresholds': {'thin_px': round(thin_w, 2), 'speck_px': round(SPECK_FRAC * canvas_px, 1), 'dark_lum': DARK_LUM},
        'summary': {
            'drawables': len(items),
            'roles': dict(Counter(i['role'] for i in items)),
            'needs_review': n_review,
            'distinct_colors': len({i['fill'] for i in items if i['fill']}),
            'objects': len(objects),
        },
        'warnings': warnings,
        'items': [{k: v for k, v in it.items() if k != 'review'} | {'review': it['review']} for it in items],
        'objects': objects,
        'status': 'READY_WITH_REVIEW' if n_review else 'READY',
    }
    if any(i['role'] == 'unsupported' for i in items):
        ann['status'] = 'NEEDS_REVIEW'
    if not any(i['role'] == 'ink_rim' for i in items):
        ann['summary']['note_no_ink'] = ('no thin dark under-layer found: the planner must derive contours from region '
                                          'boundaries instead of ink shapes')
    return ann


def _first_visible_index(items):
    for it in items:
        if it['visible_px'] > 0:
            return it['index']
    return -1


def _cluster_objects(items, ids):
    """Group visible region shapes into touching clusters (connected components of adjacency).

    This is a *hypothesis* for the artist to confirm, not semantics: clusters are named c01.. and
    carry geometry only (bbox, member ids, dominant colours).
    """
    H, W = ids.shape
    n = len(items)
    parent = list(range(n + 1))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    paper = {i['index'] + 1 for i in items if i['role'] in {'paper', 'hidden', 'unsupported'}}
    for dy, dx in ((0, 1), (1, 0)):
        a = ids[:H - dy, :W - dx]
        b = ids[dy:, dx:]
        sel = (a != b) & (a > 0) & (b > 0)
        for x, y in set(zip(a[sel].tolist(), b[sel].tolist())):
            if x in paper or y in paper:
                continue
            parent[find(x)] = find(y)
    groups = {}
    for it in items:
        k = it['index'] + 1
        if k in paper or it['visible_px'] == 0:
            continue
        groups.setdefault(find(k), []).append(it)
    out = []
    for gi, (_, mem) in enumerate(sorted(groups.items(), key=lambda kv: -sum(m['visible_px'] for m in kv[1])), 1):
        xs0 = min(m['bbox_px'][0] for m in mem); ys0 = min(m['bbox_px'][1] for m in mem)
        xs1 = max(m['bbox_px'][2] for m in mem); ys1 = max(m['bbox_px'][3] for m in mem)
        cols = Counter(m['fill'] for m in mem if m['fill'])
        out.append({'cluster': f'c{gi:02d}', 'members': [m['id'] for m in mem], 'bbox_px': [xs0, ys0, xs1, ys1],
                    'visible_px': sum(m['visible_px'] for m in mem),
                    'dominant_fills': [list(c) for c, _ in cols.most_common(3)],
                    'confidence': 0.5,
                    'note': 'touching-shape cluster; semantic label unknown (UNKNOWN until confirmed by the artist)'})
    return out


def write_annotated_copy(svg_path, ann, out_svg):
    """Copy of the SVG that only ADDS data-shine-paint/role/conf attributes (+ stable ids)."""
    root0, _ = load_svg(svg_path)
    root = normalize(root0)
    nodes = _drawables(root)
    assert len(nodes) == len(ann['items'])
    for e, it in zip(nodes, ann['items']):
        if it['v24_paint']:
            e.set('data-shine-paint', it['v24_paint'])
        e.set('data-shine-role', it['role'])
        e.set('data-shine-conf', str(it['confidence']))
        e.set('data-shine-source-sha', ann['source']['sha256'][:16])
    Path(out_svg).write_bytes(etree.tostring(root, xml_declaration=False))
    return Path(out_svg)


def raster_equal(original_svg, annotated_svg, size=800, tol=2):
    """Equivalence proof: the annotated copy must render pixel-identically (within AA noise) to the source."""
    def r(p):
        png = _cairosvg().svg2png(url=str(p), output_width=size)
        return np.array(Image.open(io.BytesIO(png)).convert('RGBA')).astype(np.int16)
    a, b = r(original_svg), r(annotated_svg)
    if a.shape != b.shape:
        return False, None
    d = np.abs(a - b).max(axis=2)
    return bool((d > 40).sum() <= tol), int((d > 40).sum())


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('svg', type=Path)
    ap.add_argument('--output', type=Path, required=True, help='directory for annotations.json and annotated copy')
    a = ap.parse_args(argv)
    a.output.mkdir(parents=True, exist_ok=True)
    ann = analyze(a.svg)
    (a.output / 'annotations.json').write_text(json.dumps(ann, indent=1), encoding='utf-8')
    prepared = write_annotated_copy(a.svg, ann, a.output / (a.svg.stem + '.prepared.svg'))
    ok, ndiff = raster_equal(a.svg, prepared)
    print(json.dumps({'status': ann['status'], 'summary': ann['summary'], 'render_identical_to_source': ok, 'pixels_differing': ndiff}, indent=1))
    return 0 if ok else 2


if __name__ == '__main__':
    raise SystemExit(main())
