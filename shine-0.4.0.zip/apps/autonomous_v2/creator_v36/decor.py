#!/usr/bin/env python3
"""Decor v1 - спрайти-декор (зірки, серця, метелик, ноти) з AI-листа на білому тлі + ефекти поверх готової сцени.

Принцип: декор не торкається персонажа (малюється ПОВЕРХ у вільних зонах паперу), тому не залежить від точності AI.
  cut_sprites(sheet_bgr)  -> {id: RGBA-спрайт} (альфа з білого тла, отвори заповнені, обрізано по габариту)
  Decor(sprites, free, events, size) ; Decor.draw(img_uint8, t) -> img
  події: pop (виринає з "пружиною", пливе вгору, згасає), fly (метелик літає по кривій, махає крилами)
"""
from __future__ import annotations

import math

import cv2
import numpy as np
from scipy import ndimage


def cut_sprites(sheet, names=("star", "heart", "butterfly", "butterfly_side", "sparkle", "note")):
    """Лист 2x3 -> спрайти. Порядок як у листі: ряд1 star, heart, butterfly; ряд2 butterfly_side, sparkle, note."""
    g = sheet.min(2)
    nz = g < 236
    nz = cv2.morphologyEx(nz.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))).astype(bool)
    lab, n = ndimage.label(cv2.dilate(nz.astype(np.uint8), np.ones((15, 15), np.uint8)))
    comps = []
    for i in range(1, n + 1):
        ys, xs = np.nonzero((lab == i) & nz)
        if len(xs) < 4000:
            continue
        comps.append((ys.min(), xs.min(), i))
    H = sheet.shape[0]
    top = sorted([c for c in comps if c[0] < H * 0.45], key=lambda c: c[1])
    bot = sorted([c for c in comps if c[0] >= H * 0.45], key=lambda c: c[1])
    ordered = top + bot
    out = {}
    for name, (_, _, i) in zip(names, ordered):
        m = (lab == i)
        ys, xs = np.nonzero(m)
        pad = 6
        y0, y1, x0, x1 = max(ys.min() - pad, 0), min(ys.max() + pad + 1, sheet.shape[0]), max(xs.min() - pad, 0), min(xs.max() + pad + 1, sheet.shape[1])
        crop = sheet[y0:y1, x0:x1]
        solid = ndimage.binary_fill_holes(nz[y0:y1, x0:x1] & m[y0:y1, x0:x1])
        a = cv2.GaussianBlur(solid.astype(np.float32), (0, 0), 0.9)
        rgb = crop.copy()
        # у кромці колір = чорний контур (кромка завжди чорна)
        edge = (a > 0.02) & (a < 0.98)
        rgb[edge & ~(crop.min(2) < 120)] = (14, 12, 12)
        out[name] = np.dstack([rgb, (a * 255).astype(np.uint8)])
    return out


def _ease_out_back(u, s=1.9):
    u = min(max(u, 0.0), 1.0) - 1.0
    return 1 + (s + 1) * u ** 3 + s * u ** 2


def _blit(img, spr, cx, cy, scale=1.0, rot=0.0, sx=1.0, alpha=1.0):
    """RGBA-спрайт у (cx,cy) з масштабом, поворотом (градуси) і ростягом по X (змах крил)."""
    h, w = spr.shape[:2]
    if scale <= 0.01 or alpha <= 0.01:
        return img
    M = cv2.getRotationMatrix2D((w / 2, h / 2), rot, scale)
    M[0, :] *= sx
    M[0, 2] += (1 - sx) * 0 + 0
    # центр у (cx,cy)
    M[0, 2] += cx - w / 2 * sx - (M[0, 0] * 0)
    M[1, 2] += cy - h / 2
    # переобчислення: точка центру спрайта мусить потрапити у (cx,cy)
    c = M @ np.array([w / 2, h / 2, 1.0])
    M[0, 2] += cx - c[0]
    M[1, 2] += cy - c[1]
    H, W = img.shape[:2]
    pm = spr.astype(np.float32).copy()
    pm[..., :3] *= pm[..., 3:4] / 255.0
    warped = cv2.warpAffine(pm, M, (W, H), flags=cv2.INTER_LINEAR, borderValue=(0, 0, 0, 0))
    a = (warped[..., 3:4] / 255.0) * alpha
    pre = warped[..., :3] * alpha
    return img * (1 - a) + pre


class Decor:
    """events: список dict(kind='pop'|'fly', sprite, t0, dur, p=(x,y), ...). free: булева карта вільного паперу (з відступом)."""

    def __init__(self, sprites, events, size, fps=30):
        self.spr = sprites
        self.ev = events
        self.W, self.H = size

    @staticmethod
    def place(free, n, rng, min_dist=150, region=None, tries=4000):
        """n точок на вільному папері (free), не ближче min_dist одна до одної; region=(x0,y0,x1,y1) додатково."""
        ys, xs = np.nonzero(free)
        if region is not None:
            k = (xs >= region[0]) & (xs <= region[2]) & (ys >= region[1]) & (ys <= region[3])
            ys, xs = ys[k], xs[k]
        pts = []
        for _ in range(tries):
            if len(pts) >= n or len(xs) == 0:
                break
            j = rng.integers(len(xs))
            p = (int(xs[j]), int(ys[j]))
            if all((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 >= min_dist ** 2 for q in pts):
                pts.append(p)
        return pts

    def draw(self, out, t):
        img = out.astype(np.float32)
        for e in self.ev:
            u = (t - e['t0']) / e['dur']
            if u < 0 or u > 1:
                continue
            spr = self.spr[e['sprite']]
            if e['kind'] == 'pop':
                x, y = e['p']
                grow = _ease_out_back(min(u / 0.28, 1.0))
                fade = 1.0 if u < 0.7 else max(0.0, 1.0 - (u - 0.7) / 0.3)
                rise = e.get('rise', 70) * u
                sway = math.sin(u * math.pi * 2 * e.get('sway', 1.0) + e.get('ph', 0.0)) * e.get('swing', 6.0)
                img = _blit(img, spr, x + 10 * math.sin(u * 5 + e.get('ph', 0.0)), y - rise, e.get('scale', 0.5) * grow, sway, 1.0, fade)
            elif e['kind'] == 'fly':
                pts = e['path']
                f = u * (len(pts) - 1)
                i = min(int(f), len(pts) - 2)
                a, b = np.array(pts[i], float), np.array(pts[i + 1], float)
                p = a + (b - a) * (f - i)
                flap = 0.3 + 0.7 * abs(math.cos(2 * math.pi * e.get('flap', 3.2) * (t - e['t0'])))
                fade = min(1.0, u / 0.08, (1 - u) / 0.08)
                wob = 4.0 * math.sin(2 * math.pi * 1.7 * (t - e['t0']))
                img = _blit(img, spr, p[0], p[1] + wob, e.get('scale', 0.45), wob * 1.5, flap, fade)
        return np.clip(img, 0, 255).astype(np.uint8)
