# usage: run_fox_full.py full  (шляхи до приватних ассетів/аудіо - у змінній A та audio-аргументі; не комітяться)
import sys, json, time, pickle
sys.path.insert(0,'/home/claude/shine-drawing-engine/apps/autonomous_v2/creator_v36')
import cv2
import planner as pl, svg_prepare as sp, render as rd, story as st, numpy as np
svg='/home/claude/shine-drawing-engine/apps/autonomous_v2/prepare_v36/fixtures/recraft_fox_original.svg'
ann=sp.analyze(svg)
members=[m for o in ann['objects'] for m in o['members']]
sc=pl.Scene(svg,ann,members,target_box=(330,60,1250,660))
idx={m['id']:i for i,m in enumerate(sc.members)}
bf_ids=[o for o in ann['objects'] if o['cluster']=='c04'][0]['members']
EYES=[['shine_el_057','shine_el_058','shine_el_059'],['shine_el_061','shine_el_062','shine_el_063']]
def build(base):
    eyes=[st.Eye(base,[sc.mask(idx[i]) for i in g]) for g in EYES]
    body=np.zeros(base.shape[:2],bool); wing=body.copy()
    for i in bf_ids:
        m=sc.members[idx[i]]; mk=sc.mask(idx[i])
        if tuple(m['fill'])==(43,71,81): body|=mk
        else: wing|=mk
    allm=wing|body
    body=cv2.dilate(body.astype(np.uint8),np.ones((3,3),np.uint8),iterations=2).astype(bool)&allm
    wing=allm&~body
    return eyes, st.Butterfly(base,wing,body)
story=st.StoryEvents(build)
plan=pickle.load(open('/home/claude/work/out/fox_plan.pkl','rb'))
A='/home/claude/work/handoff01/04_GOLDEN_REFERENCE/dragon_v21_golden_source/overhead_assets_v11'
mode=sys.argv[1] if len(sys.argv)>1 else 'full'
if mode=='story_only':   # швидка перевірка подій на еталоні
    base=np.ascontiguousarray(sc.ref[:,:,::-1]); story.frame(0,base)
    import cv2
    for k,t in enumerate([0.9+0.13,2.3,3.1,3.9,5.4]):
        i=int(t*60); cv2.imwrite(f'/home/claude/work/out/story_{k}.png',story.frame(i,base))
    print('ok',story.frames)
if mode=='full':
    t=time.time()
    qa,_=rd.render_video(sc,plan,'/home/claude/work/out/fox_full_story',A,'/home/claude/work/handoff01/04_GOLDEN_REFERENCE/audio',pace=1.0,story=story)
    print(json.dumps(qa,indent=1)); print('render s',round(time.time()-t))
