#!/usr/bin/env python3
"""Puppet v3 - оживлення готового малюнка (без ШІ-відео, без розмітки), працює від самого кадру (BGR).

  * limbs.py: автоматичні кінцівки за силуетом + «м'який шарнір» (inverse warp, дірок немає, лапа поверх тіла);
  * wave: піднята лапа/крило, tail: хвіст із запізненням (follow-through); амплітуда обмежена fail-closed
    безпечним кутом (окремо в кожен бік);
  * blink: око разом з обводкою стискається до лінії повіки;
  * breathe: ледь помітне дихання (масштаб відносно «ніг»).
Інтерфейс: PuppetShow(scene=None, cfg, fps).frames ; .frame(i, canvas_bgr) -> bgr ; .report.
"""
from __future__ import annotations

import math

import cv2
import numpy as np
from scipy import ndimage

import limbs as LB

DEFAULT = dict(seconds=6.0, blink_times=[0.7, 3.9], pack=None, laugh=None, smile=None, wave=dict(start=0.9, end=4.6, cycles=3.0, deg=8.0),
               tail=dict(start=1.3, end=5.2, cycles=2.0, deg=7.0, delay=0.18), breathe=dict(amp=0.008, hz=0.36),
               bounce_end=True, blink=True)


def _ease(u):
    u = float(np.clip(u, 0., 1.))
    return u * u * (3. - 2. * u)


def _blink_profile(t, t0, dur=0.28):
    u = (t - t0) / dur
    if u < 0 or u > 1:
        return 0.0
    return _ease(u * 2) if u < 0.5 else _ease((1 - u) * 2)


def swing(t, cfg, delay=0.0):
    """Нормований рух [-1, 1]: anticipation, загасаючі хитання, settle."""
    t = t - delay
    if t < cfg['start'] or t > cfg['end']:
        return 0.0, 0.0
    u = (t - cfg['start']) / (cfg['end'] - cfg['start'])
    env = math.sin(math.pi * min(1.0, u * 1.15)) ** 0.8 if u < 0.87 else max(0.0, (1 - u) / 0.13) ** 2 * 0.4
    return env, math.sin(2 * math.pi * cfg['cycles'] * u + 0.4)


def win(t, cfg):
    """Вікно з плавним входом/виходом: 0..1."""
    if not cfg:
        return 0.0
    r = cfg.get('ramp', 0.15)
    return _ease((t - cfg['start']) / r) * _ease((cfg['end'] - t) / r)


def _cy(m):
    return float(np.nonzero(m)[0].mean())


class PuppetShow:
    def __init__(self, scene=None, cfg=None, fps=60):
        c = dict(DEFAULT)
        c.update(cfg or {})
        self.cfg, self.fps = c, fps
        self.frames = int(round(c['seconds'] * fps))
        self.built = False
        self.report = {}
        self.eyes, self.hinges = [], []

    # ---- побудова ---------------------------------------------------------------------------------
    def _build(self, canvas):
        H, W = canvas.shape[:2]
        L, S, bg = LB.find_limbs(canvas)
        self.S = S
        ys, xs = np.nonzero(S)
        self.fig_c = (float(xs.mean()), float(ys.mean()))
        self.fig_top, self.fig_bot = float(ys.min()), float(ys.max())
        self.fig_bottom = (float(np.median(xs[ys > np.percentile(ys, 92)])), float(ys.max()))
        self.report['limbs_found'] = len(L)
        total = float(S.sum())
        if self.cfg.get('blink', True):
            self.eyes = self._find_eyes(canvas, S, bg)
        keep = None
        if self.eyes:
            keep = np.zeros(S.shape, bool)
            x0 = min(e['x0'] for e in self.eyes); x1 = max(e['x1'] for e in self.eyes)
            y0 = min(e['y0'] for e in self.eyes); y1 = max(e['y1'] for e in self.eyes)
            ew = max(e['x1'] - e['x0'] for e in self.eyes)
            keep[max(0, y0 - int(0.6 * ew)):y1 + int(1.9 * ew), max(0, x0 - int(0.6 * ew)):x1 + int(0.6 * ew)] = True
        self.keepout = keep
        used = []
        wave = self._pick_wave(L, total) if self.cfg.get('limbs', True) else None
        if keep is not None:
            # зона обличчя = лише пікселі ТІЛА (не папір поза головою і не сама рука), інакше лапа збоку голови вважається "на обличчі"
            keep = keep & S & (~wave.mask if wave is not None else True)
            self.keepout = keep
        if wave is not None:
            used.append(('wave', wave))
        tail = self._pick_tail(L, total, wave) if self.cfg.get('limbs', True) else None
        if tail is not None:
            used.append(('tail', tail))
        for role, l in used:
            hw = LB.HingeWarp(canvas, l, S)
            hw.keepout = self.keepout
            hw.front = (role != 'tail')
            tgt = self.cfg[role]['deg']
            sp, sn = hw.safe_angle(tgt, 1), hw.safe_angle(tgt, -1)
            self.report[role] = dict(pivot=[round(l.pivot[0], 1), round(l.pivot[1], 1)], area=int(l.mask.sum()),
                                     safe_pos=sp, safe_neg=sn, enabled=bool(sp + sn >= 3.0))
            if sp + sn >= 3.0:
                self.hinges.append((role, hw, sp, sn))
        # помах КИСТЮ навколо зап'ястя: набагато більший безпечний кут, ніж у всієї руки -> замінює 'wave'
        if wave is not None and self.cfg.get('hand_wave', True):
            hl = LB.split_hand(wave)
            if hl is not None:
                self.cfg.setdefault('hand', dict(self.cfg['wave'], deg=14.0))
                hh = LB.HingeWarp(canvas, hl, S)
                hh.keepout = self.keepout
                hh.front = True
                tgt = self.cfg['hand']['deg']
                sp, sn = hh.safe_angle(tgt, 1), hh.safe_angle(tgt, -1)
                en = bool(sp + sn >= 8.0)
                self.report['hand'] = dict(pivot=[round(hl.pivot[0], 1), round(hl.pivot[1], 1)], area=int(hl.mask.sum()),
                                           safe_pos=sp, safe_neg=sn, enabled=en)
                if en:
                    self.hinges = [h for h in self.hinges if h[0] != 'wave']
                    self.hinges.append(('hand', hh, sp, sn))
        self.built = True

    def _pick_wave(self, L, total):
        c = []
        for l in L:
            a = l.mask.sum() / total
            if 0.012 <= a <= 0.14 and l.axis[1] < -0.25 and l.pivot[1] < self.fig_c[1] + 0.2 * (self.S.shape[0]):
                c.append(l)
        return max(c, key=lambda l: l.score) if c else None

    def _pick_tail(self, L, total, wave):
        c = []
        for l in L:
            a = l.mask.sum() / total
            if l is wave or not (0.008 <= a <= 0.32) or (l.axis[1] < -0.25 and l.pivot[1] < self.fig_c[1]):
                continue
            if abs(l.axis[0]) < 0.5:
                continue
            tipx = l.pivot[0] + l.axis[0] * l.length
            xs_ = np.nonzero(self.S.any(0))[0]
            fw = xs_.max() - xs_.min()
            if not (tipx < xs_.min() + 0.14 * fw or tipx > xs_.max() - 0.14 * fw):
                continue
            if wave is not None and np.hypot(l.pivot[0] - wave.pivot[0], l.pivot[1] - wave.pivot[1]) < 60:
                continue
            c.append(l)
        return max(c, key=lambda l: l.score) if c else None

    # ---- очі --------------------------------------------------------------------------------------
    def _find_eyes(self, canvas, S, bg):
        """Універсальні очі: (A) білок (замкнена біла пляма) із зіницею; (B) суцільно чорні очі з відблиском.
        Усі межі відносні до фігури, тож однаково працює для листа, кропа й сцени. Fail-closed: немає зіниці -> немає ока."""
        ink = canvas.max(2) < 72
        paper = (canvas.min(2) >= 235) & ~bg
        H, W = ink.shape
        figA = float(S.sum())
        lw = max(3, int(round(np.median(ndimage.distance_transform_edt(ink)[ink]) * 2))) if ink.any() else 5
        il, nil = ndimage.label(ink)
        ink_area = np.bincount(il.ravel(), minlength=nil + 1)
        nbg = cv2.dilate(bg.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
        lab, n = ndimage.label(paper)

        def build(E, ha, kind):
            r = int(round(2.3 * lw)) + 1
            E = cv2.dilate(E.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1,) * 2)).astype(bool)
            touch = np.unique(il[E & ink])
            touch = np.array([t for t in touch if t > 0 and ink_area[t] <= max(6 * ha, 3000)], int)   # брови/вії - так; великий контур фігури - ні
            far = cv2.dilate(E.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * 3 * lw + 1,) * 2)).astype(bool)
            E |= np.isin(il, touch) & far & ~nbg
            E = cv2.dilate(E.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) & ~nbg
            ring = cv2.dilate(E.astype(np.uint8), np.ones((15, 15), np.uint8)).astype(bool) & ~E & ~ink & ~paper & ~bg
            if ring.sum() < 20:
                return None
            if int(E.sum()) > 5 * ha + 4000:
                return None                                # маска розрослась - не око (fail-closed)
            ey, ex = np.nonzero(E)
            y0, y1, x0, x1 = max(ey.min() - 40, 0), min(ey.max() + 41, H), max(ex.min() - 40, 0), min(ex.max() + 41, W)
            # заливка під повіку: найближчий "чистий" колір навколо (а не один середній), тому на межі двох кольорів без плями
            inv = E[y0:y1, x0:x1] | cv2.dilate(ink[y0:y1, x0:x1].astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) | paper[y0:y1, x0:x1]
            idx = ndimage.distance_transform_edt(inv, return_distances=False, return_indices=True)
            fill = np.zeros((H, W, 3), np.float32)
            fill[y0:y1, x0:x1] = canvas[y0:y1, x0:x1][idx[0], idx[1]]
            col = np.median(canvas[ring], axis=0)
            near_ip = cv2.dilate((ink | paper).astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool)
            skin = np.abs(canvas.astype(np.int16) - col.astype(np.int16)).sum(2) < 40
            fm = E & (near_ip | skin)
            return dict(pa=int(E.sum()), mask=E, fm=fm, col=col, fill=fill, y0=int(ey.min()), y1=int(ey.max()),
                        x0=int(ex.min()), x1=int(ex.max()), lw=lw, kind=kind)

        eyes = []
        k_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (max(3, int(1.2 * lw)) | 1,) * 2)
        for j in range(1, n + 1):
            comp = lab == j
            ys, xs = np.nonzero(comp)
            a = len(ys)
            if a < 60 or a > 0.12 * figA:
                continue
            hull = cv2.convexHull(np.stack([xs, ys], 1).astype(np.int32))
            Hm = np.zeros((H, W), np.uint8)
            cv2.fillConvexPoly(Hm, hull, 1)
            E = Hm.astype(bool)
            ha = int(E.sum())
            if float((comp | ink)[E].sum()) / ha < 0.85 or not (0.4 <= (np.ptp(xs) + 1) / (np.ptp(ys) + 1) <= 2.5):
                continue                                   # склера - опукла овальна пляма (не тіло ракети з крапками)
            inh = E & ink
            if float(inh.sum()) / ha < 0.12 or _cy(E) > self.fig_top + 0.66 * (self.fig_bot - self.fig_top):
                continue
            pup = cv2.morphologyEx(inh.astype(np.uint8), cv2.MORPH_OPEN, k_open)
            if pup.sum() < 0.10 * ha:
                continue                                   # немає товстої зіниці (вікно з хрестовиною, ґрати)
            pl, pn = ndimage.label(pup)
            pbest = max(range(1, pn + 1), key=lambda i: (pl == i).sum())
            py_, px_ = np.nonzero(pl == pbest)
            ph, pw = int(np.ptp(py_)) + 1, int(np.ptp(px_)) + 1
            ph_hull = cv2.contourArea(cv2.convexHull(np.stack([px_, py_], 1).astype(np.int32))) + 1
            if (pl == pbest).sum() / ph_hull < 0.8 or not (0.5 <= pw / ph <= 2.0):
                continue                                   # зіниця має бути суцільною округлою плямою (не кільце, не хрестовина)
            e = build(E, ha, 'sclera')
            if e:
                eyes.append(e)
        if not eyes:                                       # (B) суцільно чорні очі: світлий відблиск, оточений чорним
            for j in range(1, n + 1):
                comp = lab == j
                a = int(comp.sum())
                if a < 25 or a > 0.01 * figA:
                    continue
                ring = cv2.dilate(comp.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))).astype(bool) & ~comp
                if float((ring & ink).sum()) / max(1, ring.sum()) < 0.8:
                    continue
                ids = il[ring & ink]
                ids = ids[ids > 0]
                if len(ids) == 0:
                    continue
                blob = il == np.bincount(ids).argmax()
                ba = int(blob.sum())
                if ba < 250 or ba > 0.12 * figA:
                    continue
                ys, xs = np.nonzero(blob)
                hull = cv2.convexHull(np.stack([xs, ys], 1).astype(np.int32))
                Hm = np.zeros((H, W), np.uint8)
                cv2.fillConvexPoly(Hm, hull, 1)
                if ba / max(1, int(Hm.sum())) < 0.8 or _cy(Hm.astype(bool)) > self.fig_top + 0.66 * (self.fig_bot - self.fig_top):
                    continue
                if any(Hm[int(e['y0'] + 1):int(e['y1']), int(e['x0'] + 1):int(e['x1'])].any() for e in eyes):
                    continue
                e = build(Hm.astype(bool), int(Hm.sum()), 'solid')
                if e:
                    eyes.append(e)
        eyes.sort(key=lambda e: -e['pa'])
        keep = []
        for e in eyes:
            if not keep:
                keep.append(e)
                continue
            a = keep[0]
            sa, sb = (a['x1'] - a['x0']) * (a['y1'] - a['y0']), (e['x1'] - e['x0']) * (e['y1'] - e['y0'])
            aw = a['x1'] - a['x0']
            far = all(abs((e['x0'] + e['x1']) - (k['x0'] + k['x1'])) / 2 > 0.6 * aw or abs((e['y0'] + e['y1']) - (k['y0'] + k['y1'])) / 2 > 0.6 * aw for k in keep)
            near = np.hypot((e['x0'] + e['x1'] - a['x0'] - a['x1']) / 2, (e['y0'] + e['y1'] - a['y0'] - a['y1']) / 2) < 4.5 * aw
            if len(keep) < 6 and sb > 0.4 * sa and far and near:
                keep.append(e)
        self.report['eyes'] = len(keep)
        return keep

    # ---- кадр -------------------------------------------------------------------------------------
    def pose(self, t):
        """Кути кінцівок у момент t (градуси): асиметричні межі безпечних кутів."""
        out = {}
        for role, hw, sp, sn in self.hinges:
            cfg = self.cfg[role]
            env, osc = swing(t, cfg, cfg.get('delay', 0.0))
            mid, half = (sp - sn) / 2.0, min(cfg['deg'], (sp + sn) / 2.0)
            out[role] = env * (mid + half * osc)
        return out

    def frame(self, i, canvas):
        if not self.built:
            self._build(canvas)
        t = i / self.fps
        c = self.cfg
        H, W = canvas.shape[:2]
        img = canvas
        for role, ang in self.pose(t).items():
            if abs(ang) > 1e-3:
                hw = [h for h in self.hinges if h[0] == role][0][1]
                hw.img = img
                img = hw.render(ang)
        img = img.astype(np.float32)
        for e in self.eyes:
            p = max((_blink_profile(t, t0) for t0 in c['blink_times']), default=0.0)
            if p <= 0:
                continue
            h = e['y1'] - e['y0']
            ylid = e['y0'] + 0.68 * h
            img[e['fm']] = e['fill'][e['fm']]
            sq = 1.0 - p
            fade = float(np.clip((sq - 0.10) / 0.15, 0, 1))
            if fade > 0:
                M = np.float32([[1, 0, 0], [0, sq, ylid * (1 - sq)]])
                wc = cv2.warpAffine(canvas, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE).astype(np.float32)
                wm = cv2.warpAffine(e['mask'].astype(np.uint8) * 255, M, (W, H), flags=cv2.INTER_LINEAR).astype(np.float32)[:, :, None] / 255.0 * fade
                img = img * (1 - wm) + wc * wm
            if fade < 1 and not (c.get('pack') and 'blink' in c['pack']):
                xm = (e['x0'] + e['x1']) / 2
                wid = (e['x1'] - e['x0']) * 0.8
                pts = np.array([[xm + (q / 16 - 0.5) * wid, ylid + 0.12 * h * (1 - (2 * (q / 16 - 0.5)) ** 2)] for q in range(17)], np.float32)
                tmp = np.zeros((H, W), np.uint8)
                cv2.polylines(tmp, [np.rint(pts * 8).astype(np.int32).reshape(-1, 1, 2)], False, 255, max(3, int(e['lw'] * 0.9)), cv2.LINE_AA, shift=3)
                a = (tmp.astype(np.float32) / 255.0)[:, :, None] * (1.0 - fade)
                img = img * (1 - a) + np.array([16, 12, 12], np.float32) * a
        pk = c.get('pack') or {}
        lw_ = win(t, c.get('laugh')) if 'laugh' in pk else 0.0
        sw_ = win(t, c.get('smile')) if 'smile' in pk else 0.0
        su_ = win(t, c.get('surprise')) if 'surprise' in pk else 0.0
        if 'blink' in pk and lw_ < 0.05 and su_ < 0.05:
            p_ = max((_blink_profile(t, t0) for t0 in c['blink_times']), default=0.0)
            if p_ > 0:
                img = pk['blink'].apply(img, _ease((p_ - 0.45) / 0.4))
        if lw_ > 0:
            img = pk['laugh'].apply(img, lw_)
        if sw_ > 0:
            img = pk['smile'].apply(img, sw_)
        if su_ > 0:
            img = pk['surprise'].apply(img, su_)
        out = np.clip(img, 0, 255).astype(np.uint8)
        br = c.get('breathe')
        if br:
            ramp = min(1.0, t / 0.8) * min(1.0, (c['seconds'] - t) / 0.8)
            s_ = 1.0 + br['amp'] * ramp * (0.5 + 0.5 * math.sin(2 * math.pi * br['hz'] * t - math.pi / 2))
            bounce = -4.0 * lw_ * abs(math.sin(2 * math.pi * 3.2 * t))
            if c.get('bounce_end') and t > c['seconds'] - 1.0:
                u = (t - (c['seconds'] - 1.0)) / 1.0
                bounce = -10.0 * math.sin(math.pi * u) * (1 - u)
            bx, by = self.fig_bottom
            M = np.float32([[s_, 0, bx * (1 - s_)], [0, s_, by * (1 - s_) + bounce]])
            out = cv2.warpAffine(out, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
        if c.get('decor') is not None:
            out = c['decor'].draw(out, t)      # декор поверх сцени у вільних зонах паперу
        return out
