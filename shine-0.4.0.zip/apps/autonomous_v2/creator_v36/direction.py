"""Режисура контуру: об'єктно-орієнтований порядок штрихів (замість «найближчий сусід по всій картинці»).

1. Штрихи групуються просторово (ward по центроїдах, n груп - параметр direction.ink_groups; за замовчуванням ~ за довжиною).
2. Перша група - та, що містить найдовший (силует) штрих і лежить ближче до центру ваги; далі найближча за центроїдом.
3. Усередині групи: спершу найдовші замкнені лінії (силует), далі найближчий сусід від пера.
Усе перекривається `direction` (sidecar): {"ink_groups": N, "group_order": [i,...]}.
"""
import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage


def _pl(p):
    return float(np.hypot(*np.diff(p, axis=0).T).sum()) if len(p) > 1 else 0.0


def order_ink(strokes, direction=None, order_strokes=None):
    direction = direction or {}
    if len(strokes) < 4:
        return order_strokes(strokes, None, True, True)
    cen = np.array([np.mean(s['pts'], axis=0) for s in strokes])
    total = sum(_pl(s['pts']) for s in strokes)
    n = int(direction.get('ink_groups') or max(3, min(9, round(total / 900))))
    n = min(n, len(strokes))
    lab = fcluster(linkage(cen, 'ward'), n, 'maxclust')
    groups = {}
    for s, g in zip(strokes, lab):
        groups.setdefault(int(g), []).append(s)
    gc = {g: np.mean([np.mean(s['pts'], axis=0) for s in ss], axis=0) for g, ss in groups.items()}
    gl = {g: sum(_pl(s['pts']) for s in ss) for g, ss in groups.items()}
    cm = np.average(cen, axis=0, weights=[_pl(s['pts']) + 1 for s in strokes])
    if direction.get('group_order'):
        order = [g for g in direction['group_order'] if g in groups] + [g for g in groups if g not in direction['group_order']]
    else:
        # старт: найбільша група з найкоротшою відстанню до центру ваги (голова/основний об'єкт)
        first = max(groups, key=lambda g: gl[g] / (1.0 + np.hypot(*(gc[g] - cm)) / 150.0))
        order, cur = [first], gc[first]
        left = set(groups) - {first}
        while left:
            nxt = min(left, key=lambda g: np.hypot(*(gc[g] - cur)))
            order.append(nxt)
            left.remove(nxt)
            cur = gc[nxt]
    out, tip = [], None
    for g in order:
        seq = order_strokes(groups[g], start=tip, allow_reverse=True, big_first=tip is None)
        out += seq
        tip = seq[-1]['pts'][-1]
    return out


# ======================================================================================================
# Логічні групи (частини об'єкта) і послідовність «об'єкт за об'єктом»: контур -> деталі -> заливка
# ======================================================================================================
import cv2
from scipy import ndimage


def _rgb(c):
    return 'rgb(%d,%d,%d)' % tuple(c)


def build_groups(scene, cfg=None):
    """Групи = кореневі кольорові області + все, що в них «вкладене» (очі, ніс, щічки, внутрішнє вухо, пальці).
    Повертає (group_of_member {member_index: gid}, near_group image, groups list)."""
    cfg = cfg or {}
    members, ids = scene.members, scene.ids
    H, W = ids.shape
    reg = [i for i, m in enumerate(members) if m['role'] == 'region' and m['visible_px'] > 0]
    ink = np.zeros(ids.shape, bool)
    paper = np.zeros(ids.shape, bool)
    for i, m in enumerate(members):
        if m['role'] in ('ink_rim', 'ink_stroke'):
            ink |= ids == i + 1
        elif m['role'] == 'paper':
            paper |= ids == i + 1
    area = {i: members[i]['visible_px'] for i in reg}
    parent = {i: i for i in reg}
    r = int(cfg.get('contain_radius', 14))
    el = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    for i in sorted(reg, key=lambda k: area[k]):
        m = ids == i + 1
        ring = cv2.dilate(m.astype(np.uint8), el).astype(bool) & ~m & ~ink & ~paper
        if ring.sum() < 8:
            continue
        cnt = np.bincount(ids[ring], minlength=len(members) + 1)
        cnt[i + 1] = 0
        top = int(cnt.argmax())
        if top == 0 or top - 1 not in area:
            continue
        if cnt[top] / max(1, cnt.sum()) >= 0.8 and area[i] < cfg.get('contain_ratio', 0.35) * area[top - 1]:
            parent[i] = top - 1

    def root(i):
        while parent[i] != i:
            i = parent[i]
        return i
    gid_of_root = {}
    gm = {}
    for i in reg:
        rt = root(i)
        gm[i] = gid_of_root.setdefault(rt, len(gid_of_root))
    G = np.zeros(ids.shape, np.int32)
    for i in reg:
        G[ids == i + 1] = gm[i] + 1
    if G.max() == 0:
        return gm, G, []
    max_groups = int(cfg.get('max_groups', 8))
    min_frac = cfg.get('min_group_frac', 0.012)
    while True:
        near = _near(G)
        ids_g = sorted({int(v) for v in np.unique(G) if v})
        gar = {g: int((G == g).sum()) for g in ids_g}
        total = sum(gar.values())
        smallest = min(ids_g, key=lambda g: gar[g])
        if len(ids_g) <= 1 or (len(ids_g) <= max_groups and gar[smallest] >= min_frac * total):
            break
        adj = _adjacency(near, max(ids_g))
        nb = {h: v for h, v in adj.get(smallest, {}).items() if h != smallest}
        if not nb:
            break
        tgt = max(nb, key=nb.get)
        G[G == smallest] = tgt
        for i in list(gm):
            if gm[i] + 1 == smallest:
                gm[i] = tgt - 1
    uniq = sorted({gm[i] for i in gm})
    new = {g: n for n, g in enumerate(uniq)}
    gm = {i: new[g] for i, g in gm.items()}
    G = np.zeros(ids.shape, np.int32)
    for i in reg:
        G[ids == i + 1] = gm[i] + 1
    near = _near(G)
    groups = []
    for g in range(len(uniq)):
        mem = [i for i in reg if gm[i] == g]
        ys, xs = np.nonzero(G == g + 1)
        groups.append(dict(id=g, members=[members[i]['id'] for i in mem], n_members=len(mem),
                           area=int(len(ys)), centre=[float(xs.mean()), float(ys.mean())] if len(ys) else [0, 0],
                           colors=sorted({_rgb(members[i]['fill']) for i in mem})))
    return gm, near, groups


def _near(G):
    idx = ndimage.distance_transform_edt(G == 0, return_distances=False, return_indices=True)
    return G[idx[0], idx[1]]


def _adjacency(near, n):
    adj = {}
    for a, b in ((near[:, :-1], near[:, 1:]), (near[:-1, :], near[1:, :])):
        d = a != b
        for p, q in zip(a[d].tolist(), b[d].tolist()):
            if p and q:
                adj.setdefault(p, {}).setdefault(q, 0)
                adj[p][q] += 1
                adj.setdefault(q, {}).setdefault(p, 0)
                adj[q][p] += 1
    return adj


def sequence_by_object(scene, strokes, cfg, order_strokes):
    """Переставляє штрихи: для кожної групи - її контур (спершу силует), потім заливки її кольорів."""
    gm, near, groups = build_groups(scene, cfg)
    if not groups:
        return strokes, []
    id2idx = {m['id']: i for i, m in enumerate(scene.members)}
    H, W = near.shape

    def gof(s):
        if s.get('member') in id2idx and id2idx[s['member']] in gm:
            return gm[id2idx[s['member']]]
        p = np.rint(np.asarray(s['pts'])[::3]).astype(int)
        p[:, 0] = np.clip(p[:, 0], 0, W - 1)
        p[:, 1] = np.clip(p[:, 1], 0, H - 1)
        v = near[p[:, 1], p[:, 0]]
        return int(np.bincount(v).argmax()) - 1
    by_g = {}
    for s in strokes:
        by_g.setdefault(gof(s), []).append(s)
    adj = _adjacency(near, len(groups))
    if cfg.get('group_order'):
        order = [g for g in cfg['group_order'] if g in by_g] + [g for g in by_g if g not in cfg['group_order']]
    else:
        # старт - «обличчя»: група з найбільшою кількістю товстих чорних деталей (зіниці/очі), далі за багатством і площею
        richness = {g['id']: sum(1 for s_ in by_g.get(g['id'], []) if s_['kind'] == 'ink' and s_.get('style') == 'hatch') * 1e6
                    + g['n_members'] * 1e3 + g['area'] / 1e3 for g in groups}
        order = [max(by_g, key=lambda g: richness.get(g, 0))]
        while len(order) < len(by_g):
            done = set(order)
            cand = [g for g in by_g if g not in done]
            nxt = max(cand, key=lambda g: (sum(adj.get(g + 1, {}).get(d + 1, 0) for d in done), groups[g]['area']))
            order.append(nxt)
    col_area = {}
    for s in strokes:
        if s['kind'] == 'color':
            col_area[s['fill']] = col_area.get(s['fill'], 0) + s.get('length_px', 1)
    # які контурні штрихи «замикають» форму групи (лежать впритул до її областей) - малюються до її заливки
    reg_mask = {}
    Hn, Wn = near.shape
    el = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))
    for g in groups:
        m = np.zeros(near.shape, np.uint8)
        for mid in g['members']:
            m[scene.ids == id2idx[mid] + 1] = 1
        reg_mask[g['id']] = cv2.dilate(m, el) > 0

    def touches(s, g):
        p = np.rint(np.asarray(s['pts'])[::3]).astype(int)
        p[:, 0] = np.clip(p[:, 0], 0, Wn - 1)
        p[:, 1] = np.clip(p[:, 1], 0, Hn - 1)
        return float(reg_mask[g][p[:, 1], p[:, 0]].mean()) >= 0.25
    if cfg.get('style') == 'outline_first':
        out, tip = [], None
        for g in order:
            ink = [x for x in by_g[g] if x['kind'] == 'ink']
            if ink:
                seq = order_strokes(ink, start=tip, allow_reverse=True, big_first=(tip is None))
                out += seq
                tip = seq[-1]['pts'][-1]
        for col in sorted(col_area, key=lambda c: -col_area[c]):
            for g in order:
                cs = [x for x in by_g[g] if x['kind'] == 'color' and x['fill'] == col]
                if cs:
                    seq = order_strokes(cs, start=tip, allow_reverse=True)
                    out += seq
                    tip = seq[-1]['pts'][-1]
        for g in groups:
            g['order'] = order.index(g['id']) if g['id'] in order else -1
        return out, groups
    batch = max(1, int(cfg.get('batch', 2)))
    out, tip, drawn = [], None, set()
    for b in range(0, len(order), batch):
        part = order[b:b + batch]
        # 1) контур: власні штрихи груп партії + штрихи, що замикають їх форми
        ink_all = []
        for g in part:
            for s in by_g[g]:
                if s['kind'] == 'ink' and id(s) not in drawn:
                    ink_all.append(s)
                    drawn.add(id(s))
            for s in strokes:
                if s['kind'] == 'ink' and id(s) not in drawn and touches(s, g) and _near_drawn(s, ink_all, out):
                    ink_all.append(s)
                    drawn.add(id(s))
        if ink_all:
            seq = order_strokes(ink_all, start=tip, allow_reverse=True, big_first=(tip is None))
            out += seq
            tip = seq[-1]['pts'][-1]
        # 2) заливки партії: колір за кольором (менше змін маркера)
        cs_all = [s for g in part for s in by_g[g] if s['kind'] == 'color']
        for col in sorted({s['fill'] for s in cs_all}, key=lambda c: -col_area.get(c, 0)):
            cs = [s for s in cs_all if s['fill'] == col]
            seq = order_strokes(cs, start=tip, allow_reverse=True)
            out += seq
            tip = seq[-1]['pts'][-1]
    rest = [s for s in strokes if id(s) not in {id(x) for x in out}]
    out += rest
    for g in groups:
        g['order'] = order.index(g['id']) if g['id'] in order else -1
    return out, groups


def _near_drawn(s, current, out, gap=28.0):
    """штрих «замикання» береться лише якщо він безперервно продовжує вже намальоване (без «плаваючих» шматків)"""
    pts = [np.asarray(x['pts']) for x in current + [o for o in out if o['kind'] == 'ink']]
    if not pts:
        return True
    P = np.vstack(pts)[::4]
    e = np.vstack([np.asarray(s['pts'])[:1], np.asarray(s['pts'])[-1:]])
    d = np.sqrt(((e[:, None, :] - P[None, :, :]) ** 2).sum(2)).min()
    return bool(d < gap)
