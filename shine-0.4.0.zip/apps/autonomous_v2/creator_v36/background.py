"""Фон-стіл з аркушем: малюнок накладається на аркуш множенням (зберігає тіні/фактуру фону)."""
import cv2
import numpy as np
from scipy import ndimage


class Background:
    def __init__(self, path, W=1280, H=720):
        img = cv2.imread(str(path), cv2.IMREAD_COLOR)
        assert img is not None, f'не вдалося прочитати фон {path}'
        self.bg = cv2.resize(img, (W, H), interpolation=cv2.INTER_AREA)
        self.W, self.H = W, H
        mask = (self.bg.min(2) > 215).astype(np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((9, 9), np.uint8))
        lab, n = ndimage.label(mask)
        sizes = ndimage.sum(mask, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        ys, xs = np.nonzero(lab == k)
        m = 6                                                    # невеликий відступ від краю аркуша
        self.rect = (int(xs.min()) + m, int(ys.min()) + m, int(xs.max()) - m, int(ys.max()) - m)
        x0, y0, x1, y1 = self.rect
        paper = self.bg[y0:y1, x0:x1].astype(np.float32)
        self.paper_gain = paper / max(1.0, float(np.percentile(paper, 90)))   # нерівномірність освітлення аркуша
        self.paper_gain = np.clip(self.paper_gain, 0.85, 1.0)
        self.bg_rect = self.bg[y0:y1, x0:x1].astype(np.float32)

    def fit_box(self, margin=0.04):
        x0, y0, x1, y1 = self.rect
        s = min(x1 - x0, y1 - y0) * (1 - 2 * margin)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        return (cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)

    def compose(self, canvas_bgr):
        out = self.bg.copy()
        x0, y0, x1, y1 = self.rect
        c = canvas_bgr[y0:y1, x0:x1].astype(np.float32) / 255.0
        out[y0:y1, x0:x1] = np.clip(self.bg_rect * c, 0, 255).astype(np.uint8)
        return out
