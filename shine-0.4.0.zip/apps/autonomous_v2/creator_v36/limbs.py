#!/usr/bin/env python3
"""Limbs v1 - автоматичне знаходження кінцівок за силуетом + «м'який шарнір» (soft hinge).

Ідея (замість «вирізати лапу + підкладка + жорсткий поворот»):
  1. силует = усе, що не є зовнішнім папером (білі очі/живіт лишаються частиною персонажа);
  2. морфологічний розклад: тіло = найбільше «ядро» (erosion по EDT) + реконструкція; кінцівка = залишок силуету,
     що стирчить із тіла вузькою шийкою (лапа, хвіст, вуха);
  3. деформація - ОДНЕ inverse-відображення кадру: кут повороту в точці p = theta * w(p), де w плавно росте від 0 у
     плечі до 1 на кінчику (рампа вздовж осі) і обмежене областю кінцівки + прилеглого паперу. Тіло не рухається,
     дірок під лапою нема за побудовою (відображення неперервне), контур у плечі просто м'яко вигинається.
  4. fail-closed: перевірка зіткнення (кінцівка не має заїжджати на тіло) -> автоматичне зменшення амплітуди.
Працює на кадрі (BGR uint8) без розмітки; для складних випадків можна підставити seed-клік (paw=(x,y)).
"""
from __future__ import annotations

import math

import cv2
import numpy as np
from scipy import ndimage


def silhouette(img_bgr, paper_min=235):
    """Силует персонажа: не-папір, що не з'єднаний із краєм кадру як біле."""
    paper = img_bgr.min(2) >= paper_min
    lab, n = ndimage.label(paper)
    edge = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    bg = np.isin(lab, edge[edge > 0])
    return ~bg, bg


def _smooth(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


class Limb:
    """Кінцівка: маска, шарнір, вісь, рампа, параметри безпечного повороту."""

    def __init__(self, mask, pivot, axis, ramp, hw, kind, score, contact):
        self.mask, self.pivot, self.axis, self.ramp, self.hw = mask, pivot, axis, ramp, hw
        self.kind, self.score, self.contact = kind, score, contact
        self.safe_deg = None
        ys, xs = np.nonzero(mask)
        self.bbox = (int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max()))


def find_limbs(img_bgr, r_fracs=(0.34, 0.46, 0.58), min_frac=0.006, max_frac=0.30):
    S, bg = silhouette(img_bgr)
    H, W = S.shape
    D = ndimage.distance_transform_edt(S)
    Dmax = float(D.max())
    total = float(S.sum())
    out = []
    seen = []
    for rf in r_fracs:
        r = max(6.0, rf * Dmax)
        core = D > r
        lab, n = ndimage.label(core)
        if n < 1:
            continue
        sizes = ndimage.sum(core, lab, range(1, n + 1))
        body_core = lab == (int(np.argmax(sizes)) + 1)
        body = (ndimage.distance_transform_edt(~body_core) <= r + 1.0) & S
        resid = S & ~body
        rl, rn = ndimage.label(resid)
        bd = ndimage.binary_dilation(body, iterations=2)
        for j in range(1, rn + 1):
            comp = rl == j
            a = float(comp.sum())
            if a < min_frac * total or a > max_frac * total:
                continue
            contact = comp & bd
            cn = int(contact.sum())
            if cn < 6:
                continue
            ys, xs = np.nonzero(comp)
            cx, cy = float(xs.mean()), float(ys.mean())
            if any(math.hypot(cx - s[0], cy - s[1]) < 25 and abs(a - s[2]) < 0.35 * a for s in seen):
                continue
            seen.append((cx, cy, a))
            cys, cxs = np.nonzero(contact)
            pivot = (float(cxs.mean()), float(cys.mean()))
            far = np.hypot(xs - pivot[0], ys - pivot[1])
            far_pt = (float(xs[far >= np.percentile(far, 90)].mean()), float(ys[far >= np.percentile(far, 90)].mean()))
            ax = np.array([far_pt[0] - pivot[0], far_pt[1] - pivot[1]], float)
            L = float(np.linalg.norm(ax))
            if L < 18:
                continue
            ax /= L
            hw = float(np.median(D[contact]))
            neck = float(cn)
            thick = float(D[comp].max())
            # «шийка» вузька відносно кінцівки -> впевненіша кінцівка
            score = (L / (2 * thick + 1e-6)) / (1.0 + neck / (2 * thick + 1e-6) * 0.35)
            bcx, bcy = ndimage.center_of_mass(body)[1], ndimage.center_of_mass(body)[0]
            kind = 'arm_up' if cy < bcy - 0.05 * H and abs(cx - bcx) > 0.5 * Dmax else ('low' if cy > bcy else 'side')
            ramp = float(max(22.0, 2.6 * hw))
            lb = Limb(comp, pivot, ax, ramp, hw, kind, score, cn)
            lb.length = L
            out.append(lb)
    out.sort(key=lambda l: -l.score)
    return out, S, bg


def split_hand(limb, bin_px=8):
    """Відокремлює КИСТЬ від руки по шийці зап'ястя: найвужче місце вздовж осі, за яким кінцівка помітно розширюється.
    Повертає новий Limb (kind='hand') або None, якщо виразного зап'ястя немає (fail-closed)."""
    ys, xs = np.nonzero(limb.mask)
    ux, uy = limb.axis
    px, py = limb.pivot
    t = (xs - px) * ux + (ys - py) * uy
    e = ndimage.distance_transform_edt(limb.mask)[ys, xs]
    Lt = float(t.max())
    if Lt < 60:
        return None
    starts = np.arange(0.2 * Lt, Lt - bin_px, bin_px)
    me = np.array([e[(t >= b) & (t < b + bin_px)].max() if ((t >= b) & (t < b + bin_px)).any() else np.nan for b in starts])
    cand = [i for i, b in enumerate(starts) if 0.40 * Lt <= b <= 0.75 * Lt and not np.isnan(me[i])]
    if not cand:
        return None
    i0 = min(cand, key=lambda i: me[i])
    wmin = float(me[i0])
    tail = [i for i in range(i0 + 1, len(starts)) if not np.isnan(me[i]) and me[i] >= 1.2 * wmin]
    if wmin < 3 or not tail:
        return None
    tw = float(starts[i0])                              # зап'ясток = найвужча шийка перед розширенням
    sel = (t > tw - 7) & (t < tw + 7)
    if sel.sum() < 10:
        return None
    wx, wy = float(xs[sel].mean()), float(ys[sel].mean())
    hk = t >= tw
    hand = np.zeros_like(limb.mask, bool)
    hand[ys[hk], xs[hk]] = True
    if hand.sum() < 0.25 * limb.mask.sum() * 0.3:
        return None
    hy, hx = np.nonzero(hand)
    ax = np.array([hx.mean() - wx, hy.mean() - wy]); n = np.linalg.norm(ax)
    if n < 5:
        return None
    ax /= n
    hl = Limb(hand, (wx, wy), (float(ax[0]), float(ax[1])), float(max(14.0, 1.2 * wmin)), float(e[hk].max()), "hand", 1.0, (wx, wy))
    hl.length = float(np.hypot(hx - wx, hy - wy).max())
    return hl


def pick(limbs, kind='arm_up'):
    c = [l for l in limbs if l.kind == kind]
    return max(c, key=lambda l: l.score) if c else None


# ------------------------------------------------------------------------------------------------
class HingeWarp:
    """Перераховує кадр з поворотом кінцівки на кут theta (градуси) навколо pivot з м'яким шарніром."""

    def __init__(self, img_bgr, limb: Limb, S, margin=26, pad=14):
        self.img, self.limb, self.S = img_bgr, limb, S
        H, W = S.shape
        x0, y0, x1, y1 = limb.bbox
        ext = int(0.35 * math.hypot(x1 - x0, y1 - y0))
        m = margin + pad + int(limb.ramp) + ext
        self.roi = (max(0, x0 - m), max(0, y0 - m), min(W, x1 + m), min(H, y1 + m))
        rx0, ry0, rx1, ry1 = self.roi
        L = limb.mask
        paper = ~S
        near = ndimage.binary_dilation(L, iterations=margin) & paper
        Lext = (L | near)
        M = cv2.GaussianBlur(Lext.astype(np.float32), (0, 0), 3.0)
        # область тіла: вага 0
        body = S & ~L
        M[body] = 0.0
        # захисний пояс: згладжені краї контуру тіла (світліші за paper_min) НЕ рухаються разом з кінцівкою
        guard = ndimage.binary_dilation(body, iterations=5) & ~ndimage.binary_dilation(L, iterations=2)
        M[guard] = 0.0
        M = np.where(L, 1.0, M)
        yy, xx = np.mgrid[ry0:ry1, rx0:rx1].astype(np.float32)
        px, py = limb.pivot
        ux, uy = limb.axis
        t = (xx - px) * ux + (yy - py) * uy
        ramp = limb.ramp
        w = _smooth((t + 0.35 * ramp) / (1.35 * ramp))
        self.w = (w * M[ry0:ry1, rx0:rx1]).astype(np.float32)
        self.wr = w.astype(np.float32)
        self.xx, self.yy = xx, yy
        self.pivot = (px, py)

    def _srcw(self, theta_deg, w):
        a = np.deg2rad(theta_deg) * w
        c, s = np.cos(-a), np.sin(-a)
        px, py = self.pivot
        dx, dy = self.xx - px, self.yy - py
        return (px + c * dx - s * dy).astype(np.float32), (py + s * dx + c * dy).astype(np.float32)

    def render(self, theta_deg):
        """База: м'яке inverse-відображення (папір рухається з кінцівкою, тіло стоїть) + кінцівка ПОВЕРХ тіла."""
        rx0, ry0, rx1, ry1 = self.roi
        out = self.img.copy()
        if abs(theta_deg) < 1e-4:
            return out
        sx, sy = self._srcw(theta_deg, self.w)
        base = cv2.remap(self.img, sx, sy, cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE).astype(np.float32)
        if not self.front:
            out[ry0:ry1, rx0:rx1] = np.clip(base, 0, 255).astype(np.uint8)
            return out
        L = self.limb.mask.astype(np.float32)
        sx2, sy2 = self._srcw(theta_deg, self.wr)
        al = cv2.remap(L, sx2, sy2, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)[:, :, None]
        pm = (self.img.astype(np.float32) * L[:, :, None])
        pmw = cv2.remap(pm, sx2, sy2, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        comp = pmw + base * (1.0 - al)
        out[ry0:ry1, rx0:rx1] = np.clip(comp, 0, 255).astype(np.uint8)
        return out

    def smear(self, theta_deg):
        """Fail-closed метрика: звільнені пікселі кінцівки, що стали НЕ папером (розмазане тіло/контур)."""
        rx0, ry0, rx1, ry1 = self.roi
        fr = self.render(theta_deg)[ry0:ry1, rx0:rx1]
        L = self.limb.mask[ry0:ry1, rx0:rx1]
        sx, sy = self._srcw(theta_deg, self.wr)
        lw = cv2.remap(self.limb.mask.astype(np.float32), sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0) > 0.5
        freed = ndimage.binary_erosion(L & ~lw, iterations=2)
        far = np.hypot(self.xx - self.pivot[0], self.yy - self.pivot[1]) > 1.2 * self.limb.ramp
        return int((freed & far & (fr.min(2) < 225)).sum())

    def spurious(self, theta_deg):
        """Нове чорнило там, де у вихідному був папір і де немає рухомої кінцівки: клаптики контуру, що відірвалися/потяглися."""
        rx0, ry0, rx1, ry1 = self.roi
        fr = self.render(theta_deg)[ry0:ry1, rx0:rx1]
        sx, sy = self._srcw(theta_deg, self.wr if self.front else self.w)
        al = cv2.remap(self.limb.mask.astype(np.float32), sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0) > 0.02
        cover = ndimage.binary_dilation(al, iterations=2)
        S = ndimage.binary_dilation(self.S[ry0:ry1, rx0:rx1], iterations=2)
        return int(((fr.min(2) < 150) & ~S & ~cover).sum())

    def _src(self, theta_deg):
        a = np.deg2rad(theta_deg) * self.w
        c, s = np.cos(-a), np.sin(-a)
        px, py = self.pivot
        dx, dy = self.xx - px, self.yy - py
        return (px + c * dx - s * dy).astype(np.float32), (py + s * dx + c * dy).astype(np.float32)

    front = True     # True: кінцівка попереду тіла (лапа); False: позаду (хвіст)
    keepout = None   # bool-маска (повний кадр): зона обличчя, яку кінцівка не має накривати

    def intrusion(self, theta_deg):
        if self.keepout is None:
            return 0
        sx, sy = self._srcw(theta_deg, self.wr)
        rx0, ry0, rx1, ry1 = self.roi
        lw = cv2.remap(self.limb.mask.astype(np.float32), sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0) > 0.5
        return int((lw & self.keepout[ry0:ry1, rx0:rx1]).sum())

    def lost(self, theta_deg):
        """Скільки пікселів кінцівки втиснулося в тіло (актуально, коли кінцівка позаду)."""
        rx0, ry0, rx1, ry1 = self.roi
        sx, sy = self._srcw(theta_deg, self.w)
        L = self.limb.mask.astype(np.float32)
        lw = cv2.remap(L, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return int(max(0.0, float(L[ry0:ry1, rx0:rx1].sum() - lw.sum())))

    def safe_angle(self, target, sign=1, step=0.5, tol=40):
        th = abs(target)
        base = self.intrusion(0.0)
        while th > 0 and (self.smear(sign * th) > tol or self.spurious(sign * th) > 25 or self.intrusion(sign * th) > base + 12
                          or (not self.front and self.lost(sign * th) > 12)):
            th -= step
        return max(0.0, th)
