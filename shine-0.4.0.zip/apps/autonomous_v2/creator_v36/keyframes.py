#!/usr/bin/env python3
"""Keyframes v1 - статичні AI-кадри (закриті очі, сміх, усмішка) як ЛОКАЛЬНІ патчі поверх оригіналу.

Модель не зберігає піксельну точність, тому:
  1. кожен кадр афінно вирівнюється по нерухомих частинах (ECC) до базового;
  2. маска зміни = де кадр відрізняється від бази (поріг, закриття, заповнення дір, розширення);
  3. патч локально уточнюється (translation ECC по кільцю навколо маски);
  4. у фінальний кадр вставляється ТІЛЬКИ маска, решта = оригінал (піксель-в-піксель);
  5. QA: товщина контуру, колір палітри, зсув - у report.
"""
from __future__ import annotations

import cv2
import numpy as np
from scipy import ndimage


def _gray(x):
    return cv2.cvtColor(x, cv2.COLOR_BGR2GRAY).astype(np.float32)


def coarse_shift(base, kf, stable_rows=(0.80, 0.95), rng=48, xrange=None, region=None):
    """Грубий зсув (tx,ty) для старту ECC: AI-кадри інколи зсунуті на десятки пікселів.
    Повертає tx,ty у конвенції WARP_INVERSE_MAP (base(x) ~ kf(x+t))."""
    H, W = base.shape[:2]
    r0, r1 = int(stable_rows[0] * H), int(stable_rows[1] * H)
    if region is not None:
        ys = np.nonzero(region.any(1))[0]; r0, r1 = int(ys.min()), int(ys.max()) + 1
    ink = lambda im: cv2.GaussianBlur((_gray(im) < 90).astype(np.float32), (0, 0), 2)
    a, b = ink(base)[r0:r1], ink(kf)
    if xrange is not None:
        a = a.copy(); a[:, :int(xrange[0] * W)] = 0; a[:, int(xrange[1] * W):] = 0
    if region is not None:
        a = a * region[r0:r1].astype(np.float32)
    na = np.sqrt((a * a).sum()) + 1e-6

    def score(tx, ty):
        M = np.float32([[1, 0, -tx], [0, 1, -ty]])
        w = cv2.warpAffine(b, M, (W, H))[r0:r1]
        return float((a * w).sum() / (na * (np.sqrt((w * w).sum()) + 1e-6)))

    best = (score(0, 0), 0, 0)
    for ty in range(-rng, rng + 1, 4):
        for tx in range(-rng, rng + 1, 4):
            sc = score(tx, ty)
            if sc > best[0]:
                best = (sc, tx, ty)
    _, cx, cy = best
    for ty in range(cy - 3, cy + 4):
        for tx in range(cx - 3, cx + 4):
            sc = score(tx, ty)
            if sc > best[0]:
                best = (sc, tx, ty)
    return float(best[1]), float(best[2])


def align_pyramid(base, kf, mask):
    """Афінне ECC по піраміді (1/8->1) на розмитій масці чорнила, лише в області mask (нерухомі частини).
    Потрібне, коли AI-кадр зсунутий/трохи масштабований (набір 2)."""
    H, W = base.shape[:2]
    inkf = lambda im, sg: cv2.GaussianBlur((_gray(im) < 90).astype(np.float32), (0, 0), sg)
    warp = np.eye(2, 3, dtype=np.float32)
    cc = 0.0
    for sc, sg in [(0.125, 2), (0.25, 2), (0.5, 2), (1.0, 3)]:
        b = cv2.resize(inkf(base, sg), None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
        k = cv2.resize(inkf(kf, sg), None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
        m = cv2.resize(mask.astype(np.uint8), (b.shape[1], b.shape[0]), interpolation=cv2.INTER_NEAREST)
        w = warp.copy(); w[:, 2] *= sc
        try:
            cc, w = cv2.findTransformECC(b, k, w, cv2.MOTION_AFFINE, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-7), m, 5)
        except cv2.error:
            break
        w[:, 2] /= sc
        warp = w
    out = cv2.warpAffine(kf, warp, (W, H), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP, borderValue=(255, 255, 255))
    return out, warp, float(cc)


def align(base, kf, stable_rows=(0.80, 0.95), motion="affine", xrange=None, stable_mask=None):
    """Афінне вирівнювання kf до base по нижній (нерухомій) частині; повертає (kf_aligned, warp, cc)."""
    H, W = base.shape[:2]
    m = np.zeros((H, W), np.uint8)
    xa, xb = (0, W) if xrange is None else (int(xrange[0] * W), int(xrange[1] * W))
    m[int(stable_rows[0] * H):int(stable_rows[1] * H), xa:xb] = 1
    if stable_mask is not None:
        m = stable_mask.astype(np.uint8)
    warp = np.eye(2, 3, dtype=np.float32)
    warp[0, 2], warp[1, 2] = coarse_shift(base, kf, stable_rows, xrange=xrange, region=stable_mask)
    mot = cv2.MOTION_TRANSLATION if motion == "translation" else cv2.MOTION_AFFINE
    cc, warp = cv2.findTransformECC(_gray(base), _gray(kf), warp, mot,
                                    (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 300, 1e-7), m, 7)
    out = cv2.warpAffine(kf, warp, (W, H), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP, borderValue=(255, 255, 255))
    return out, warp, float(cc)


def change_mask(base, kf, thr=70, min_area=150, grow=11):
    d = np.abs(base.astype(np.int16) - kf.astype(np.int16)).max(2) > thr
    # тонкі смужки (суб-піксельний зсув контурів) прибираємо відкриттям; реальні зміни (очі/рот) - товсті
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))).astype(bool)
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))).astype(bool)
    lab, n = ndimage.label(d)
    if n:
        sz = ndimage.sum(d, lab, range(1, n + 1))
        d = np.isin(lab, [i + 1 for i, s in enumerate(sz) if s >= min_area])
    d = ndimage.binary_fill_holes(d)
    return cv2.dilate(d.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * grow + 1,) * 2)).astype(bool)


def refine(base, kf, mask, ring=26):
    """Локальне уточнення зсуву патча по кільцю навколо маски (де кадри мають збігатися)."""
    rg = cv2.dilate(mask.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * ring + 1,) * 2)).astype(bool) & ~mask
    if rg.sum() < 200:
        return kf, (0.0, 0.0)
    warp = np.eye(2, 3, dtype=np.float32)
    try:
        _, warp = cv2.findTransformECC(_gray(base), _gray(kf), warp, cv2.MOTION_TRANSLATION,
                                       (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6), rg.astype(np.uint8), 5)
    except cv2.error:
        return kf, (0.0, 0.0)
    H, W = base.shape[:2]
    out = cv2.warpAffine(kf, warp, (W, H), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
    return out, (float(warp[0, 2]), float(warp[1, 2]))


def ink_width(x):
    ink = x.max(2) < 72
    return float(np.median(ndimage.distance_transform_edt(ink)[ink]) * 2) if ink.any() else 0.0


def color_match(base, kf, mask):
    """Лінійна підгонка кольору kf до base (gain+offset по каналах) по нерухомих НЕчорнильних пікселях mask."""
    ok = mask & (_gray(base) > 110) & (_gray(kf) > 110)
    if ok.sum() < 5000:
        return kf
    out = kf.astype(np.float32)
    for c in range(3):
        x = kf[..., c][ok].astype(np.float32); y = base[..., c][ok].astype(np.float32)
        A = np.vstack([x, np.ones_like(x)]).T
        g, o = np.linalg.lstsq(A[::7], y[::7], rcond=None)[0]
        out[..., c] = out[..., c] * g + o
    # чорне чорнило не чіпаємо: корекція згасає до нуля в темних пікселях
    wgt = np.clip((_gray(kf) - 90.0) / 70.0, 0, 1)[..., None]
    out = kf.astype(np.float32) * (1 - wgt) + out * wgt
    return np.clip(out, 0, 255).astype(np.uint8)


def feature_mask(base, kf, roi, grow=14, max_area=70000):
    """Маска ознак обличчя: чорнило (очі/брови/ніс/рот) з ОБОХ кадрів у roi, без великих контурних компонент;
    отвори заповнені (білки, язик). Межа маски лежить на пласкому тлі, контур голови не чіпається."""
    H, W = base.shape[:2]
    x0, y0, x1, y1 = int(roi[0] * W), int(roi[1] * H), int(roi[2] * W), int(roi[3] * H)
    ink = ((_gray(base) < 90) | (_gray(kf) < 90))
    rm = np.zeros((H, W), bool); rm[y0:y1, x0:x1] = True
    ink &= rm
    lab, n = ndimage.label(ink)
    keep = np.zeros_like(ink)
    for i in range(1, n + 1):
        comp = lab == i
        ys, xs = np.nonzero(comp)
        if comp.sum() > max_area or xs.min() <= x0 + 2 or xs.max() >= x1 - 3 or ys.min() <= y0 + 2 or ys.max() >= y1 - 3:
            continue
        keep |= comp
    keep = cv2.morphologyEx(keep.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))).astype(bool)
    keep = ndimage.binary_fill_holes(keep)
    return cv2.dilate(keep.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * grow + 1,) * 2)).astype(bool)


def snap_palette(base, kf, k=6, tol=38.0):
    """Прибирає плямистість AI-заливок: пласкі кольори kf, близькі до палітри базового кадру, стають точно палітрою.
    Краї (згладжування навколо чорнила) не чіпаємо - вони далекі від палітри."""
    sm = base.reshape(-1, 3)[::37].astype(np.float32)
    sm = sm[_gray(base).reshape(-1)[::37] > 110]
    _, _, cen = cv2.kmeans(sm, k, None, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.5), 3, cv2.KMEANS_PP_CENTERS)
    f = kf.astype(np.float32)
    d = np.stack([np.linalg.norm(f - c, axis=2) for c in cen], 2)
    j = d.argmin(2); dm = d.min(2)
    out = kf.copy()
    sel = dm < tol
    out[sel] = cen[j[sel]].astype(np.uint8)
    return out


class Patch:
    """Один ключовий стан: kf (вирівняний), alpha (м'яка маска), report."""

    def __init__(self, name, base, kf_raw, thr=70, grow=11, pyramid_mask=None, roi=None, features=False, **align_kw):
        """pyramid_mask: булева маска нерухомих частин -> пірамідальне ECC; roi=(x0,y0,x1,y1) частки кадру: маска зміни тільки там."""
        self.name = name
        if pyramid_mask is not None:
            kf, warp, cc = align_pyramid(base, kf_raw, pyramid_mask)
            kf = color_match(base, kf, pyramid_mask)
            if features:
                kf = snap_palette(base, kf)
        else:
            kf, warp, cc = align(base, kf_raw, **align_kw)
        H, W = base.shape[:2]
        rm = np.ones((H, W), bool)
        if roi is not None:
            rm[:] = False; rm[int(roi[1] * H):int(roi[3] * H), int(roi[0] * W):int(roi[2] * W)] = True
        mk = (lambda b, k: feature_mask(b, k, roi, grow=grow + 3)) if (features and roi is not None) else \
             (lambda b, k: change_mask(b, k, thr=thr, grow=grow) & rm)
        mask = mk(base, kf)
        if features:
            shift = (0.0, 0.0)      # пірамідальне ECC уже збіглося; кільцеве уточнення тут хибить
        else:
            kf, shift = refine(base, kf, mask)
            mask = mk(base, kf)
        self.mask = mask
        self.kf = kf
        self.alpha = cv2.GaussianBlur(mask.astype(np.float32), (0, 0), 1.6)
        ys, xs = np.nonzero(mask)
        self.bbox = (int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())) if len(xs) else (0, 0, 0, 0)
        self.report = dict(cc=round(cc, 4), shift_local=[round(shift[0], 2), round(shift[1], 2)],
                           affine=[[round(float(v), 4) for v in r] for r in warp], ink_w=round(ink_width(kf), 2),
                           area=int(mask.sum()), bbox=list(self.bbox))

    def apply(self, img, w):
        """Змішує патч у img з вагою w∈[0,1] (тільки всередині маски)."""
        if w <= 0:
            return img
        a = (self.alpha * float(np.clip(w, 0, 1)))[:, :, None]
        return img * (1.0 - a) + self.kf.astype(np.float32) * a


def scale_all(base, patches, size):
    """Масштабує базу й усі патчі до розміру size=(w,h), зберігаючи маски."""
    w, h = size
    r = lambda x, interp=cv2.INTER_AREA: cv2.resize(x, (w, h), interpolation=interp)
    b = r(base)
    for p in patches:
        p.kf = r(p.kf)
        p.alpha = r(p.alpha, cv2.INTER_LINEAR)
        p.mask = p.alpha > 0.5
    return b


def to_canvas(patch, canvas_size, box):
    """Переносить патч у координати полотна: box=(x0,y0,x1,y1) - куди вписано базу."""
    cw, ch = canvas_size
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    kf = np.full((ch, cw, 3), 255, np.uint8)
    al = np.zeros((ch, cw), np.float32)
    kf[y0:y1, x0:x1] = cv2.resize(patch.kf, (w, h), interpolation=cv2.INTER_AREA)
    al[y0:y1, x0:x1] = cv2.resize(patch.alpha, (w, h), interpolation=cv2.INTER_LINEAR)
    out = Patch.__new__(Patch)
    out.name, out.kf, out.alpha, out.report = patch.name, kf, al, patch.report
    out.mask = al > 0.5
    ys, xs = np.nonzero(out.mask)
    out.bbox = (int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max()))
    return out
