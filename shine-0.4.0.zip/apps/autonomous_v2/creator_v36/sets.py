#!/usr/bin/env python3
"""Sets v1 - розумне розділення листа (набір монстриків/машинок/фруктів) на окремі ОБ'ЄКТИ.

Навіщо: процес малювання/розфарбування працює по одному об'єкту; анімація (моргання тощо) теж - по одному.
Принцип (без нейромереж, детерміновано):
  1. силует = усе, що не папір, плюс білі острівці всередині контуру (склера, білі животи);
  2. з'єднані компоненти силуету (після легкого закриття дірок згладжування);
  3. великі компоненти = об'єкти; дрібні відірвані шматки (краплі слизу, кульки антен) приклеюються
     до найближчого об'єкта, якщо близько; решта дрібниць = "props" (зірки, бульбашки) - окремі легкі об'єкти;
  4. об'єкти, що перекриваються/торкаються (риф із восьминогом), лишаються одним об'єктом: чесніше, ніж різати навпіл.
Вихід: список Obj(mask, bbox, kind) + crop() з білим тлом + layout (позиція в листі) для повернення на місце.
"""
from __future__ import annotations

import cv2
import numpy as np
from scipy import ndimage


class Obj:
    def __init__(self, mask, kind):
        self.mask, self.kind = mask, kind
        ys, xs = np.nonzero(mask)
        self.bbox = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
        self.area = int(mask.sum())

    def crop(self, img, margin=24):
        H, W = self.mask.shape
        x0, y0, x1, y1 = self.bbox
        x0, y0, x1, y1 = max(0, x0 - margin), max(0, y0 - margin), min(W, x1 + margin), min(H, y1 + margin)
        # чуже (сусідні об'єкти) в кроп не потрапляє: усе поза власною маскою (з відступом) -> білий папір
        own = cv2.dilate(self.mask.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))).astype(bool)
        c = np.full(img.shape, 255, np.uint8)
        c[own] = img[own]
        return c[y0:y1, x0:x1].copy(), (x0, y0, x1, y1)


def silhouette(img, paper_min=235):
    paper = img.min(2) >= paper_min
    lab, n = ndimage.label(paper)
    edge = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    bg = np.isin(lab, edge[edge > 0])
    return ~bg


def split_sheet(img, min_frac=0.012, attach_frac=0.10, prop_frac=0.0015):
    """img BGR -> список Obj. min_frac: частка площі найбільшого для "справжнього" об'єкта;
    attach_frac: дрібне відірване шматочко приклеюється, якщо відстань < attach_frac * розмір об'єкта."""
    S = silhouette(img)
    S = cv2.morphologyEx(S.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))).astype(bool)
    lab, n = ndimage.label(S)
    if n == 0:
        return []
    area = ndimage.sum(S, lab, range(1, n + 1))
    big = float(area.max())
    H, W = S.shape
    real = [i + 1 for i, a in enumerate(area) if a >= 0.12 * big]
    rest = [i + 1 for i, a in enumerate(area) if a < 0.12 * big]
    groups = {i: (lab == i) for i in real}
    props = []
    dist_cache = {i: ndimage.distance_transform_edt(~groups[i]) for i in real}
    for j in rest:
        m = lab == j
        if m.sum() < prop_frac * H * W * 0.2:
            # пилюка: приклеїти до найближчого без умов
            if real:
                k = min(real, key=lambda i: float(dist_cache[i][m].min()))
                groups[k] |= m
            continue
        if real:
            k = min(real, key=lambda i: float(dist_cache[i][m].min()))
            gx0, gy0, gx1, gy1 = Obj(groups[k], 'x').bbox
            size = max(gx1 - gx0, gy1 - gy0)
            # приклеюємо лише справжні дрібниці (краплі, кульки): <3% площі об'єкта і дуже близько; зірки/бульбашки лишаються props
            if m.sum() < 0.03 * groups[k].sum() and float(dist_cache[k][m].min()) < 0.5 * attach_frac * size:
                groups[k] |= m
                continue
        props.append(m)
    objs = [Obj(groups[i], 'object') for i in real]
    objs += [Obj(m, 'prop') for m in props]
    # порядок читання: рядками зверху вниз, зліва направо
    hs = np.median([o.bbox[3] - o.bbox[1] for o in objs])
    objs.sort(key=lambda o: (round(((o.bbox[1] + o.bbox[3]) / 2) / (0.8 * hs)), o.bbox[0]))
    return objs


def preview(img, objs):
    v = img.copy()
    pal = [(0, 0, 255), (255, 0, 0), (0, 160, 0), (0, 140, 255), (200, 0, 200), (0, 200, 200)]
    for k, o in enumerate(objs):
        x0, y0, x1, y1 = o.bbox
        c = pal[k % len(pal)] if o.kind == 'object' else (120, 120, 120)
        cv2.rectangle(v, (x0, y0), (x1, y1), c, 3)
        cv2.putText(v, f'{k}{"" if o.kind == "object" else "p"}', (x0 + 4, y0 + 26), cv2.FONT_HERSHEY_SIMPLEX, 0.9, c, 2)
    return v
