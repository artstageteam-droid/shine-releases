#!/usr/bin/env python3
"""Story Events v36: смислові події, що стартують лише після завершення відповідних елементів.

Усе робиться з уже намальованих пікселів (жодних нових ассетів і жодного синтезованого звуку):
  * blink  - повіка кольору шкіри зверху вниз накриває розпізнане око і відкривається назад;
  * flutter - крила метелика стискаються навколо осі тіла + м'який дрейф, у кінці точно повертаються в статичну позу.
Мітки (які саме члени є оком / метеликом) приходять із sidecar labels, а не вгадуються з кольору.
"""
from __future__ import annotations

import math

import cv2
import numpy as np


def _ease(u):
    u = float(np.clip(u, 0., 1.))
    return u * u * (3. - 2. * u)


def _hull_mask(mask):
    pts = cv2.findNonZero(mask.astype(np.uint8))
    out = np.zeros(mask.shape, np.uint8)
    if pts is not None:
        cv2.fillConvexPoly(out, cv2.convexHull(pts), 1)
    return out.astype(bool)


class Eye:
    def __init__(self, base_bgr, member_masks):
        m = np.zeros(base_bgr.shape[:2], bool)
        for k in member_masks:
            m |= k
        self.mask = _hull_mask(m)
        ys, xs = np.nonzero(self.mask)
        self.y0, self.y1 = int(ys.min()), int(ys.max())
        k = np.ones((3, 3), np.uint8)
        ring = cv2.dilate(self.mask.astype(np.uint8), k, iterations=7).astype(bool) & ~cv2.dilate(
            self.mask.astype(np.uint8), k, iterations=3).astype(bool)
        px = base_bgr[ring]
        lum = px.astype(np.float32).mean(1)
        px = px[lum > 120]
        self.lid_color = np.median(px, axis=0).astype(np.uint8) if len(px) else np.array([220, 220, 220], np.uint8)
        self.line_color = np.array([22, 24, 47], np.uint8)       # rgb(47,24,22) - колір контуру ока в оригіналі
        self.yy = np.indices(base_bgr.shape[:2])[0]

    def apply(self, frame, p):
        if p <= 0.0:
            return
        edge = self.y0 + p * (self.y1 - self.y0 + 1)
        lid = self.mask & (self.yy < edge)
        frame[lid] = self.lid_color
        if p > 0.12:
            line = self.mask & (self.yy >= edge - 2.5) & (self.yy < edge + 0.5)
            frame[line] = self.line_color


def blink_profile(t, t0, dur=0.32):
    """0 -> 1 -> 0 за dur секунд (закриття швидше за відкриття)."""
    u = (t - t0) / dur
    if u <= 0 or u >= 1:
        return 0.0
    return _ease(u / 0.42) if u < 0.42 else 1.0 - _ease((u - 0.42) / 0.58)


class Butterfly:
    def __init__(self, base_bgr, wing_mask, body_mask, bg=255):
        k = np.ones((3, 3), np.uint8)
        full = cv2.dilate((wing_mask | body_mask).astype(np.uint8), k, iterations=3).astype(bool)
        self.full = full
        self.wing = full & ~cv2.dilate(body_mask.astype(np.uint8), k, iterations=1).astype(bool)
        self.body = cv2.dilate(body_mask.astype(np.uint8), k, iterations=1).astype(bool)
        self.layer = base_bgr.copy()
        self.bg = bg
        ys, xs = np.nonzero(body_mask if body_mask.any() else wing_mask)
        c = np.array([xs.mean(), ys.mean()], np.float32)
        u, s, vt = np.linalg.svd(np.column_stack((xs - c[0], ys - c[1])).astype(np.float32), full_matrices=False)
        self.axis = vt[0]                                       # вісь тіла
        self.center = c

    def _warp(self, mask, sx, dx, dy, bob_deg):
        W, H = mask.shape[1], mask.shape[0]
        a = math.atan2(self.axis[1], self.axis[0])
        # у системі координат тіла: стискаємо ПОПЕРЕК осі (крила складаються до тіла)
        R = np.array([[math.cos(a), math.sin(a)], [-math.sin(a), math.cos(a)]], np.float32)
        Rb = R.T
        Sx = np.diag([1.0, sx]).astype(np.float32)
        A = Rb @ Sx @ R
        rot = math.radians(bob_deg)
        Rr = np.array([[math.cos(rot), -math.sin(rot)], [math.sin(rot), math.cos(rot)]], np.float32)
        A = Rr @ A
        c = self.center
        t = c - A @ c + np.array([dx, dy], np.float32)
        M = np.hstack((A, t[:, None])).astype(np.float32)
        img = cv2.warpAffine(self.layer, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        m = cv2.warpAffine(mask.astype(np.uint8) * 255, M, (W, H), flags=cv2.INTER_LINEAR)
        return img, m

    def apply(self, frame, p, t):
        """p: 0 (статика) .. 1 (повна інтенсивність); t - час події, с."""
        if p <= 0:
            return
        frame[self.full] = self.bg
        flap = 0.5 + 0.5 * math.cos(2 * math.pi * 3.2 * t)      # ~3,2 Гц змах
        sx = 1.0 - 0.50 * p * (1 - flap)
        dx = p * 16 * math.sin(math.pi * min(1.0, t / 2.8) * 1.0)
        dy = -p * 22 * math.sin(math.pi * min(1.0, t / 2.8)) - p * 3 * math.sin(2 * math.pi * 3.2 * t)
        bob = p * 4 * math.sin(2 * math.pi * 1.6 * t)
        for mask, factor in ((self.wing, sx), (self.body, 1.0)):
            img, m = self._warp(mask, factor, dx, dy, bob)
            a = (m.astype(np.float32) / 255.) * (img.min(2) < 246)       # білий фон не накриває сусідні елементи
            a = a[:, :, None]
            frame[:] = np.uint8(np.clip(img.astype(np.float32) * a + frame.astype(np.float32) * (1 - a), 0, 255))


class StoryEvents:
    """Таймлайн подій після завершення малюнка. build(final_canvas) -> (eyes, butterfly) викликається один раз,
    на реально намальованому фінальному кадрі (не на еталоні)."""

    def __init__(self, build, fps=60, blink_times=(0.9, 5.3), flutter=(1.6, 3.0), tail=1.2):
        self.build, self.fps = build, fps
        self.eyes = self.bf = self.base = None
        self.blink_times, self.flutter = blink_times, flutter
        self.total_s = max(blink_times[-1] + 0.32, flutter[0] + flutter[1]) + tail
        self.frames = int(math.ceil(self.total_s * fps))

    def frame(self, i, canvas):
        if self.base is None:
            self.base = canvas.copy()
            self.eyes, self.bf = self.build(self.base)
        t = (i + .5) / self.fps
        f = self.base.copy()
        f0, d = self.flutter
        if self.bf is not None and f0 < t < f0 + d:
            u = (t - f0) / d
            self.bf.apply(f, math.sin(math.pi * u) ** 0.5, t - f0)
        pb = max(blink_profile(t, b) for b in self.blink_times)
        if pb > 0:
            for e in self.eyes:
                e.apply(f, pb)
        return f
