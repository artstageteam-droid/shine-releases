#!/usr/bin/env python3
"""Sound v2 - керований синтез контактного звуку маркера (замість зациклених шматків запису).

Три варіанти (A/B):
  golden     - старий рушій (render.build_foley), для порівняння;
  granular   - гранульований: короткі зерна (35-70 мс, вікно Ханна) з оригінальних WAV, випадкові зсуви БЕЗ зациклення,
               гучність і яскравість залежать від швидкості штриха, тиск - від виду штриха;
  procedural - повністю процедурний (фільтрований шум + резонанс паперу), не містить жодного оригінального запису:
               «чистий за правами» варіант, якщо ліцензію записів не підтверджено.
Спільне: тихий тон кімнати (-62 dBFS) замість мертвої тиші, дотик/відрив (короткий транзієнт), шерех рукава під час
руху поза папером, шум зняття/надягання ковпачка на заміні маркера, видалення клацань (fade на межах),
м'який лімітер, вимірювання гучності (EBU R128 через ffmpeg).
Усе керується параметрами `mix` (sidecar: foley_mix): contact, touch, room, sleeve, cap, variant, seed.
"""
import math
import subprocess
import wave
from pathlib import Path

import numpy as np
from scipy import signal

FS = 48000
DEFAULT_MIX = dict(variant='granular', contact=1.0, touch=0.8, room=1.0, sleeve=1.0, cap=1.0, seed=7,
                   ink_gain=0.75, color_gain=0.55)


def _read(path):
    with wave.open(str(path)) as w:
        assert w.getnchannels() == 1 and w.getsampwidth() == 2
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(np.float32) / 32768.
        return x, w.getframerate()


def _lp(x, fc, order=2):
    sos = signal.butter(order, fc, 'low', fs=FS, output='sos')
    return signal.sosfilt(sos, x).astype(np.float32)


def _bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], 'band', fs=FS, output='sos')
    return signal.sosfilt(sos, x).astype(np.float32)


def _ctrl(vals, fps, n):
    """керуючий сигнал з кадрової частоти до частоти дискретизації (лінійно)"""
    t = (np.arange(len(vals)) + .5) / fps
    return np.interp(np.arange(n) / FS, t, vals).astype(np.float32)


def _grains(src, n, rng, glen=0.050):
    """неперервна текстура з зерен без зациклення: OLA зерен Ханна з випадковими позиціями в записі"""
    g = int(glen * FS)
    hop = g // 2
    out = np.zeros(n + 2 * g, np.float32)
    win = np.hanning(g).astype(np.float32)
    pos = 0
    while pos < n:
        o = int(rng.integers(0, max(1, len(src) - g)))
        out[pos:pos + g] += src[o:o + g] * win
        pos += hop
    return out[:n]


def _procedural(n, rng, bright=False):
    w = rng.standard_normal(n).astype(np.float32)
    pink = _lp(w, 2400) * 0.8 + _bp(w, 2500, 7500) * (0.55 if bright else 0.35)
    res = _bp(w, 1500, 2100, 2) * 0.5                        # резонанс паперу/столу
    return (pink + res) * 0.40


def _burst(ms, rng, fc_lo, fc_hi, decay):
    n = int(ms / 1000 * FS)
    x = _bp(rng.standard_normal(n).astype(np.float32), fc_lo, fc_hi)
    return x * np.exp(-np.arange(n) / (decay * FS)).astype(np.float32)


def build_foley2(audio_dir, contacts, kinds, speeds, tool_events, out_path, fps=60, mix=None, stroke_kind=None):
    """contacts[i] bool, kinds[i] 'ink'|'color', speeds[i] px/s (нормовані до 800 px), tool_events = [(t0,t1), ...].
    stroke_kind[i] - 'line'|'hatch'|'dab'|None для тиску. Повертає QA-словник."""
    m = dict(DEFAULT_MIX)
    m.update(mix or {})
    rng = np.random.default_rng(int(m['seed']))
    nf = len(contacts)
    n = nf * (FS // fps)
    c = np.asarray(contacts, bool)
    spd = np.asarray(speeds, np.float32)
    kind_ink = np.asarray([k == 'ink' for k in kinds], np.float32)
    # --- текстури ---
    if m['variant'] == 'procedural':
        tex_i = _procedural(n, rng, False)
        tex_c = _procedural(n, rng, True) * 0.9
    else:
        a, _ = _read(Path(audio_dir) / 'marker_active_passes.wav')
        b, _ = _read(Path(audio_dir) / 'scribbling_continuous.wav')
        # шумоподібне вирівнювання: прибираємо DC, нормуємо RMS, щоб різні записи звучали рівно
        def prep(x):
            x = x - x.mean()
            return x / (np.sqrt(np.mean(x ** 2)) + 1e-6) * 0.2
        tex_i = _grains(prep(a), n, rng)
        tex_c = _grains(prep(b), n, rng)
    tex_dark_i, tex_dark_c = _lp(tex_i, 1800), _lp(tex_c, 1800)
    # --- керуючі сигнали ---
    contact_s = _ctrl(c.astype(np.float32), fps, n)
    contact_s = _lp(contact_s, 55, 1)                         # ~3 мс плавності: без клацань
    sp = np.clip(spd / 260.0, 0, 1.4)
    sp = np.convolve(sp, np.ones(3) / 3, 'same')
    sp_s = _ctrl(sp, fps, n)
    bright = np.clip(sp_s * 0.9, 0, 1)                        # швидше - яскравіше
    gain = (0.12 + 0.88 * np.clip(sp_s, 0, 1.2) ** 0.75)      # тихо на повільному, але не мертво
    if stroke_kind is not None:
        pr = np.asarray([{'hatch': 1.0, 'line': 0.82, 'dab': 0.9}.get(k, 0.9) for k in stroke_kind], np.float32)
        gain = gain * _ctrl(pr, fps, n)
    ink_s = _ctrl(kind_ink, fps, n)
    tex = lambda d, br: d + (br - d) * bright
    t_i = tex_dark_i + (tex_i - tex_dark_i) * bright
    t_c = tex_dark_c + (tex_c - tex_dark_c) * bright
    contact_sig = (t_i * ink_s * m['ink_gain'] + t_c * (1 - ink_s) * m['color_gain']) * gain * contact_s * m['contact']
    out = contact_sig.astype(np.float32)
    # --- дотик / відрив ---
    edges = np.diff(c.astype(np.int8), prepend=0)
    for i in np.where(edges != 0)[0]:
        pos = int(i * FS / fps)
        down = edges[i] > 0
        b = _burst(26 if down else 18, rng, 900, 6500, 0.007 if down else 0.005) * (0.20 if down else 0.10) * m['touch']
        b *= 1.0 if kinds[min(i, nf - 1)] == 'ink' else 0.8
        e = min(n, pos + len(b))
        out[pos:e] += b[:e - pos]
    # --- шерех рукава під час руху поза папером ---
    air = _lp(_ctrl((~c).astype(np.float32), fps, n), 20, 1)
    sleeve = _bp(rng.standard_normal(n).astype(np.float32), 200, 1400) * air * 0.018 * m['sleeve']
    out += sleeve
    # --- зміна маркера: зняття та надягання ковпачка ---
    for (t0, t1) in tool_events:
        for tt, strength in ((t0 + 0.30, 1.0), (t1 - 0.26, 0.8)):
            pos = int(tt * FS)
            if 0 <= pos < n - 6000:
                pop = _burst(60, rng, 400, 4500, 0.018) * 0.12 * strength * m['cap']
                click = _burst(10, rng, 2500, 9000, 0.003) * 0.10 * strength * m['cap']
                out[pos:pos + len(pop)] += pop
                out[pos + 1500:pos + 1500 + len(click)] += click
    # --- тон кімнати ---
    room = _lp(rng.standard_normal(n).astype(np.float32), 900) * 0.0007 * m['room']
    out += room
    # --- м'який лімітер + нормування ---
    out = np.tanh(out * 1.6) / 1.6
    out = np.clip(out, -0.89, 0.89)
    with wave.open(str(out_path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(FS)
        w.writeframes((out * 32767).astype('<i2').tobytes())
    pk = float(np.max(np.abs(out)))
    rms = float(np.sqrt(np.mean(out ** 2)) + 1e-12)
    off = ~np.repeat(c, FS // fps)
    qa = dict(variant=m['variant'], peak_dbfs=round(20 * math.log10(pk + 1e-12), 1),
              rms_dbfs=round(20 * math.log10(rms), 1),
              offpaper_rms_dbfs=round(20 * math.log10(float(np.sqrt(np.mean(out[off] ** 2)) + 1e-12)), 1) if off.any() else None,
              contact_frames=int(c.sum()), mix={k: m[k] for k in m})
    qa['loudness'] = measure_loudness(out_path)
    return qa


def measure_loudness(path):
    r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(path), '-af', 'ebur128=peak=true', '-f', 'null', '-'],
                       capture_output=True, text=True)
    txt = r.stderr
    i = txt.rfind('Integrated loudness')
    lufs = None
    if i >= 0:
        for line in txt[i:].splitlines():
            if 'I:' in line:
                lufs = float(line.split('I:')[1].split('LUFS')[0])
                break
    return dict(integrated_lufs=lufs)
