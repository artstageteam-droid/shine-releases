"""Prompt Studio: форма -> JSON-запит для ChatGPT -> перевірка отриманих ілюстрацій (intake).

Принцип: чим суворіше ілюстрація відповідає "контракту", тим менше потрібно розумності в движку.
Контракт виведений з тестів (17 зображень): біле тло, товстий чорний контур, плоскі кольори,
стандартні очі (біла склера + суцільна зіниця + блік), об'єкти не торкаються, руки відокремлені від тулуба.

CLI:
  python promptgen.py make --kind set --subject "cute monsters" --count 6 --out req.json
  python promptgen.py check req.json returned.png
"""
import argparse, json, sys, time, uuid

KINDS = {
    "character": "один персонаж",
    "set": "набір персонажів (аркуш)",
    "objects": "набір предметів: машинки, їжа, іграшки (аркуш)",
    "scene": "сцена (фон + кілька предметів)  - ЛИШЕ малювання, без анімації очей",
}

CONTRACT = [
    "Pure white background (#FFFFFF), no gradient, no shadow on the ground, no texture, no frame.",
    "Flat sticker / coloring-book style: thick uniform black outline (about 1% of image width), flat fills, "
    "at most 1 soft highlight per shape, no gradients, no glow, no photographic lighting.",
    "Every object fully inside the canvas with at least 6% white margin; nothing cropped.",
    "Objects must NOT touch or overlap each other or the border; at least 5% white gap between objects.",
    "Square canvas 1254x1254 (or 1536x1024 for wide sets).",
    "No text, no letters, no logos, no watermark, no signature, no background props.",
]

EYES = [
    "Eyes in the standard cartoon form: white sclera ellipse with a thick black outline, one solid dark pupil "
    "that touches or nearly touches the sclera edge, one small white highlight inside the pupil.",
    "Eyes are fully open, not covered by hair, hat, brows or helmet; brows (if any) are separate thin strokes above the eye.",
    "Both eyes the same size, symmetric, placed in the upper half of the head.",
]

CHAR_POSE = [
    "Front view (or slight 3/4), standing or sitting, neutral relaxed pose, symmetrical.",
    "Arms hang down at the sides and are clearly separated from the body by a white or colour gap; "
    "no crossed arms, no hands in pockets, no hands holding objects (a held prop is a separate object).",
    "Mouth closed smile or small open smile, simple shapes.",
    "No motion lines, no sparkles, no hearts, no speech bubbles around the character.",
]

NEGATIVE = [
    "photorealistic", "3D render", "shading gradients", "text", "watermark", "background scenery",
    "overlapping objects", "cropped objects", "crossed arms", "hair covering eyes", "tiny dot eyes",
    "motion blur", "extra limbs",
]


def _layout(count, wide=False):
    cols = 3 if count > 4 else 2 if count > 1 else 1
    rows = -(-count // cols)
    return dict(cols=cols, rows=rows, canvas=[1536, 1024] if wide else [1254, 1254])


def make_request(kind, subject, count=1, style="flat sticker", palette="bright, saturated, child friendly",
                 extra="", variants=("base",), wide=None):
    """Повертає dict-запит. variants: base | blink | smile | surprise (кадри-патчі тієї ж картинки)."""
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {list(KINDS)}")
    count = 1 if kind == "character" else max(1, int(count))
    wide = (count > 4) if wide is None else wide
    lay = _layout(count, wide)
    rules = list(CONTRACT)
    if kind in ("character", "set"):
        rules += EYES + CHAR_POSE
    if kind == "objects":
        rules.append("Each object in clean 3/4 or side view, simple readable silhouette, no tiny parts smaller than 1% of width. "
                     "If an object has eyes (cartoon car, food) use the standard eye form.")
        rules += EYES[:1]
    if kind == "scene":
        rules = [r for r in rules if "No text" not in r and "background props" not in r and "touch" not in r]
        rules.append("Scene may have a complete background; keep outlines thick and fills flat.")
    if count > 1:
        rules.append(f"Arrange exactly {count} separate items in a clean grid of {lay['cols']} columns x {lay['rows']} rows, "
                     "equal cell size, each item centred in its cell, all items drawn at a similar size, no duplicates.")
    prompt = (f"Create a {style} illustration: {subject}. "
              + (f"Exactly {count} separate items, each different (different colour and shape). " if count > 1 else "")
              + f"Palette: {palette}. " + (extra + " " if extra else "")
              + "Follow ALL constraints strictly.")
    rid = time.strftime("%Y%m%d-") + uuid.uuid4().hex[:6]
    req = dict(
        id=rid, kind=kind, subject=subject, count=count,
        prompt=prompt, constraints=rules, negative=NEGATIVE, layout=lay,
        deliver=dict(format="PNG", background="white", images=1),
        expect=dict(objects=count, white_bg=True, eyes=kind in ("character", "set"), margin_frac=0.02),
    )
    # додаткові кадри для оживлення: ТА САМА картинка з мінімальною зміною (редагування, не нова генерація)
    vs = [v for v in variants if v != "base"]
    if vs and kind in ("character", "set"):
        edits = {
            "blink": "Same image, pixel-identical everything, but ALL eyes closed (simple curved lid line, no lashes).",
            "smile": "Same image, pixel-identical everything, but wide happy open-mouth smile.",
            "surprise": "Same image, pixel-identical everything, but eyes wide open and mouth a small round 'o'.",
        }
        req["followups"] = [dict(name=v, prompt=edits[v] + " Do not move, resize, recolour or redraw anything else. "
                                 "Keep the same canvas, same position, white background.") for v in vs if v in edits]
    return req


def chatgpt_text(req):
    """Готовий текст для вставки в ChatGPT (JSON + коротка інструкція)."""
    return ("Generate the image strictly following this JSON spec. Return exactly one PNG. "
            "If any constraint cannot be met, regenerate until it is.\n\n" + json.dumps(
                {k: req[k] for k in ("prompt", "constraints", "negative", "layout", "deliver")}, ensure_ascii=False, indent=2))


def check(req, img):
    """Перевірка зображення за контрактом. Повертає (ok, report dict). img: BGR ndarray."""
    import numpy as np, cv2
    sys.path.insert(0, __file__.rsplit("/", 1)[0])
    import sets
    rep, ok = {}, True
    H, W = img.shape[:2]
    border = np.concatenate([img[0], img[-1], img[:, 0], img[:, -1]])
    rep["white_bg"] = bool((border.min(1) > 240).mean() > 0.995)
    ok &= rep["white_bg"]
    objs = [o for o in sets.split_sheet(img) if o.kind == "object"]
    rep["objects"] = len(objs)
    exp = req["expect"]["objects"]
    rep["objects_ok"] = len(objs) == exp
    ok &= rep["objects_ok"]
    m = int(exp and req["expect"]["margin_frac"] * min(H, W))
    rep["touches_border"] = [i for i, o in enumerate(objs) if min(o.bbox[0], o.bbox[1], W - o.bbox[2], H - o.bbox[3]) < m] \
        if len(objs) and objs[0].bbox is not None else []
    ok &= not rep["touches_border"]
    if req["expect"].get("eyes"):
        import puppet
        miss = []
        for i, o in enumerate(objs):
            crop, _ = o.crop(img)
            ps = puppet.PuppetShow(cfg=dict(seconds=1.0, limbs=False, breathe=None, bounce_end=False), fps=30)
            try:
                ps.frame(0, crop)
                n = len(ps.eyes)
            except Exception:
                n = 0
            if n < 1:
                miss.append(i)
        rep["no_eyes_detected"] = miss
        ok &= not miss
    rep["ok"] = bool(ok)
    rep["advice"] = [t for c, t in [
        (not rep["white_bg"], "Тло не біле - попроси перегенерувати з чистим білим тлом."),
        (not rep["objects_ok"], f"Знайдено {rep['objects']} об'єктів замість {exp}: вони торкаються або злиті - попроси більші проміжки."),
        (bool(rep["touches_border"]), f"Об'єкти торкаються краю (№ {', '.join(str(i + 1) for i in rep['touches_border'])}) - попроси більші поля."),
        (bool(rep.get("no_eyes_detected")), "Очі не розпізнано - попроси стандартні очі (склера+зіниця+блік)."),
    ] if c]
    return ok, rep


def main(a=None):
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    m = sp.add_parser("make")
    m.add_argument("--kind", required=True, choices=list(KINDS))
    m.add_argument("--subject", required=True)
    m.add_argument("--count", type=int, default=1)
    m.add_argument("--style", default="flat sticker")
    m.add_argument("--palette", default="bright, saturated, child friendly")
    m.add_argument("--extra", default="")
    m.add_argument("--variants", default="base")
    m.add_argument("--out", default="request.json")
    c = sp.add_parser("check")
    c.add_argument("request")
    c.add_argument("image")
    args = ap.parse_args(a)
    if args.cmd == "make":
        req = make_request(args.kind, args.subject, args.count, args.style, args.palette, args.extra,
                           tuple(args.variants.split(",")))
        json.dump(req, open(args.out, "w"), ensure_ascii=False, indent=2)
        print(chatgpt_text(req))
        for f in req.get("followups", []):
            print("\n--- follow-up:", f["name"], "---\n" + f["prompt"])
    else:
        import cv2
        req = json.load(open(args.request))
        ok, rep = check(req, cv2.imread(args.image))
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
