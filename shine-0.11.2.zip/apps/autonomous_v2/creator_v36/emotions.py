"""Кінцівка ролику з виразами: після завершення малювання персонаж «міняє емоції».

Кадри - ТА САМА ілюстрація з іншим виразом (редагування в ChatGPT), вирівняна по тому самому кадру. Між кадрами - короткий
кросфейд, у кінці повернення до основного вигляду. Інтерфейс сумісний із puppet.PuppetShow: .frames, .frame(i, canvas).
Fail-closed: кадр, який не читається або має інші пропорції, пропускається.
"""
import numpy as np


class EmotionShow:
    def __init__(self, scene, files, fps=60, hold=1.3, fade=0.18):
        self.fps = fps
        self.hold, self.fade = int(round(hold * fps)), max(1, int(round(fade * fps)))
        self.imgs = []
        for f in files:
            try:
                self.imgs.append(scene.place_image(f))
            except Exception:
                continue
        # ключові кадри: основний (пауза), вирази..., основний (пауза); між ними кросфейд
        self.holds = [self.hold // 2] + [self.hold] * len(self.imgs) + [self.hold // 2 + self.fade]
        self.frames = sum(self.holds) + self.fade * (len(self.holds) - 1) if self.imgs else 0

    def frame(self, i, canvas):
        seq = [canvas] + self.imgs + [canvas]
        t = i
        for k, h in enumerate(self.holds):
            if t < h:
                return seq[k]
            t -= h
            if k == len(self.holds) - 1:
                break
            if t < self.fade:
                a = (t + 1) / float(self.fade + 1)
                a = a * a * (3 - 2 * a)
                return (seq[k].astype(np.float32) * (1 - a) + seq[k + 1].astype(np.float32) * a).astype(np.uint8)
            t -= self.fade
        return canvas
