#!/usr/bin/env python3
"""PngScene - сцена з растрової картинки (чорний контур + пласкі кольори) замість SVG.

Той самий інтерфейс, що й planner.Scene (members, ids, ref, mask, mask_hi, ref_hi, coverage), тож planner/painter2/render
працюють без змін. Контур = ОДИН член 'ink_rim' (центральні лінії трасуються планувальником зі скелета), кольорові
області = окремі члени 'region' (зв'язні компоненти плаского кольору). Білі області (відблиски) - 'paper': не малюються.
"""
from __future__ import annotations

import hashlib
import io
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from scipy import ndimage

INK_MAX = 72           # піксель вважається чорнилом, якщо max(R,G,B) < INK_MAX


def _nearest_fill(lab, valid):
    """заповнює невалідні пікселі найближчою валідною міткою"""
    idx = ndimage.distance_transform_edt(~valid, return_distances=False, return_indices=True)
    return lab[idx[0], idx[1]]


class PngScene:
    def __init__(self, png, W=1280, H=720, target_box=(300, 50, 960, 670), k=4, n_colors=12, min_region_px=60):
        self.path = Path(png)
        raw = self.path.read_bytes()
        self.source_sha = hashlib.sha256(raw).hexdigest()
        im = Image.open(io.BytesIO(raw)).convert('RGB')
        self.W, self.H, self.k = W, H, k
        x0, y0, x1, y1 = target_box
        # пропорції зберігаються: вписуємо в target_box по меншому масштабу (раніше все тягнулось у квадрат)
        scale = min((x1 - x0) / im.width, (y1 - y0) / im.height)
        sw, sh = max(1, int(round(im.width * scale))), max(1, int(round(im.height * scale)))
        ox, oy = int(x0 + ((x1 - x0) - sw) / 2), int(y0 + ((y1 - y0) - sh) / 2)
        self.zoom = scale
        self.place = (ox, oy, sw, sh)
        self.viewbox = (0, 0, W, H)
        self._clip = None
        self._hi = {}
        # --- растри: 1x (канвас) і k-кратний ---
        sq = im.resize((sw, sh), Image.LANCZOS)
        ref = np.full((H, W, 3), 255, np.uint8)
        ref[oy:oy + sh, ox:ox + sw] = np.asarray(sq)
        self.ref = ref
        big = np.full((H * k, W * k, 3), 255, np.uint8)
        big[oy * k:(oy + sh) * k, ox * k:(ox + sw) * k] = np.asarray(im.resize((sw * k, sh * k), Image.LANCZOS))
        self._ref_big = big
        inside = np.zeros((H * k, W * k), bool)
        inside[oy * k:(oy + sh) * k, ox * k:(ox + sw) * k] = True
        # --- чорнило ---
        mx = big.max(2)
        ink = (mx < INK_MAX) & inside
        ink = cv2.morphologyEx(ink.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8)).astype(bool)
        ink_rgb = tuple(int(v) for v in np.median(big[ink], axis=0)) if ink.any() else (24, 16, 16)
        # --- кольори: k-means по вибірці нечорнильних пікселів 1x ---
        small = ref.reshape(-1, 3)
        nonink1 = (small.max(1) >= INK_MAX)
        samp = small[nonink1][::7].astype(np.float32)
        crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.5)
        _, _, centers = cv2.kmeans(samp, n_colors, None, crit, 3, cv2.KMEANS_PP_CENTERS)
        merged = []
        for c in centers:
            for m in merged:
                if np.linalg.norm(c - m) < 28:
                    break
            else:
                merged.append(c)
        centers = np.array(merged, np.float32)
        lab = np.zeros(big.shape[:2], np.uint8)
        for y in range(0, big.shape[0], 512):                       # шматками, щоб не з'їсти пам'ять
            blk = big[y:y + 512].astype(np.float32)
            d = ((blk[:, :, None, :] - centers[None, None, :, :]) ** 2).sum(3)
            lab[y:y + 512] = d.argmin(2).astype(np.uint8)
        # --- прибираємо тонкі кластери антиаліасних облямівок: opening по кожній мітці ---
        r = max(2, int(1.2 * k))
        el = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
        keep = np.zeros(lab.shape, bool)
        lab_clean = np.full(lab.shape, 255, np.uint8)
        for ci in range(len(centers)):
            m = (lab == ci) & ~ink & inside
            if not m.any():
                continue
            o = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, el).astype(bool)
            lab_clean[o] = ci
            keep |= o
        # під чорнилом і в зоні облямівок колір береться від найближчої стабільної області
        lab_full = _nearest_fill(lab_clean, keep) if keep.any() else lab_clean
        # --- компоненти -> члени ---
        members, ids_hi = [], np.zeros(lab.shape, np.int32)
        white_thr = 246
        n = 0
        for ci in range(len(centers)):
            m = (lab_full == ci) & ~ink & inside
            if not m.any():
                continue
            cc, nn = ndimage.label(m)
            sizes = ndimage.sum(m, cc, range(1, nn + 1))
            rgb = tuple(int(round(v)) for v in centers[ci])
            is_white = min(rgb) >= white_thr
            for j, sz in enumerate(sizes, start=1):
                if sz < min_region_px * k * k / 4:
                    continue
                n += 1
                ids_hi[cc == j] = n
                members.append(dict(id=f'png_r{n:03d}', role='paper' if is_white else 'region', fill=list(rgb),
                                    visible_px=0, bbox_px=None))
        n += 1
        ids_hi[ink] = n
        members.append(dict(id='png_ink', role='ink_rim', fill=list(ink_rgb), visible_px=0, bbox_px=None))
        # дрібні нерозподілені пікселі (відкинуті мілкі компоненти) -> найближчий член
        zero = (ids_hi == 0) & inside
        if zero.any():
            ids_hi = _nearest_fill(ids_hi, ~zero | ~inside)
            ids_hi[~inside] = 0
        self.members = members
        self._hi[k] = ids_hi
        self.ids = ids_hi[k // 2::k, k // 2::k].copy()
        for i, m in enumerate(members):
            m['visible_px'] = int((self.ids == i + 1).sum())
        self._find_under()

    def _find_under(self):
        """Області без власної чорної окантовки, оточені іншою областю (щічки, відблиски кольору): спершу фарбується
        основна область ПІД ними, потім вони накладаються поверх - білих «дір» у процесі немає."""
        ids, M = self.ids, self.members
        ink_id = len(M)
        paper = {i + 1 for i, m in enumerate(M) if m['role'] == 'paper'}
        el = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        area = {i: m['visible_px'] for i, m in enumerate(M)}
        self.under = {}
        for i, m in enumerate(M):
            if m['role'] != 'region' or m['visible_px'] < 20:
                continue
            mk = ids == i + 1
            ring = cv2.dilate(mk.astype(np.uint8), el).astype(bool) & ~mk
            if ring.sum() < 8:
                continue
            cnt = np.bincount(ids[ring], minlength=len(M) + 1)
            tot = cnt.sum()
            ink_share = cnt[ink_id] / max(1, tot)
            cnt[i + 1] = 0
            cnt[ink_id] = 0
            for p in paper:
                cnt[p] = 0
            top = int(cnt.argmax())
            rest = max(1, tot - (cnt.sum() * 0 + int(np.bincount(ids[ring], minlength=len(M) + 1)[ink_id])))
            if top and ink_share < 0.30 and cnt[top] / rest >= 0.8 and area[i] < 0.35 * area[top - 1] \
                    and M[top - 1]['role'] == 'region':
                self.under[i] = top - 1
        # ланцюжки -> корінь
        for i in list(self.under):
            r, seen = self.under[i], 0
            while r in self.under and seen < 5:
                r, seen = self.under[r], seen + 1
            self.under[i] = r
        for i, p in self.under.items():
            M[i]['under'] = M[p]['id']
        self._children = {}
        for i, p in self.under.items():
            self._children.setdefault(p, []).append(i)

    # ---------------- інтерфейс Scene -------------------------------------------------------------
    def mask(self, i):
        m = self.ids == (i + 1)
        for c in self._children.get(i, []):
            m = m | (self.ids == (c + 1))
        return m

    def _ids_k(self, k):
        if k not in self._hi:
            self._hi[k] = cv2.resize(self._hi[self.k].astype(np.int32), (self.W * k, self.H * k), interpolation=cv2.INTER_NEAREST)
        return self._hi[k]

    def mask_hi(self, idxs, k=3):
        ids = self._ids_k(k)
        out = np.zeros(ids.shape, bool)
        for i in idxs:
            out |= ids == (i + 1)
            for c in self._children.get(i, []):
                out |= ids == (c + 1)
        return out

    def place_image(self, png):
        """Інша версія тієї ж ілюстрації (вираз обличчя) -> кадр H x W BGR на тому самому місці, що й еталон."""
        im = Image.open(png).convert('RGB')
        ox, oy, sw, sh = self.place
        out = np.full((self.H, self.W, 3), 255, np.uint8)
        out[oy:oy + sh, ox:ox + sw] = np.asarray(im.resize((sw, sh), Image.LANCZOS))
        return np.ascontiguousarray(out[:, :, ::-1])

    def ref_hi(self, k=4):
        if k == self.k:
            return self._ref_big
        return cv2.resize(self._ref_big, (self.W * k, self.H * k), interpolation=cv2.INTER_AREA)

    def coverage(self, k=None):
        k = k or self.k                      # власна кратність: без нерівномірного перерахунку 3->4 (давав «сходинки»)
        key = ('cov', k)
        if key in self._hi:
            return self._hi[key]
        ids = self._ids_k(k)
        out = {}
        for lab, sl in enumerate(ndimage.find_objects(ids.astype(np.int32)), start=1):
            if sl is None or lab - 1 >= len(self.members):
                continue
            y0, y1 = sl[0].start // k, -(-sl[0].stop // k)
            x0, x1 = sl[1].start // k, -(-sl[1].stop // k)
            blk = ids[y0 * k:y1 * k, x0 * k:x1 * k]
            sub = (blk == lab).astype(np.float32)
            for c in self._children.get(lab - 1, []):
                sub = np.maximum(sub, (blk == c + 1).astype(np.float32))
            out[lab - 1] = (y0, y1, x0, x1, sub.reshape(y1 - y0, k, x1 - x0, k).mean(axis=(1, 3)))
        self._hi[key] = out
        return out
