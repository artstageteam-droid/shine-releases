"""Моргання ПІД ЧАС малювання.

Кадри моргання беруться з puppet (той самий детектор очей і ворота fail-closed) і накладаються на поточне полотно
лише коли ділянка, яку змінює моргання, вже ПОВНІСТЮ збігається з одним з двох еталонів:
  * «контурний» - тільки лінії на білому (очі домальовані, обличчя ще не зафарбоване) -> моргаємо ще в контурній фазі;
  * «кольоровий» - кінцева картинка (колір під повіками вже на місці).
Інакше моргання відкладається до готовності. Немає очей - нічого не відбувається.
"""
import os

import cv2
import numpy as np


def ink_only(ref_bgr):
    """чернетка еталона: лише темні лінії на білому (чорнило), без кольорових заливок"""
    mx = ref_bgr.max(2).astype(np.float32)
    a = np.clip((140.0 - mx) / 100.0, 0, 1)[:, :, None]
    ink = np.float32([22, 18, 18])
    return np.uint8(np.clip(255.0 * (1 - a) + ink * a + 0.5, 0, 255))


class _Set:
    def __init__(self, ref, fps, dur):
        import puppet
        self.ok = False
        ps = puppet.PuppetShow(cfg=dict(seconds=1.0, limbs=False, breathe=None, bounce_end=False, blink=True,
                                        blink_times=[0.0]), fps=fps)
        frames = [ps.frame(k, ref) for k in range(int(dur * fps) + 1)]
        if not ps.eyes:
            return
        r16 = ref.astype(np.int16)
        mask = np.zeros(ref.shape[:2], bool)
        for f in frames:
            mask |= (np.abs(f.astype(np.int16) - r16).max(2) > 3)
        if not mask.any():
            return
        ys, xs = np.nonzero(mask)
        pad = 6
        self.y0, self.y1 = max(0, ys.min() - pad), min(ref.shape[0], ys.max() + pad + 1)
        self.x0, self.x1 = max(0, xs.min() - pad), min(ref.shape[1], xs.max() + pad + 1)
        sl = (slice(self.y0, self.y1), slice(self.x0, self.x1))
        self.m = cv2.dilate(mask[sl].astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
        self.ref_roi = ref[sl].astype(np.int16)
        self.patch = [f[sl].copy() for f in frames]
        self.ok = True

    def ready(self, canvas):
        roi = canvas[self.y0:self.y1, self.x0:self.x1].astype(np.int16)
        bad = (np.abs(roi - self.ref_roi).max(2) > 80) & self.m
        fr = float(bad.sum()) / max(1, int(self.m.sum()))
        if os.environ.get('SHINE_DEBUG_BLINK'):
            self.n = getattr(self, 'n', 0) + 1
            if self.n % 240 == 0:
                print('DBG', id(self) % 1000, round(fr, 3), flush=True)
        return fr < 0.04


class LiveBlink:
    DUR = 0.28

    def __init__(self, ref_bgr, fps=60, seed=7, first=2.5):
        self.rng = np.random.default_rng(seed)
        self.sets = []
        for r in (ref_bgr, None):
            try:                                   # будь-яка помилка детектора = без моргання (відео не ламаємо)
                st = _Set(ref_bgr if r is not None else ink_only(ref_bgr), fps, self.DUR)
                if st.ok:
                    self.sets.append(st)
            except Exception:
                continue
        self.ok = bool(self.sets)
        self.start, self.cur, self.next_t = None, None, first

    def apply(self, t, i, canvas):
        if not self.ok:
            return canvas, False
        if self.start is None:
            if t < self.next_t:
                return canvas, False
            st = next((s for s in self.sets if s.ready(canvas)), None)       # спершу кольоровий, потім контурний
            if st is None:
                return canvas, False
            self.start, self.cur = i, st
            if os.environ.get('SHINE_DEBUG_BLINK'):
                print(f'BLINK {t:.2f}', flush=True)
        st = self.cur
        k = i - self.start
        if k >= len(st.patch):
            self.start = None
            self.next_t = t + (0.5 if self.rng.random() < 0.25 else float(self.rng.uniform(4.0, 8.0)))
            return canvas, False
        out = canvas.copy()
        roi = out[st.y0:st.y1, st.x0:st.x1]
        roi[st.m] = st.patch[k][st.m]
        return out, True
