#!/usr/bin/env python3
"""SHINE Creator planner v36 - natural, editable drawing plan from a prepared SVG.

Input : source SVG + `prepare_v36` annotations (roles) + a selection of drawable ids (an "object").
Output: `plan.json` (strokes as 1px-resampled polylines, chapters, tool order) and the
        masks needed by the renderer.  No Fox/Dragon knowledge: everything comes from visible
        geometry measured on the real painter-order raster ("Visible Ink").

Design (what is different from v24's raster trace):
  * outline  = centre-line of the *visible* thin ink regions, walked as continuous pen trails that
               prefer the straightest continuation at junctions (few lifts, no 1-px zig-zag);
  * colour   = one serpentine route per region (rows along the region's main axis), rows are
               linked inside the region (the pen stays down), one marker per colour (a "chapter");
  * thick parts of ink shapes (nose, collar) are filled, not traced;
  * coverage is verified and gaps are repaired, so the final picture equals the reference.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import sys
from collections import defaultdict
from pathlib import Path


def _cairosvg():
    """Ледачий імпорт: Cairo потрібна лише для SVG-шляху (на Windows її окремо ставлять)."""
    import cairosvg
    return cairosvg

import colorsys
import cv2
import numpy as np
from lxml import etree
from PIL import Image
from skimage.morphology import skeletonize

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'prepare_v36'))
import svg_prepare as sp  # noqa: E402

INK_ROLES = {'ink_rim', 'ink_stroke'}
FILL_ROLES = {'region', 'speck'}


# ------------------------------------------------------------------ scene --------------------------
class Scene:
    """A selection of drawables rendered into a fixed canvas (the 'camera' framing the object)."""

    def __init__(self, svg, ann, member_ids, W=1280, H=720, target_box=(330, 60, 1250, 660), clip_raster=None):
        """clip_raster: (x0,y0,x1,y1) у растрових px анотації - показується лише це «вікно» (фрагмент ілюстрації)."""
        self.svg = Path(svg)
        self.W, self.H = W, H
        root0, _ = sp.load_svg(self.svg)
        root = sp.normalize(root0)
        nodes = sp._drawables(root)
        assert len(nodes) == len(ann['items'])
        keep = {i['id'] for i in ann['items'] if i['id'] in set(member_ids)}
        scale_a = ann['canvas']['raster'][0] / ann['canvas']['viewBox'][2]
        items = [i for i in ann['items'] if i['id'] in keep and i['bbox_px']]
        x0 = min(i['bbox_px'][0] for i in items) / scale_a
        y0 = min(i['bbox_px'][1] for i in items) / scale_a
        x1 = max(i['bbox_px'][2] for i in items) / scale_a
        y1 = max(i['bbox_px'][3] for i in items) / scale_a
        if clip_raster:
            x0, y0, x1, y1 = (v / scale_a for v in clip_raster)
        tx0, ty0, tx1, ty1 = target_box
        s = min((tx1 - tx0) / (x1 - x0), (ty1 - ty0) / (y1 - y0))
        ox = tx0 + ((tx1 - tx0) - (x1 - x0) * s) / 2
        oy = ty0 + ((ty1 - ty0) - (y1 - y0) * s) / 2
        self.zoom = s
        self.viewbox = (x0 - ox / s, y0 - oy / s, W / s, H / s)
        # sub-tree with the members only (their painter order is preserved)
        sub = copy_tree(root)
        sub_nodes = sp._drawables(sub)
        self.members = []
        for e, it in zip(sub_nodes, ann['items']):
            if it['id'] in keep:
                self.members.append(it)
            else:
                e.getparent().remove(e)
        for e in list(sub.iter()):
            if sp.local(e.tag) in {'metadata', 'title', 'desc'}:
                e.getparent().remove(e)
        sub_nodes = sp._drawables(sub)
        assert len(sub_nodes) == len(self.members)
        self.ids = sp._id_map(sub, sub_nodes, W, H, viewbox=self.viewbox)
        self._sub, self._sub_nodes, self._hi = sub, sub_nodes, {}
        self._clip = None
        if clip_raster:
            cx0, cy0, cx1, cy1 = [(clip_raster[0] / scale_a - self.viewbox[0]) * s, (clip_raster[1] / scale_a - self.viewbox[1]) * s,
                                  (clip_raster[2] / scale_a - self.viewbox[0]) * s, (clip_raster[3] / scale_a - self.viewbox[1]) * s]
            self._clip = (cx0, cy0, cx1, cy1)
            self.ids = self._clipped(self.ids, 1)
        sub.set('viewBox', ' '.join(str(float(v)) for v in self.viewbox))
        sub.set('width', str(W)); sub.set('height', str(H)); sub.set('preserveAspectRatio', 'none')
        png = _cairosvg().svg2png(bytestring=etree.tostring(sub), output_width=W, output_height=H, background_color='white')
        self.ref = np.array(Image.open(io.BytesIO(png)).convert('RGB'))      # RGB reference picture
        if self._clip:
            out_ = self._clipped(np.ones(self.ref.shape[:2], np.int64), 1) == 0
            self.ref[out_] = 255
        self.source_sha = ann['source']['sha256']

    def _clipped(self, ids, k):
        if not self._clip:
            return ids
        ids = ids.copy()
        h, w = ids.shape
        x0, y0, x1, y1 = (int(round(v * k)) for v in self._clip)
        keep = np.zeros(ids.shape, bool)
        keep[max(0, y0):min(h, y1), max(0, x0):min(w, x1)] = True
        ids[~keep] = 0
        return ids

    def mask(self, member_index):
        return self.ids == (member_index + 1)

    def ref_hi(self, k=4):
        """Антиаліасна надвибіркова картинка сцени (RGB), k-кратне розрішення."""
        key = ('ref', k)
        if key not in self._hi:
            sub = copy_tree(self._sub)
            sub.set('viewBox', ' '.join(str(float(v)) for v in self.viewbox))
            sub.set('width', str(self.W * k)); sub.set('height', str(self.H * k)); sub.set('preserveAspectRatio', 'none')
            png = _cairosvg().svg2png(bytestring=etree.tostring(sub), output_width=self.W * k, output_height=self.H * k,
                                   background_color='white')
            img = np.array(Image.open(io.BytesIO(png)).convert('RGB'))
            if self._clip:
                img[self._clipped(np.ones(img.shape[:2], np.int64), k) == 0] = 255
            self._hi[key] = img
        return self._hi[key]

    def coverage(self, k=4):
        """Дробове покриття ВИДИМОГО власника для кожного члена (k-кратна надвибірка): {i: (y0,y1,x0,x1,cov float32)}.
        Видимі власники не перетинаються, тому кадр = білий*(1-Σa) + Σ a*колір - лінійно й точно як рендер SVG."""
        key = ('cov', k)
        if key in self._hi:
            return self._hi[key]
        from scipy import ndimage
        if k not in self._hi:
            self._hi[k] = self._clipped(sp._id_map(self._sub, self._sub_nodes, self.W * k, self.H * k, viewbox=self.viewbox), k)
        ids = self._hi[k]
        out = {}
        for lab, sl in enumerate(ndimage.find_objects(ids.astype(np.int32)), start=1):
            if sl is None or lab - 1 >= len(self.members):
                continue
            y0, y1 = sl[0].start // k, -(-sl[0].stop // k)
            x0, x1 = sl[1].start // k, -(-sl[1].stop // k)
            sub = (ids[y0 * k:y1 * k, x0 * k:x1 * k] == lab).astype(np.float32)
            cov = sub.reshape(y1 - y0, k, x1 - x0, k).mean(axis=(1, 3))
            out[lab - 1] = (y0, y1, x0, x1, cov)
        self._hi[key] = out
        return out

    def mask_hi(self, member_indices, k=3):
        """Маска об'єднання членів у k-кратному розрішенні (ободок ~1 px на канвасі стає суцільним)."""
        if k not in self._hi:
            self._hi[k] = self._clipped(sp._id_map(self._sub, self._sub_nodes, self.W * k, self.H * k, viewbox=self.viewbox), k)
        ids = self._hi[k]
        out = np.zeros(ids.shape, bool)
        for i in member_indices:
            out |= ids == (i + 1)
        return out


def copy_tree(root):
    import copy
    return copy.deepcopy(root)


# ------------------------------------------------------------------ geometry helpers ---------------
def resample(poly, step=1.0):
    p = np.asarray(poly, np.float64)
    if len(p) < 2:
        return p
    seg = np.hypot(*(np.diff(p, axis=0).T))
    s = np.concatenate([[0], np.cumsum(seg)])
    if s[-1] < 1e-6:
        return p[:1]
    n = max(2, int(round(s[-1] / step)) + 1)
    t = np.linspace(0, s[-1], n)
    return np.stack([np.interp(t, s, p[:, 0]), np.interp(t, s, p[:, 1])], 1)


def chaikin(poly, it=2):
    p = np.asarray(poly, np.float64)
    for _ in range(it):
        if len(p) < 3:
            break
        q = 0.75 * p[:-1] + 0.25 * p[1:]
        r = 0.25 * p[:-1] + 0.75 * p[1:]
        mid = np.empty((len(q) * 2, 2))
        mid[0::2], mid[1::2] = q, r
        p = np.vstack([p[:1], mid, p[-1:]])
    return p


def poly_len(p):
    return float(np.hypot(*(np.diff(p, axis=0).T)).sum()) if len(p) > 1 else 0.0


NB = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def trace_skeleton(sk, min_len=3):
    """Walk a 1-px skeleton into continuous trails: straightest continuation at junctions."""
    pts = set(zip(*[a.tolist() for a in np.nonzero(sk)]))
    if not pts:
        return []

    def nbrs(p):
        return [(p[0] + dy, p[1] + dx) for dy, dx in NB if (p[0] + dy, p[1] + dx) in pts]
    deg = {p: len(nbrs(p)) for p in pts}
    visited, trails = set(), []

    def walk(start):
        path = [start]
        visited.add(start)
        cur = start
        while True:
            cand = [q for q in nbrs(cur) if q not in visited]
            if not cand:
                break
            if len(path) >= 2:
                k = min(len(path) - 1, 6)
                hv = np.array([cur[1] - path[-1 - k][1], cur[0] - path[-1 - k][0]], float)
                hv /= (np.linalg.norm(hv) + 1e-9)
                best = max(cand, key=lambda q: float(np.dot(hv, np.array([q[1] - cur[1], q[0] - cur[0]], float) /
                                                       math.hypot(q[1] - cur[1], q[0] - cur[0]))))
            else:
                best = min(cand, key=lambda q: abs(q[0] - cur[0]) + abs(q[1] - cur[1]))
            for q in cand:                                    # staircase shoulders are not branches
                if q != best and max(abs(q[0] - best[0]), abs(q[1] - best[1])) <= 1:
                    visited.add(q)
            path.append(best)
            visited.add(best)
            cur = best
        return path

    while len(visited) < len(pts):
        rest = [p for p in pts if p not in visited]
        ends = [p for p in rest if deg[p] == 1]
        if ends:
            start = min(ends, key=lambda p: (p[1], p[0]))
        else:
            touching = [p for p in rest if any(q in visited for q in nbrs(p))]
            start = min(touching or rest, key=lambda p: (p[1], p[0]))
        path = walk(start)
        if len(path) >= min_len:
            trails.append(np.array([[x, y] for y, x in path], np.float64))
    return trails


def region_skeleton_trails(mask, min_len=3):
    sk = skeletonize(mask > 0)
    return trace_skeleton(sk, min_len)


def hatch_trails(mask, step, angle_deg, ext=0.0):
    """Serpentine rows (along `angle_deg`) linked inside the region; returns polylines in x,y."""
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return []
    th = math.radians(angle_deg)
    c, s = math.cos(th), math.sin(th)
    u = xs * c + ys * s
    v = -xs * s + ys * c
    r = np.rint(v / step).astype(int)
    rows = {}
    for ri in np.unique(r):
        sel = r == ri
        uu = np.sort(np.unique(np.rint(u[sel]).astype(int)))
        # runs: gaps larger than 2 px start a new run
        cut = np.nonzero(np.diff(uu) > 2)[0]
        starts = np.concatenate([[0], cut + 1])
        ends = np.concatenate([cut, [len(uu) - 1]])
        rows[int(ri)] = [(float(uu[a]), float(uu[b])) for a, b in zip(starts, ends)]
    # link runs of consecutive rows greedily by overlap
    nxt, prv = {}, {}
    for ri in sorted(rows):
        if ri + 1 not in rows:
            continue
        cand = []
        for ai, (a0, a1) in enumerate(rows[ri]):
            for bi, (b0, b1) in enumerate(rows[ri + 1]):
                ov = min(a1, b1) - max(a0, b0)
                if ov >= 2:
                    cand.append((ov, ai, bi))
        for ov, ai, bi in sorted(cand, reverse=True):
            if (ri, ai) in nxt or (ri + 1, bi) in prv:
                continue
            nxt[(ri, ai)] = (ri + 1, bi)
            prv[(ri + 1, bi)] = (ri, ai)
    trails = []
    for ri in sorted(rows):
        for ai in range(len(rows[ri])):
            if (ri, ai) in prv:
                continue
            node, dirn, pts = (ri, ai), 1, []
            while node is not None:
                a0, a1 = rows[node[0]][node[1]]
                vv = node[0] * step
                seg = [(a0 - ext, vv), (a1 + ext, vv)] if dirn > 0 else [(a1 + ext, vv), (a0 - ext, vv)]
                pts.extend(seg)
                node = nxt.get(node)
                dirn = -dirn
            arr = np.array(pts, np.float64)
            x = arr[:, 0] * c - arr[:, 1] * s
            y = arr[:, 0] * s + arr[:, 1] * c
            trails.append(np.stack([x, y], 1))
    return trails


def main_axis_angle(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) < 5:
        return 0.0
    cov = np.cov(np.stack([xs, ys]).astype(float))
    w, v = np.linalg.eigh(cov)
    ang = math.degrees(math.atan2(v[1, 1], v[0, 1]))
    if w[1] < 2.2 * max(w[0], 1e-6):          # майже круглі/квадратні області: діагональна штриховка, як малює людина
        return -35.0
    return round(ang / 15.0) * 15.0


def smooth_poly(pts, sigma, closed_tol=0.0):
    """Гаусове згладжування траєкторії руки (розмір у px): прибирає тремтіння скелета, не зсуває лінію на >~1 px."""
    from scipy.ndimage import gaussian_filter1d
    p = np.asarray(pts, float)
    if len(p) < 8 or sigma <= 0:
        return p
    closed = np.hypot(*(p[0] - p[-1])) < max(closed_tol, 1.5)
    mode = 'wrap' if closed else 'nearest'
    q = np.stack([gaussian_filter1d(p[:, 0], sigma, mode=mode), gaussian_filter1d(p[:, 1], sigma, mode=mode)], 1)
    if closed:
        q[-1] = q[0]
    return q            # кінці не «пришпилюємо»: це давало гачки на початку/кінці штриха


def remove_backsteps(pts, max_back=8.0):
    """Прибирає мікро-відкоти (<max_back px) вздовж штриха: наконечник не смикається назад."""
    p = np.asarray(pts, float)
    out = [p[0]]
    for q in p[1:]:
        if len(out) >= 2:
            a, b = out[-1] - out[-2], q - out[-1]
            if float(a @ b) < 0 and np.linalg.norm(b) < max_back:
                continue
        out.append(q)
    return np.array(out)


def split_at_cusps(pts, k=6, min_ang=2.2, min_piece=8.0):
    """Рука не розвертається на 180° посеред штриха: у місці розвороту штрих ділиться (підйом пера)."""
    p = np.asarray(pts, float)
    n = len(p)
    cut = []
    for i in range(k, n - k):
        a, b = p[i] - p[i - k], p[i + k] - p[i]
        na, nb = np.linalg.norm(a), np.linalg.norm(b)
        if na > 3 and nb > 3 and abs(math.atan2(a[0] * b[1] - a[1] * b[0], float(a @ b))) > min_ang:
            if not cut or i - cut[-1] > 2 * k:
                cut.append(i)
    if not cut:
        return [p]
    idx = [0] + cut + [n - 1]
    return [p[a:b + 1] for a, b in zip(idx[:-1], idx[1:]) if poly_len(p[a:b + 1]) >= min_piece]


# ------------------------------------------------------------------ planning -----------------------
def rgb_str(rgb):
    return 'rgb(%d,%d,%d)' % tuple(int(x) for x in rgb)


def _assign_ink_clusters(scene, strokes, ink_fill, K, tol=70):
    """Колір пера контурного штриха = колір ink-члена, вздовж якого він іде (кластер близьких темних відтінків)."""
    cols = sorted(ink_fill, key=lambda c: -ink_fill[c])
    reps = []
    for c in cols:
        if all(sum(abs(a - b) for a, b in zip(c, r)) > tol for r in reps):
            reps.append(c)
    if len(reps) <= 1 or K not in scene._hi:
        return
    ids = scene._hi[K]
    for st in strokes:
        # st['pts'] поки що в канвас-координатах
        p = np.rint(np.asarray(st['pts']) * K + (K - 1) / 2).astype(int)
        p[:, 0] = np.clip(p[:, 0], 0, ids.shape[1] - 1); p[:, 1] = np.clip(p[:, 1], 0, ids.shape[0] - 1)
        got = ids[p[::4, 1], p[::4, 0]]
        votes = defaultdict(int)
        for g in got:
            if 0 < g <= len(scene.members):
                c = tuple(scene.members[g - 1]['fill'])
                best = min(reps, key=lambda r: sum(abs(a - b) for a, b in zip(c, r)))
                votes[best] += 1
        if votes:
            st['fill'] = rgb_str(max(votes, key=votes.get))


def finish_line_ends(pts, w, hook_len=1.8, hook_deg=50.0, ext=0.45):
    """Прибирає «засічки» (короткі різкі гачки на кінцях) і трохи подовжує кінці, щоб лінії сходились на стиках."""
    P = np.asarray(pts, float)
    if len(P) < 5:
        return P
    for end in (0, 1):
        if end == 1:
            P = P[::-1]
        d = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
        if d[-1] > 6 * w:
            j = int(np.searchsorted(d, hook_len * w))                    # кінцева ділянка довжини ~hook_len*w
            j2 = int(np.searchsorted(d, 3.4 * w))
            if 2 <= j < j2 < len(P):
                v1 = P[j] - P[0]
                v2 = P[min(len(P) - 1, j2)] - P[j]
                n1, n2 = np.hypot(*v1), np.hypot(*v2)
                if n1 > 1e-6 and n2 > 1e-6:
                    cosang = float(np.dot(v1, v2) / (n1 * n2))
                    if np.degrees(np.arccos(np.clip(cosang, -1, 1))) > hook_deg:
                        P = P[j:]
        if end == 1:
            P = P[::-1]
    # подовжити обидва кінці по дотичній (фарба обрізається по видимій формі, тож не вилізе за контур)
    out = P
    for end in (0, 1):
        Q = out if end == 1 else out[::-1]
        k = min(len(Q) - 1, 3)
        t = Q[-1] - Q[-1 - k]
        n = np.hypot(*t)
        if n > 1e-6:
            Q = np.vstack([Q, Q[-1] + t / n * ext * w])
        out = Q if end == 1 else Q[::-1]
    return out


def build_plan(scene, ink_width=None, color_width=14, ink_rgb=None, join_px=22, order_hint=None, min_fill_px=40, direction=None, ink_group_order=False, ink_scale=1.0, order='human', trace='loops'):
    """min_fill_px: видимі шматки менше за це не малюються (підпіксельні плями); вони перелічені в plan['skipped']."""
    W, H = scene.W, scene.H
    members = scene.members
    ink_idx = [i for i, m in enumerate(members) if m['role'] in INK_ROLES]
    fill_all = [i for i, m in enumerate(members) if m['role'] in FILL_ROLES and m['visible_px'] > 0]
    fill_idx = [i for i in fill_all if int(scene.mask(i).sum()) >= min_fill_px]
    skipped = [dict(member=members[i]['id'], px=int(scene.mask(i).sum()), fill=rgb_str(members[i]['fill']))
               for i in fill_all if i not in set(fill_idx)]
    strokes = []
    covered_ink = np.zeros((H, W), np.uint8)

    # ---- outline phase -------------------------------------------------------------------------
    ink_mask = np.zeros((H, W), np.uint8)
    for i in ink_idx:
        ink_mask |= scene.mask(i).astype(np.uint8)
    ink_fill = {}
    for i in ink_idx:
        ink_fill[tuple(members[i]['fill'])] = ink_fill.get(tuple(members[i]['fill']), 0) + int(scene.mask(i).sum())
    ink_color = ink_rgb or (max(ink_fill, key=ink_fill.get) if ink_fill else (42, 22, 22))
    # Траєкторії контуру рахуються в K-кратному розрішенні, щоб тонкий ободок (~1 px) не розпадався на «пунктир».
    K = 4
    ink_hi = scene.mask_hi(ink_idx, K).astype(np.uint8)
    # Суб-піксельні ділянки ободка crisp-маска губить -> додаємо темні пікселі ink-кольору з антиаліасної надвибіркової картинки
    # (крім чорних плям-заливок на кшталт зіниць).
    hi = scene.ref_hi(K).astype(np.int32)
    inks = np.array([c for c in ink_fill], np.int32).reshape(-1, 3)
    near_ink = np.zeros(hi.shape[:2], bool)
    for c in inks:
        near_ink |= np.abs(hi - c[None, None, :]).sum(2) < 90
    blob_idx = [i for i, m in enumerate(members) if m['role'] == 'region' and m['visible_px'] > 0
                and colorsys.rgb_to_hls(*[c / 255 for c in m['fill']])[1] <= 0.2]
    blobs = cv2.dilate(scene.mask_hi(blob_idx, K).astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) if blob_idx else 0
    ink_hi = (ink_hi.astype(bool) | (near_ink & ~blobs)).astype(np.uint8)
    ink_hi = cv2.morphologyEx(ink_hi, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    # Line width is *measured* (median of the local width along the centre line), never assumed.
    dist_ink = cv2.distanceTransform(ink_hi, cv2.DIST_L2, 3)
    sk0 = skeletonize(ink_hi > 0)
    w_line = float(np.median(2 * dist_ink[sk0])) / K if sk0.any() else float(ink_width or 4)
    w_p95 = float(np.percentile(2 * dist_ink[sk0], 95)) / K if sk0.any() else float(ink_width or 4)
    if ink_width is None:
        # Товщина пера береться з ОРИГІНАЛУ (виміряна ширина лінії), а не з єдиного «жирного» стилю:
        # тонкі лінії Fox -> тонке перо, товстий контур Dragon -> товсте перо.
        # перо має ПОКРИВАТИ лінію одним проходом (інакше з'являються «ремонтні» проходи й контур малюється кілька разів):
        # для тонких ліній додатково розширюємо на ink_scale, для товстих перо = 1.35 ширини лінії; стеля - частка кадру
        boost = 1.0 + (ink_scale - 1.0) * max(0.0, 1.0 - w_line / 14.0)
        ink_width = int(np.clip(round((1.35 * w_line + 1.2) * boost), 2, max(14, 0.045 * W)))
    ink_width = int(max(ink_width, 1))
    k = int(max(ink_width, 2.6 * w_line) * K) | 1
    thick = cv2.morphologyEx(ink_hi, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    thin = (ink_hi > 0) & ~cv2.dilate(thick, np.ones((5 * K, 5 * K), np.uint8)).astype(bool)

    def down(t):
        return (np.asarray(t, float) + 0.5) / K - 0.5

    loop_trails = []
    if trace == 'loops':
        try:
            from loops import loop_strokes
            lp = loop_strokes(thin.astype(np.uint8), w_line, K, skeleton=skeletonize(thin > 0))
            blob_zone = cv2.dilate(thick, np.ones((5, 5), np.uint8)) > 0
            for p_ in lp:                                      # контури всередині товстих плям (зіниці) - не штрихи: їх штрихує hatch
                q_ = np.rint(p_).astype(int)
                q_[:, 0] = np.clip(q_[:, 0], 0, thin.shape[1] - 1)
                q_[:, 1] = np.clip(q_[:, 1], 0, thin.shape[0] - 1)
                if blob_zone[q_[:, 1], q_[:, 0]].mean() < 0.6:
                    loop_trails.append(p_)
        except Exception:
            loop_trails = []
    if loop_trails:
        cov_ = np.zeros(thin.shape, np.uint8)
        for p_ in loop_trails:
            cv2.polylines(cov_, [np.rint(p_).astype(np.int32).reshape(-1, 1, 2)], False, 255, max(3, int(round(w_line * K * 1.15))))
        resid = (thin > 0) & (cov_ == 0)
        resid = cv2.morphologyEx(resid.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        nr, lr = cv2.connectedComponents(resid)
        keep_r = np.zeros_like(resid)
        for li in range(1, nr):
            if (lr == li).sum() >= (1.2 * w_line * K) ** 2:
                keep_r |= (lr == li).astype(np.uint8)
        raw = region_skeleton_trails(keep_r, min_len=3) if keep_r.any() else []
        ink_trails = [down(t) for t in loop_trails] + [down(t) for t in stitch_trails(raw, join_px * K) if poly_len(t) >= 4 * K]
    else:
        raw = region_skeleton_trails(thin, min_len=3)            # дрібні шматки не відкидаємо ДО зшивання (вони й ламали лінію)
        ink_trails = [down(t) for t in stitch_trails(raw, join_px * K) if poly_len(t) >= 4 * K]
    thick_trails = []
    n_lab, lab = cv2.connectedComponents(thick)
    for li in range(1, n_lab):
        comp = lab == li
        if comp.sum() < 12 * K * K:
            continue
        thick_trails += [down(t) for t in hatch_trails(comp, step=ink_width * 0.8 * K, angle_deg=main_axis_angle(comp))]
    ink_strokes = [dict(kind='ink', fill=rgb_str(ink_color), width=ink_width, pts=t, style='line') for t in ink_trails]
    ink_strokes += [dict(kind='ink', fill=rgb_str(ink_color), width=ink_width, pts=t, style='hatch') for t in thick_trails]
    for st_ in ink_strokes:
        if st_['style'] == 'line' and float(np.hypot(*(np.asarray(st_['pts'][0]) - np.asarray(st_['pts'][-1])))) > 2.0:
            st_['pts'] = finish_line_ends(st_['pts'], ink_width)      # замкнені контури (кола) не чіпаємо
    _assign_ink_clusters(scene, ink_strokes, ink_fill, K)
    # --- уламки-«крапки» (довжина < ~2 ширин пера): прибираємо, якщо без них не відкривається помітний контур;
    #     усе вилучене перелічується в plan['skipped_ink'] (нічого не губимо мовчки)
    skipped_ink = []
    if ink_strokes:
        short_len = max(2.2 * ink_width, 10.0)
        def _lay(ss):
            l = np.zeros((H, W), np.uint8)
            for st_ in ss:
                pp = np.rint(st_['pts']).astype(np.int32).reshape(-1, 1, 2)
                cv2.polylines(l, [pp], False, 255, max(1, int(st_['width'])), cv2.LINE_AA)
            return cv2.dilate(l, np.ones((3, 3), np.uint8)) > 100
        long_ = [s_ for s_ in ink_strokes if poly_len(s_['pts']) >= short_len]
        LP = np.vstack([np.asarray(s_['pts'])[::2] for s_ in long_]) if long_ else np.zeros((0, 2))

        def _isolated(s_):                  # окрема дрібна деталь (ніздря, крапка) - зберігаємо
            if not len(LP):
                return True
            d_ = np.sqrt(((np.asarray(s_['pts'])[:, None, :] - LP[None, :, :]) ** 2).sum(2)).min()
            return d_ > 2.0 * ink_width
        short_ = [s_ for s_ in ink_strokes if poly_len(s_['pts']) < short_len]
        keep_ = long_ + [s_ for s_ in short_ if _isolated(s_)]
        drop_ = [s_ for s_ in short_ if not _isolated(s_)]
        if drop_:
            lost = int((ink_mask.astype(bool) & ~_lay(keep_)).sum()) - int((ink_mask.astype(bool) & ~_lay(ink_strokes)).sum())
            if lost <= 0.004 * max(1, int(ink_mask.sum())):
                skipped_ink = [dict(len_px=round(poly_len(s_['pts']), 1), at=[round(float(s_['pts'][0][0]), 1), round(float(s_['pts'][0][1]), 1)])
                               for s_ in drop_]
                skipped_ink.append(dict(summary='dropped_short_ink', count=len(drop_), uncovered_ink_px=lost))
                ink_strokes = keep_
    if order == 'human' and direction is None and not ink_group_order:
        from ordering import order_human
        ink_strokes = order_human(ink_strokes, ink_mask, ink_width)
    elif direction is not None or ink_group_order:
        from direction import order_ink
        ink_strokes = order_ink(ink_strokes, direction, order_strokes)
    else:
        ink_strokes = order_strokes(ink_strokes, start=None, allow_reverse=True, big_first=True)
    strokes += ink_strokes

    # ---- colour phases (one chapter per marker colour) -----------------------------------------
    by_color = defaultdict(list)
    for i in fill_idx:
        by_color[tuple(members[i]['fill'])].append(i)
    chapter_order = sorted(by_color, key=lambda c: -sum(int(scene.mask(i).sum()) for i in by_color[c]))
    if order_hint:
        chapter_order = sorted(chapter_order, key=lambda c: order_hint.index(c) if c in order_hint else 99)
    for col in chapter_order:
        chap = []
        for i in by_color[col]:
            m = scene.mask(i)
            if m.sum() == 0:
                continue
            dist = cv2.distanceTransform(m.astype(np.uint8), cv2.DIST_L2, 3)
            if dist.max() * 2 < 1.5 * color_width:
                trails = region_skeleton_trails(m, min_len=1) or [np.array([[*np.mean(np.nonzero(m)[::-1], axis=1)]] * 2)]
            else:
                trails = hatch_trails(m, step=color_width * 0.62, angle_deg=main_axis_angle(m), ext=color_width * 0.7)   # ряди перекриваються: без видимих смуг
            for t in trails:
                chap.append(dict(kind='color', fill=rgb_str(col), width=color_width, pts=t, member=members[i]['id'],
                                 style='hatch' if dist.max() * 2 >= 1.5 * color_width else 'dab'))
        strokes += order_strokes(chap, start=strokes[-1]['pts'][-1] if strokes else None, allow_reverse=True)

    # ---- smooth, resample, verify coverage and repair gaps ---------------------------------------
    for s in strokes:
        s['pts'] = resample(chaikin(resample(s['pts'], 2.0), 2), 1.0)
        if s['kind'] == 'color' and s.get('style') == 'hatch':
            # закруглені розвороти серпантину: рука не робить кутових ривків (штрих трохи виходить за регіон - фарба обрізається по регіону)
            s['pts'] = resample(smooth_poly(s['pts'], 0.36 * s['width']), 1.0)
        if s['kind'] == 'color' and s.get('style') == 'dab':
            s['pts'] = resample(smooth_poly(remove_backsteps(resample(smooth_poly(s['pts'], 0.3 * s['width']), 1.0)), 1.5), 1.0)
        if s['kind'] == 'ink' and s.get('style') == 'line':
            s['pts'] = resample(smooth_poly(remove_backsteps(resample(smooth_poly(s['pts'], 0.9 * s['width'], closed_tol=2.5 * s['width']), 1.0)), 1.5), 1.0)
    split = []
    for s_ in strokes:
        if (s_['kind'] == 'ink' and s_.get('style') == 'line') or (s_['kind'] == 'color' and s_.get('style') == 'dab'):
            split += [dict(s_, pts=piece) for piece in split_at_cusps(s_['pts'])]
        else:
            split.append(s_)
    strokes = prune_redundant(scene, split, ink_mask > 0, max_len=70)
    plan_strokes = strokes
    plan_strokes = repair_coverage(scene, plan_strokes, ink_mask > 0, fill_idx, ink_width, color_width, foot=max(3, int(round(1.4 * w_line))))
    groups_info = []
    if direction and direction.get('style') in ('object_by_object', 'outline_first'):
        from direction import sequence_by_object
        for n_, s_ in enumerate(plan_strokes):
            s_['length_px'] = round(poly_len(s_['pts']), 1)
        plan_strokes, groups_info = sequence_by_object(scene, plan_strokes, direction, order_strokes)
    for n, s in enumerate(plan_strokes):
        s['id'] = f"{s['kind']}_{n:03d}"
        s['length_px'] = round(poly_len(s['pts']), 1)
    return dict(schema='shine.creator_plan.v36', canvas=[W, H], source_sha256=scene.source_sha,
                chapters=_chapters(plan_strokes), strokes=plan_strokes, skipped=skipped, skipped_ink=skipped_ink, groups=groups_info, ink_rgb=rgb_str(ink_color), min_fill_px=min_fill_px, w_line=round(float(w_line), 2))


def _chapters(strokes):
    out, cur = [], None
    for s in strokes:
        if cur is None or cur['fill'] != s['fill']:
            cur = dict(fill=s['fill'], kind=s['kind'], strokes=[])
            out.append(cur)
        cur['strokes'].append(s['id'] if 'id' in s else None)
    return out


def _tangent(p, at_end, k=8):
    k = min(k, len(p) - 1)
    d = (p[-1] - p[-1 - k]) if at_end else (p[0] - p[k])
    n = np.linalg.norm(d)
    return d / n if n > 1e-9 else np.array([1.0, 0.0])


def stitch_trails(trails, join_px, max_turn_deg=70):
    """Join broken centre-line pieces into long continuous pen trails.

    Two ends are joined when they are close (bridge drawn under contact, clipped by the visible mask)
    and the pen would keep going in roughly the same direction.  Greedy by smallest gap.
    """
    ts = [np.asarray(t, float) for t in trails if len(t) >= 2]
    cos_lim = math.cos(math.radians(max_turn_deg))
    while True:
        best = None
        for i, a in enumerate(ts):
            for j, b in enumerate(ts):
                if i == j:
                    continue
                for a_rev in (False, True):
                    for b_rev in (False, True):
                        A = a[::-1] if a_rev else a
                        B = b[::-1] if b_rev else b
                        gap = B[0] - A[-1]
                        g = float(np.hypot(*gap))
                        if g > join_px:
                            continue
                        ta, tb = _tangent(A, True), _tangent(B, False)
                        dirn = gap / g if g > 1e-6 else ta
                        if np.dot(ta, dirn) < cos_lim * 0 and g > 3:      # bridge must not double back
                            continue
                        if np.dot(ta, tb) < cos_lim:
                            continue
                        score = g + 12 * (1 - np.dot(ta, tb))
                        if best is None or score < best[0]:
                            best = (score, i, j, a_rev, b_rev)
        if best is None:
            return ts
        _, i, j, a_rev, b_rev = best
        A = ts[i][::-1] if a_rev else ts[i]
        B = ts[j][::-1] if b_rev else ts[j]
        merged = np.vstack([A, B])
        ts = [t for n, t in enumerate(ts) if n not in (i, j)] + [merged]


def order_strokes(strokes, start, allow_reverse=True, big_first=False):
    """Nearest-neighbour chaining from the pen tip; the biggest contour first for outlines."""
    rest = list(strokes)
    out = []
    if not rest:
        return out
    tip = None if start is None else np.asarray(start, float)
    if tip is None:
        if big_first:
            first = max(rest, key=lambda s: poly_len(s['pts']))
        else:
            first = min(rest, key=lambda s: (s['pts'][0][0], s['pts'][0][1]))
        rest = [x for x in rest if x is not first]
        out.append(first)
        tip = first['pts'][-1]
    while rest:
        def cost(s):
            a = np.hypot(*(s['pts'][0] - tip))
            b = np.hypot(*(s['pts'][-1] - tip)) if allow_reverse else 1e9
            return min(a, b)
        nxt = min(rest, key=cost)
        rest = [x for x in rest if x is not nxt]
        if allow_reverse and np.hypot(*(nxt['pts'][-1] - tip)) < np.hypot(*(nxt['pts'][0] - tip)) - 1e-6:
            nxt['pts'] = nxt['pts'][::-1].copy()
        out.append(nxt)
        tip = nxt['pts'][-1]
    return out


def prune_redundant(scene, strokes, ink_mask, max_len=70):
    """Drop short ink stubs whose brush footprint is fully covered by other strokes (junction debris)."""
    H, W = scene.H, scene.W
    def fp(st):
        layer = np.zeros((H, W), np.uint8)
        pp = np.rint(st['pts']).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(layer, [pp], False, 1, int(st['width']), cv2.LINE_8)
        return layer.astype(bool)
    ink_idx = [i for i, st in enumerate(strokes) if st['kind'] == 'ink']
    count = np.zeros((H, W), np.int16)
    fps = {i: fp(strokes[i]) for i in ink_idx}
    for i in ink_idx:
        count += fps[i]
    drop = set()
    for i in sorted(ink_idx, key=lambda i: poly_len(strokes[i]['pts'])):
        if poly_len(strokes[i]['pts']) > max_len:
            break
        need = fps[i] & ink_mask
        if not need.any() or (count[need] >= 2).all():
            count -= fps[i]
            drop.add(i)
    return [st for i, st in enumerate(strokes) if i not in drop]


def footprint(shape, strokes, kind, width=None):
    layer = np.zeros(shape, np.uint8)
    for s in strokes:
        if s['kind'] != kind:
            continue
        p = np.rint(s['pts']).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(layer, [p], False, 255, int(width or s['width']), cv2.LINE_8)
        if len(p) == 1 or poly_len(s['pts']) < 1:
            cv2.circle(layer, tuple(p[0, 0]), int(s['width'] // 2), 255, -1)
    return layer > 0


def repair_coverage(scene, strokes, ink_mask, fill_idx, ink_w, col_w, foot=None):
    """Add short strokes for any visible pixel the brush footprint did not reach (never silently skip)."""
    H, W = scene.H, scene.W
    extra = []
    ink_fp = footprint((H, W), strokes, 'ink', width=foot)
    miss = ink_mask & ~ink_fp
    n, lab = cv2.connectedComponents(miss.astype(np.uint8))
    for li in range(1, n):
        comp = lab == li
        touches_ink = bool((cv2.dilate(comp.astype(np.uint8), np.ones((2 * int(ink_w) + 1,) * 2, np.uint8)).astype(bool) & ink_fp).any())
        small = 0.03 * (foot or ink_w) ** 2 if foot else 1.5 * ink_w * ink_w
        if comp.sum() < 4 or (touches_ink and comp.sum() < max(4, int(small))):
            continue                         # лише справжній дріб'язок: пальці/зубці біля лінії мають власний штрих
        trails = None
        if touches_ink and comp.sum() < 2.0 * (foot or ink_w) ** 2:
            # зубець/палець/відросток при лінії: короткий штрих від осі лінії до кінчика і назад (як рух пальцем маркера)
            cy, cx = np.nonzero(comp)
            pts_all = np.vstack([np.asarray(s_['pts'])[::2] for s_ in strokes if s_['kind'] == 'ink']) if strokes else None
            if pts_all is not None and len(pts_all):
                from scipy.spatial import cKDTree as _KD
                q = np.column_stack((cx, cy)).astype(np.float32)
                dd, ii = _KD(pts_all).query(q)
                j = int(np.argmax(dd))
                if dd[j] > 1.6 * (foot or ink_w):
                    j = None
                tip = q[j] if j is not None else None
                if j is not None:
                    anchor = pts_all[int(ii[j])]
                    trails = [np.array([anchor, tip, anchor], np.float32)]
        for t in trails or region_skeleton_trails(comp, min_len=1) or [np.array([[*np.mean(np.nonzero(comp)[::-1], axis=1)]] * 2)]:
            extra.append(dict(kind='ink', fill=strokes[0]['fill'] if strokes else 'rgb(0,0,0)', width=ink_w, pts=t, repair=True, style='line'))
    # insert ink repairs at the end of the ink phase
    # ремонтні штрихи вставляємо ПОРУЧ зі штрихом, до якого вони належать, а не в кінець контуру
    # (інакше після ока й рота «догумовуються» шматочки старого місця)
    ink_list = [s for s in strokes if s['kind'] == 'ink']
    rest_list = [s for s in strokes if s['kind'] != 'ink']
    for e in extra:
        e['pts'] = resample(e['pts'], 1.0)
        if not ink_list:
            ink_list.append(e)
            continue
        q = np.vstack([e['pts'][0], e['pts'][-1]])
        best, bj = None, 0
        for j, s_ in enumerate(ink_list):
            d_ = float(np.sqrt(((np.asarray(s_['pts'])[::3, None, :] - q[None, :, :]) ** 2).sum(2)).min())
            if best is None or d_ < best:
                best, bj = d_, j
        tip = np.asarray(ink_list[bj]['pts'][-1])
        if np.hypot(*(e['pts'][-1] - tip)) < np.hypot(*(e['pts'][0] - tip)):
            e['pts'] = e['pts'][::-1].copy()
        ink_list.insert(bj + 1, e)
    strokes = ink_list + rest_list
    col_fp = footprint((H, W), strokes, 'color')
    fills = {}
    for s in strokes:
        if s['kind'] == 'color':
            fills.setdefault(s.get('member'), s['fill'])
    tail = []
    for i in fill_idx:
        m = scene.mask(i) & ~col_fp
        n, lab = cv2.connectedComponents(m.astype(np.uint8))
        for li in range(1, n):
            comp = lab == li
            fill_s = rgb_str(scene.members[i]['fill'])
            new_marker = not any(x['kind'] == 'color' and x['fill'] == fill_s for x in strokes)
            if comp.sum() < 12 or (new_marker and comp.sum() < 40):
                continue     # sub-visible speck: not worth a whole marker change (reported via coverage_report)
            trails = None
            for t in region_skeleton_trails(comp, min_len=1) or [np.array([[*np.mean(np.nonzero(comp)[::-1], axis=1)]] * 2)]:
                tail.append(dict(kind='color', fill=fill_s, width=col_w,
                                 pts=resample(t, 1.0), member=scene.members[i]['id'], repair=True))
    # repairs share the marker of their colour: place them right after that colour's chapter
    out = list(strokes)
    for r in tail:
        last = max((j for j, s in enumerate(out) if s['kind'] == 'color' and s['fill'] == r['fill']), default=len(out) - 1)
        out.insert(last + 1, r)
    return out


def coverage_report(scene, plan):
    H, W = scene.H, scene.W
    strokes = plan['strokes']
    ink_fp = footprint((H, W), strokes, 'ink')
    col_fp = footprint((H, W), strokes, 'color')
    ink = np.zeros((H, W), bool)
    fill = np.zeros((H, W), bool)
    for i, m in enumerate(scene.members):
        if m['role'] in INK_ROLES:
            ink |= scene.mask(i)
        elif m['role'] in FILL_ROLES:
            fill |= scene.mask(i)
    return dict(ink_px=int(ink.sum()), ink_uncovered=int((ink & ~ink_fp).sum()),
                fill_px=int(fill.sum()), fill_uncovered=int((fill & ~col_fp).sum()))


def preview(scene, plan, out):
    img = (scene.ref.astype(np.float32) * 0.25 + 255 * 0.75).astype(np.uint8)
    n = len(plan['strokes'])
    for k, s in enumerate(plan['strokes']):
        hue = int(150 * k / max(n - 1, 1))
        col = cv2.cvtColor(np.uint8([[[hue, 220, 200]]]), cv2.COLOR_HSV2BGR)[0, 0]
        p = np.rint(s['pts']).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(img, [p], False, tuple(int(c) for c in col[::-1]), 1 if s['kind'] == 'color' else 2, cv2.LINE_AA)
        cv2.circle(img, tuple(p[0, 0]), 3, (0, 0, 0), -1)
    Image.fromarray(img).save(out)


def save_plan(plan, path):
    d = dict(plan)
    d['strokes'] = [dict(s, pts=np.round(s['pts'], 1).tolist()) for s in plan['strokes']]
    Path(path).write_text(json.dumps(d))
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
