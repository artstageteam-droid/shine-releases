"""Контур за формами («як малює людина»).

Кожна область, відмежована чорнилом (голова, крило, живіт, кільце ока...), дає замкнений контур по ОСЬОВІЙ лінії чорнила.
Контури обробляються від зовнішнього силуету до дрібних форм; частини, що збігаються з уже наміченим (спільні межі
сусідніх форм), пропускаються. Незайманий замкнений контур = ОДИН штрих (коло, кільце ока, куля антени), решта -
дуги між стиками. Так ділення контуру збігається з будовою малюнка, а не з шумом скелета.

Усе в надвибірці K; вихід - штрихи в координатах кадру.
"""
import cv2
import numpy as np
from scipy.spatial import cKDTree
from skimage.morphology import skeletonize


def _smooth_closed(p, win):
    if len(p) < 3 * win:
        return p
    k = np.ones(win) / win
    pad = np.vstack([p[-win:], p, p[:win]])
    return np.column_stack([np.convolve(pad[:, 0], k, 'same'), np.convolve(pad[:, 1], k, 'same')])[win:-win]


def _runs(mask):
    """послідовності True у циклічному масиві -> список (start, end) індексів (end включно), з урахуванням циклу"""
    n = len(mask)
    if mask.all():
        return [(0, n - 1)], True
    if not mask.any():
        return [], False
    s = int(np.argmin(mask))                      # перший False
    idx = [(s + i) % n for i in range(n)]
    runs, cur = [], []
    for i in idx:
        if mask[i]:
            cur.append(i)
        elif cur:
            runs.append(cur)
            cur = []
    if cur:
        runs.append(cur)
    return runs, False


def loop_strokes(ink_hi, w_line, K, skeleton=None, min_region_px=None):
    """ink_hi: бінарна маска лінійного чорнила (K-кратна). Повертає список полілаїнів (у координатах hi-res, x,y)."""
    H, W = ink_hi.shape
    ink = (ink_hi > 0).astype(np.uint8)
    free = (ink == 0).astype(np.uint8)
    n, lab = cv2.connectedComponents(free, connectivity=4)
    areas = np.bincount(lab.ravel(), minlength=n)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    r = max(2, int(round(w_line * K / 2.0)))
    min_px = min_region_px if min_region_px is not None else (2.5 * w_line * K) ** 2 * 0.6
    sk = skeleton if skeleton is not None else skeletonize(ink > 0)
    SK = np.column_stack(np.nonzero(sk)[::-1]).astype(np.float32)          # x,y
    sk_tree = cKDTree(SK) if len(SK) else None
    order = sorted([L for L in range(1, n) if (L in border) or areas[L] >= min_px],
                   key=lambda L: (L not in border, -areas[L]))
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    drawn = np.zeros((0, 2), np.float32)
    dtree = None
    out = []
    cover = max(1.0, 0.75 * r)
    for L in order:
        m = (lab == L).astype(np.uint8)
        if L in border:                            # зовнішній папір: рамку кадру не малюємо
            m[:3, :] = m[-3:, :] = 0
            m[:, :3] = m[:, -3:] = 0
            m = cv2.copyMakeBorder(m, 0, 0, 0, 0, cv2.BORDER_CONSTANT)
        md = cv2.dilate(m, ker)
        cs, _ = cv2.findContours(md, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        for c in cs:
            if len(c) < 6 * r:
                continue
            p = c[:, 0, :].astype(np.float32)
            edge = (p[:, 0] < 4) | (p[:, 1] < 4) | (p[:, 0] > W - 5) | (p[:, 1] > H - 5)
            if edge.mean() > 0.5:
                continue
            p = _smooth_closed(p, max(3, r))
            if sk_tree is not None:                # прив'язка до осьової лінії чорнила
                d, ix = sk_tree.query(p)
                p = np.where((d <= 1.6 * r + 2)[:, None], SK[ix], p)
                p = _smooth_closed(p, max(3, r))
            cov = np.zeros(len(p), bool)
            if dtree is not None:
                cov = dtree.query(p)[0] < cover
            cov |= edge
            if not cov.any():
                out.append(np.vstack([p, p[:1]]))            # цілий замкнений контур - один штрих
                keep = p
            else:
                runs, _ = _runs(~cov)
                keep = []
                for rr in (runs if isinstance(runs, list) else []):
                    if isinstance(rr, tuple):
                        rr = list(range(rr[0], rr[1] + 1))
                    if len(rr) >= 3 * r:
                        seg = p[rr]
                        out.append(seg)
                        keep.append(seg)
                keep = np.vstack(keep) if keep else np.zeros((0, 2), np.float32)
            if len(keep):
                drawn = np.vstack([drawn, keep]) if len(drawn) else keep
                dtree = cKDTree(drawn)
    return out
