"use strict";
const TOKEN = document.querySelector('meta[name="shine-token"]').content;
const $ = (s, r = document) => r.querySelector(s);
const h = (html) => { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstChild; };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, opts = {}) {
  const o = { method: "GET", headers: {}, ...opts };
  o.headers["X-Shine-Token"] = TOKEN;
  if (o.json !== undefined) { o.body = JSON.stringify(o.json); o.headers["Content-Type"] = "application/json"; o.method = o.method === "GET" ? "POST" : o.method; }
  const r = await fetch(path, o);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || data.detail || "Помилка " + r.status);
  return data;
}

const KINDS = { character: "Один персонаж", set: "Набір персонажів", objects: "Набір предметів (машинки, їжа…)", scene: "Сцена (лише малювання)" };
const view = $("#view");
let current = { request: null };

/* ---------- оновлення ---------- */
async function checkUpdate(manual) {
  const b = $("#banner");
  try {
    const s = await api("/api/update/check");
    if (s.available) {
      b.hidden = false; b.className = "banner";
      b.innerHTML = `<div><b>Є оновлення ${esc(s.version)}</b><div class="note">${esc((s.notes || "").slice(0, 300))}</div></div>
        <div class="row"><button id="upd">Оновити</button><button class="sec" id="later">Пізніше</button></div>`;
      $("#later").onclick = () => (b.hidden = true);
      $("#upd").onclick = async () => {
        $("#upd").disabled = true; $("#upd").textContent = "Завантаження…";
        try { await api("/api/update/download", { method: "POST" }); $("#upd").textContent = "Перезапуск…"; await api("/api/update/apply", { method: "POST" }); }
        catch (e) { b.className = "banner err"; b.innerHTML = esc(e.message); }
      };
    } else if (manual) {
      b.hidden = false; b.className = "banner";
      b.innerHTML = s.installed ? "У вас остання версія." : esc(s.reason || "Оновлення недоступні в цьому режимі запуску.");
    }
  } catch (e) { if (manual) { b.hidden = false; b.className = "banner err"; b.textContent = e.message; } }
}

/* ---------- екрани ---------- */
async function viewProjects() {
  const list = await api("/api/projects");
  view.innerHTML = `<h1>Проєкти</h1><p class="sub">Один проєкт = одне відео (або набір малюнків).</p>
    <div class="card"><div class="row">
      <label>Назва нового проєкту<input id="pname" placeholder="Напр.: Веселі монстрики"></label>
      <label>Тип<select id="pkind">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
      <button id="padd">Створити</button></div><div id="perr" class="bad note"></div></div>
    <div class="card list">${list.length ? list.map((p) => `<div class="item"><div><a href="#/project/${esc(p.id)}">${esc(p.name)}</a><span class="tag">${esc(KINDS[p.kind] || p.kind)}</span></div><span class="note">малюнків: ${p.sources}</span></div>`).join("") : `<div class="empty">Проєктів ще немає. Створіть перший.</div>`}</div>`;
  $("#padd").onclick = async () => {
    try { const p = await api("/api/projects", { json: { name: $("#pname").value, kind: $("#pkind").value, request: current.request } }); current.request = null; location.hash = "#/project/" + p.id; }
    catch (e) { $("#perr").textContent = e.message; }
  };
}

const blobCache = new Map();
async function imgUrl(path) {
  if (blobCache.has(path)) return blobCache.get(path);
  const r = await fetch(path, { headers: { "X-Shine-Token": TOKEN } });
  if (!r.ok) return "";
  const u = URL.createObjectURL(await r.blob());
  blobCache.set(path, u);
  return u;
}
async function fillImgs(root) {
  for (const im of root.querySelectorAll("img[data-src]")) { im.src = await imgUrl(im.dataset.src); }
}

function objCard(pid, o) {
  const real = o.kind === "object";
  const badge = !real ? `<span class="tag">деталь</span>` : o.plan.blink ? `<span class="tag ok">оживлення: так</span>` : `<span class="tag warn">лише малювання</span>`;
  return `<div class="obj"><img data-src="/api/projects/${encodeURIComponent(pid)}/files/objects/${encodeURIComponent(o.id)}.png" alt="${esc(o.id)}">
    <div><b>${esc(o.id)}</b> ${badge}</div><div class="note">${esc(o.plan.reason)}</div>${real ? `<div class="row" style="margin-top:8px"><button data-draw="${esc(o.id)}">Намалювати</button><button class="sec" data-plan="${esc(o.id)}">План малювання</button></div><div data-planbox="${esc(o.id)}"></div><div class="note" style="margin-top:8px">Вирази:</div><div class="row" style="flex-wrap:wrap;gap:6px" data-emo="${esc(o.id)}"></div>` : ""}</div>`;
}

async function viewProject(pid) {
  const p = await api("/api/projects/" + encodeURIComponent(pid));
  const exp = p.request ? p.request.count : null;
  const analyzed = p.objects.length > 0;
  const real = p.objects.filter((o) => o.kind === "object");
  view.innerHTML = `<h1>${esc(p.name)}</h1><p class="sub">${esc(KINDS[p.kind] || p.kind)}${exp ? " · очікується об'єктів: " + exp : ""}</p>
    <div class="card"><div class="drop" id="drop">Перетягніть сюди PNG (або SVG) чи <button class="sec" id="pick">оберіть файл</button><input id="file" type="file" accept=".png,.svg" hidden multiple></div>
      <div id="uerr" class="bad note"></div>
      <div class="thumbs">${p.sources.map((s) => `<div><b>${esc(s.id)}</b> · ${esc(s.file)}${s.file.endsWith(".png") ? `<br><img data-src="/api/projects/${encodeURIComponent(pid)}/files/source/${encodeURIComponent(s.id)}.png" alt="">` : ""}</div>`).join("")}</div>
      ${p.sources.length ? `<div class="row" style="margin-top:14px"><select id="lay" title="Як ділити лист"><option value="auto">Окремі об'єкти (дрібниці лишаються з головним)</option><option value="whole">Увесь лист — одним роликом (цілий набір)</option><option value="split">Ділити все, навіть дрібниці</option></select><button id="an">${analyzed ? "Проаналізувати знову" : "Проаналізувати"}</button><span id="anst" class="note"></span></div>` : ""}</div>
    <div id="res"></div><div id="rlist"></div>`;
  const up = async (files) => { for (const f of files) { const fd = new FormData(); fd.append("file", f); try { await api(`/api/projects/${encodeURIComponent(pid)}/sources`, { method: "POST", body: fd }); } catch (e) { $("#uerr").textContent = e.message; return; } } viewProject(pid); };
  $("#pick").onclick = () => $("#file").click(); $("#file").onchange = (e) => up(e.target.files);
  const d = $("#drop"); d.ondragover = (e) => { e.preventDefault(); d.classList.add("over"); }; d.ondragleave = () => d.classList.remove("over");
  d.ondrop = (e) => { e.preventDefault(); d.classList.remove("over"); up(e.dataTransfer.files); };

  const showResult = (objects, plan, reports) => {
    const rs = $("#res"); const rp = objects.filter((o) => o.kind === "object");
    const advice = (reports || []).flatMap((r) => r.error ? [`${r.source}: ${r.error}`] : ((r.check && r.check.advice) || []).map((t) => `${r.source}: ${t}`));
    rs.innerHTML = `<div class="card"><h3 style="margin-top:0">Результат аналізу</h3>
      <p>Об'єктів: <b>${plan.objects}</b> · оживлення можливе: <b>${plan.animate}</b> · лише малювання: <b>${plan.draw_only}</b></p>
      ${advice.length ? `<div class="banner err" style="display:block">${advice.map(esc).join("<br>")}</div>` : ""}
      ${rp.length ? `<div class="row" style="margin-bottom:12px"><button id="drawall">Намалювати все (${rp.length}) — один ролик</button></div>` : ""}
      <div class="objs">${objects.map((o) => objCard(pid, o)).join("")}</div>
      <p class="note">Оживлення вмикається лише там, де очі знайдені впевнено — щоб не псувати малюнок.</p></div>`;
    fillImgs(rs); p.emotions = p.emotions || {}; emoBoxes();
    const da = $("#drawall"); if (da) da.onclick = () => drawDialog(pid, "__all__");
    rs.querySelectorAll("[data-plan]").forEach((b) => (b.onclick = async () => {
      const id = b.dataset.plan, box = rs.querySelector(`[data-planbox="${id}"]`); b.disabled = true; box.innerHTML = `<p class="note">Рахую план…</p>`;
      try { const r = await api(`/api/projects/${encodeURIComponent(pid)}/objects/${encodeURIComponent(id)}/plan`, { method: "POST" });
        box.innerHTML = `<p class="note">Контур: ${r.ink_strokes} штрихів (номери = порядок), заливка: ${r.fill_strokes}; орієнтовно ${Math.round(r.seconds)} с малювання.</p><img src="/api/projects/${encodeURIComponent(pid)}/files/cache/plan_${encodeURIComponent(id)}.png?t=${Date.now()}" style="max-width:100%;border:1px solid #ddd;border-radius:8px">`;
      } catch (e) { box.innerHTML = `<p class="bad note">${esc(e.message)}</p>`; }
      b.disabled = false; }));
    rs.querySelectorAll("[data-draw]").forEach((b) => (b.onclick = () => drawDialog(pid, b.dataset.draw)));
  };
  const emoBoxes = () => {
    document.querySelectorAll("[data-emo]").forEach((box) => {
      const id = box.dataset.emo, have = p.emotions[id] || [];
      box.innerHTML = have.map((e) => `<span class="tag ok">${esc(EM[e.name] || e.name)} <a href="#" data-rm="${esc(e.name)}" title="Прибрати">×</a></span>`).join("") +
        `<select data-sel>${Object.entries(EM).filter(([k]) => !have.some((e) => e.name === k)).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select><button class="sec" data-add>＋ кадр</button><input type="file" accept=".png" hidden>`;
      const fi = box.querySelector("input");
      box.querySelector("[data-add]").onclick = () => fi.click();
      fi.onchange = async () => {
        const fd = new FormData(); fd.append("file", fi.files[0]);
        try { const r = await api(`/api/projects/${encodeURIComponent(pid)}/objects/${encodeURIComponent(id)}/emotions/${box.querySelector("[data-sel]").value}`, { method: "POST", body: fd }); p.emotions[id] = r.emotions; emoBoxes(); }
        catch (e) { $("#uerr").textContent = e.message; }
      };
      box.querySelectorAll("[data-rm]").forEach((a) => (a.onclick = async (ev) => { ev.preventDefault();
        const r = await api(`/api/projects/${encodeURIComponent(pid)}/objects/${encodeURIComponent(id)}/emotions/${a.dataset.rm}`, { method: "DELETE" }); p.emotions[id] = r.emotions; emoBoxes(); }));
    });
  };
  fillImgs(view);
  loadRenders(pid);
  if (analyzed) showResult(p.objects, p.plan, []);
  const an = $("#an");
  if (an) an.onclick = async () => {
    an.disabled = true; $("#anst").textContent = "Аналізую…";
    try { const r = await api(`/api/projects/${encodeURIComponent(pid)}/analyze?layout=${encodeURIComponent($("#lay").value)}`, { method: "POST" }); $("#anst").textContent = ""; showResult(r.objects, r.plan, r.reports); }
    catch (e) { $("#anst").textContent = ""; $("#uerr").textContent = e.message; }
    an.disabled = false;
  };
}

async function loadRenders(pid) {
  let box = $("#rlist");
  if (!box) return;
  const list = await api(`/api/projects/${encodeURIComponent(pid)}/renders`);
  const fmt = (t) => (t ? new Date(t * 1000).toLocaleString("uk-UA") : "");
  box.innerHTML = `<div class="card"><h3 style="margin-top:0">Готові відео</h3>
    ${list.length ? list.map((r) => `<div class="item"><div><b>${esc(r.title || "")}</b> <span class="tag">${r.quality === "full" ? "повне" : r.quality === "alive_test" ? "тест оживлення" : "тест"}</span><span class="tag">${esc(r.video_q || "")}</span>${r.music ? `<span class="tag">музика</span>` : ""}
      <div class="note">${fmt(r.created)}${r.duration_s ? " · " + r.duration_s + " с" : ""}${r.size_mb ? " · " + r.size_mb + " МБ" : ""}</div></div>
      <div class="row"><button class="sec" data-play="${esc(r.dir)}">Дивитись</button><a href="/api/projects/${encodeURIComponent(pid)}/renders/${encodeURIComponent(r.dir)}/video?t=${encodeURIComponent(TOKEN)}" download><button class="sec">Зберегти</button></a></div></div>`).join("") : `<div class="empty">Ще немає. Натисніть «Намалювати».</div>`}
    <div class="row" style="margin-top:10px"><button class="sec" id="ropen">Відкрити папку з відео</button></div><div id="rplay"></div></div>`;
  box.querySelectorAll("[data-play]").forEach((b) => (b.onclick = () => { $("#rplay").innerHTML = `<video controls autoplay style="width:100%;max-width:960px;margin-top:10px;border-radius:8px" src="/api/projects/${encodeURIComponent(pid)}/renders/${encodeURIComponent(b.dataset.play)}/video?t=${encodeURIComponent(TOKEN)}"></video>`; }));
  $("#ropen").onclick = () => api(`/api/projects/${encodeURIComponent(pid)}/open-renders`, { method: "POST" });
}

async function drawDialog(pid, oid) {
  const pk = await api("/api/packs");
  let box = $("#drawbox");
  if (!box) { box = h(`<div id="drawbox" class="card"></div>`); $("#res").prepend(box); }
  if (!pk.hand || !pk.sound || !pk.ffmpeg) {
    box.innerHTML = `<h3 style="margin-top:0">Для малювання потрібні ресурси</h3><p class="note">${!pk.hand ? "Немає фото-рук. " : ""}${!pk.sound ? "Немає звуків. " : ""}${!pk.ffmpeg ? "Немає ffmpeg (перезапустіть інсталятор). " : ""}</p>
      <a href="#/settings"><button>Завантажити ресурси</button></a>`;
    box.scrollIntoView({ behavior: "smooth" }); return;
  }
  box.innerHTML = `<h3 style="margin-top:0">${oid === "__all__" ? "Намалювати весь набір одним роликом" : "Намалювати " + esc(oid)}</h3>
    <div class="row"><label>Якість<select id="dq"><option value="preview">Швидкий тест (перші 12 с, ~1 хв)</option><option value="full">Повне відео (кілька хвилин)</option><option value="alive_test">Тест оживлення (кінець малювання + моргання)</option></select></label>
    <label>Розмір кадру<select id="dvq"><option value="1080p">Full HD 1080p (краща якість)</option><option value="720p">HD 720p (швидше)</option></select></label>
    <label>Музика<select id="dmu"><option value="">Без музики</option>${(pk.music || []).map((b) => `<option>${esc(b)}</option>`).join("")}</select></label>
    <label>Гучність музики<select id="dmv"><option value="low">Тиха</option><option value="mid">Середня</option></select></label>
    <label>Фон<select id="dbg"><option value="">Білий аркуш</option>${pk.backgrounds.map((b) => `<option>${esc(b)}</option>`).join("")}</select></label>
    <label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:8px"><input id="dlb" type="checkbox" style="padding:0" checked> моргати під час малювання (коли очі вже готові)</label>
    <label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:8px"><input id="dal" type="checkbox" style="padding:0" checked> оживити після малювання (моргання в кінці)</label>
    <button id="dgo">Намалювати</button></div><div id="dst" class="note"></div><div id="dvid"></div>`;
  box.scrollIntoView({ behavior: "smooth" });
  $("#dgo").onclick = async () => {
    $("#dgo").disabled = true; $("#dst").textContent = "Запуск…";
    try {
      let j = await api("/api/render", { json: { project: pid, object: oid, quality: $("#dq").value, background: $("#dbg").value || null, alive: $("#dal").checked, live_blink: $("#dlb").checked, video: $("#dvq").value, music: $("#dmu").value || null, music_volume: $("#dmv").value } });
      while (j.state === "running" || j.state === "queued") {
        const pct = Math.round(j.progress * 100);
        $("#dst").innerHTML = j.state === "queued" ? "У черзі — почнеться, щойно завершиться попередній рендер. " + `<button class="sec" id="dx">Скасувати</button>` : `<div class="bar"><i style="width:${pct}%"></i></div>${j.parts > 1 ? "об'єкт " + j.part + " з " + j.parts + " · " : ""}${pct}%${j.eta ? " · залишилось близько " + (j.eta > 90 ? Math.round(j.eta / 60) + " хв" : j.eta + " с") : ""} <button class="sec" id="dx">Скасувати</button>`;
        $("#dx").onclick = () => api(`/api/render/${j.id}/cancel`, { method: "POST" });
        await new Promise((r) => setTimeout(r, 1500));
        j = await api("/api/render/" + j.id);
      }
      if (j.state === "done") {
        $("#dst").innerHTML = `Готово. ${j.qa ? "Тривалість " + j.qa.duration_s + " с. Безпечність руки: " + (j.qa.unsafe_hand_frames === 0 ? "ок" : j.qa.unsafe_hand_frames + " кадрів поза межами") : ""}`;
        $("#dvid").innerHTML = `<video controls style="width:100%;max-width:720px;margin-top:10px;border-radius:8px" src="/api/render/${j.id}/video?t=${encodeURIComponent(TOKEN)}"></video>
          <div class="note">Файл лежить у папці проєкту (renders). Усі готові відео — у списку нижче. ${j.size_mb ? "Розмір " + j.size_mb + " МБ." : ""}</div>`;
        loadRenders(pid);
      } else if (j.state === "cancelled") $("#dst").textContent = "Скасовано.";
      else $("#dst").innerHTML = `<span class="bad">${esc(j.error || "Помилка")}</span><pre>${esc((j.log || []).slice(-8).join("\n"))}</pre>`;
    } catch (e) { $("#dst").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
    $("#dgo").disabled = false;
  };
}

const CX = { 1: "дуже просто", 2: "просто", 3: "середньо", 4: "детально", 5: "багато деталей" };
const EM = { blink: "моргання", smile: "усмішка", surprise: "здивування", sad: "сум", angry: "злість", laugh: "сміх", sleepy: "сон", wink: "підморгування", love: "закоханість", scared: "страх" };
function viewPrompt() {
  view.innerHTML = `<h1>Prompt Studio</h1><p class="sub">Опишіть, що хочете намалювати. Програма складе точний запит для ChatGPT, щоб малюнки одразу підходили для малювання й оживлення.</p>
    <div class="card"><div class="row">
      <label>Тип<select id="k">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
      <label>Скільки об'єктів<input id="n" type="number" min="1" max="12" value="6"></label></div>
      <div class="row" style="margin-top:12px"><label>Що саме (англійською краще)<input id="s" placeholder="6 cute friendly monsters, each different"></label></div>
      <div class="row" style="margin-top:12px"><label>Палітра<input id="pal" value="bright, saturated, child friendly"></label>
      <label>Додатково<input id="ex" placeholder="необов'язково"></label></div>
      <div class="row" style="margin-top:12px"><label>Складність малюнка<select id="cx">${Object.entries(CX).map(([k, v]) => `<option value="${k}"${k === "3" ? " selected" : ""}>${k} — ${v}</option>`).join("")}</select></label></div>
      <p class="note" style="margin:12px 0 4px">Набір виразів тієї самої ілюстрації (окремі кадри-редагування в ChatGPT):</p>
      <div class="row" style="flex-wrap:wrap">${Object.entries(EM).map(([k, v]) => `<label style="flex:0 0 auto;flex-direction:row;align-items:center;gap:6px"><input class="em" data-e="${k}" type="checkbox" style="padding:0"> ${v}</label>`).join("")}</div>
      <div class="row" style="margin-top:14px"><button id="go">Скласти запит</button></div><div id="perr" class="bad note"></div></div>
    <div id="out"></div>`;
  const kind = $("#k"), n = $("#n");
  kind.onchange = () => { n.disabled = kind.value === "character"; if (kind.value === "character") n.value = 1; };
  $("#go").onclick = async () => {
    $("#perr").textContent = "";
    if (!$("#s").value.trim()) { $("#perr").textContent = "Опишіть, що малювати."; return; }
    const variants = ["base", ...[...document.querySelectorAll(".em:checked")].map((c) => c.dataset.e)];
    try {
      const r = await api("/api/prompt", { json: { kind: kind.value, subject: $("#s").value, count: +n.value || 1, palette: $("#pal").value, extra: $("#ex").value, variants, complexity: +$("#cx").value } });
      current.request = r.request;
      const fu = (r.request.followups || []).map((f) => `<h3>Додатковий кадр: ${esc(f.label || f.name)}</h3><pre>${esc(f.prompt)}</pre><button class="sec" data-c="${esc(f.prompt)}">Скопіювати</button>`).join("");
      $("#out").innerHTML = `<div class="card"><h3 style="margin-top:0">Вставте це в ChatGPT</h3><pre id="txt">${esc(r.chatgpt_text)}</pre>
        <div class="row"><button id="cp">Скопіювати запит</button><button class="sec" id="mk">Створити проєкт із цим запитом</button></div>
        <p class="note">Після відповіді ChatGPT збережіть картинку й завантажте її в проєкт — програма перевірить, чи вона відповідає запиту.</p>${fu}</div>`;
      $("#cp").onclick = async () => { await navigator.clipboard.writeText(r.chatgpt_text); $("#cp").textContent = "Скопійовано"; };
      $("#mk").onclick = () => { location.hash = "#/projects"; };
      document.querySelectorAll("[data-c]").forEach((b) => (b.onclick = async () => { await navigator.clipboard.writeText(b.dataset.c); b.textContent = "Скопійовано"; }));
    } catch (e) { $("#perr").textContent = e.message; }
  };
}

async function viewSettings() {
  const [i, u] = await Promise.all([api("/api/info"), api("/api/update/check")]);
  view.innerHTML = `<h1>Налаштування</h1><p class="sub">Версія ${esc(i.version)} · дані: ${esc(i.home)}</p>
    <div class="card"><h3 style="margin-top:0">Оновлення</h3>
      <p class="note">${u.installed ? (u.error ? esc(u.error) : u.available ? "Є нова версія " + esc(u.version) : "У вас остання версія.") : esc(u.reason || "")}</p>
      <div class="row"><label>Адреса каналу оновлень (необов'язково)<input id="uurl" placeholder="за замовчуванням" value="${esc(i.settings.update_url || "")}"></label>
      <button id="sv">Зберегти</button><button class="sec" id="ck">Перевірити оновлення</button>
      <button class="sec" id="rb" ${u.can_rollback ? "" : "disabled"}>Повернути попередню версію${u.previous ? " (" + esc(u.previous) + ")" : ""}</button></div></div>`;
  const pk = await api("/api/packs");
  const ok = (v) => (v ? `<span class="tag ok">є</span>` : `<span class="tag warn">немає</span>`);
  view.appendChild(h(`<div class="card"><h3 style="margin-top:0">Ресурси для малювання</h3>
    <p>Фото-рука ${ok(pk.hand)} · Звуки ${ok(pk.sound)} · ffmpeg ${ok(pk.ffmpeg)} · Фони: ${pk.backgrounds.length ? esc(pk.backgrounds.join(", ")) : "немає"}</p>
    <p class="note">Рука й звуки беруться з вашого архіву (наприклад, SHINE_Dragon_Pilot_v21….zip) і зберігаються лише на цьому комп'ютері.</p>
    <div class="row"><label>Шлях до архіву або папки<input id="ipath" placeholder="G:\\SHINE DRAWING\\SHINE_Dragon_Pilot_v21_Reproducible_2026-11-10.zip"></label>
    <button id="iimp">Імпортувати</button><button class="sec" id="ifind">Знайти автоматично</button></div>
    <div id="ires" class="note"></div>
    <div class="drop" id="pdrop" style="margin-top:12px;padding:18px">Або перетягніть сюди архів <b>.zip</b> (Dragon Pilot…) чи окремі файли: <b>overhead_*.png</b>, <b>assets.json</b>, <b>marker_active_passes.wav</b>, <b>scribbling_continuous.wav</b>
      <button class="sec" id="ppick">оберіть файли</button><input id="pfile" type="file" accept=".zip,.png,.wav,.json" multiple hidden></div>
    <div class="row" style="margin-top:12px"><label>Додати фон-стіл (PNG)<input id="bgf" type="file" accept=".png"></label>
    <label>Додати музику (mp3/wav/ogg/m4a/flac)<input id="muf" type="file" accept=".mp3,.wav,.ogg,.m4a,.flac"></label></div>
    <p class="note">Музика: ${pk.music.length ? esc(pk.music.join(", ")) : "немає"}. Використовуйте лише ту, що дозволяє комерційне використання на YouTube.</p></div>`));
  $("#muf").onchange = async (e) => { const fd = new FormData(); fd.append("file", e.target.files[0]); try { await api("/api/packs/music", { method: "POST", body: fd }); viewSettings(); } catch (er) { $("#ires").innerHTML = `<span class="bad">${esc(er.message)}</span>`; } };
  $("#ifind").onclick = async () => { $("#ires").textContent = "Шукаю…"; const r = await api("/api/packs/find"); $("#ires").innerHTML = r.candidates.length ? "Знайдено (натисніть, щоб підставити):<br>" + r.candidates.map((c) => `<a href="#" data-p="${esc(c)}">${esc(c)}</a>`).join("<br>") : "Нічого не знайдено — вкажіть шлях вручну."; $("#ires").querySelectorAll("[data-p]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); $("#ipath").value = a.dataset.p; })); };
  $("#iimp").onclick = async () => { $("#ires").textContent = "Імпортую…"; try { const r = await api("/api/packs/import", { json: { path: $("#ipath").value } }); $("#ires").textContent = "Імпортовано: " + r.imported.join(", "); setTimeout(viewSettings, 800); } catch (e) { $("#ires").innerHTML = `<span class="bad">${esc(e.message)}</span>`; } };
  const upPack = async (files) => { $("#ires").textContent = "Завантажую (великий архів може зайняти хвилину)…"; const fd = new FormData(); for (const f of files) fd.append("files", f);
    try { const r = await api("/api/packs/upload", { method: "POST", body: fd }); $("#ires").textContent = "Імпортовано: " + r.imported.join(", "); setTimeout(viewSettings, 800); } catch (e) { $("#ires").innerHTML = `<span class="bad">${esc(e.message)}</span>`; } };
  $("#ppick").onclick = () => $("#pfile").click(); $("#pfile").onchange = (e) => upPack(e.target.files);
  const pd = $("#pdrop"); pd.ondragover = (e) => { e.preventDefault(); pd.classList.add("over"); }; pd.ondragleave = () => pd.classList.remove("over");
  pd.ondrop = (e) => { e.preventDefault(); pd.classList.remove("over"); upPack(e.dataTransfer.files); };
  $("#bgf").onchange = async (e) => { const fd = new FormData(); fd.append("file", e.target.files[0]); try { await api("/api/packs/background", { method: "POST", body: fd }); viewSettings(); } catch (er) { $("#ires").innerHTML = `<span class="bad">${esc(er.message)}</span>`; } };
  $("#sv").onclick = async () => { await api("/api/settings", { json: { update_url: $("#uurl").value.trim() } }); $("#sv").textContent = "Збережено"; };
  $("#ck").onclick = () => checkUpdate(true);
  $("#rb").onclick = async () => { if (!confirm("Повернутись до попередньої версії? Програма перезапуститься. Проєкти не зачіпаються.")) return; try { await api("/api/update/rollback", { method: "POST" }); $("#rb").textContent = "Перезапуск…"; } catch (e) { alert(e.message); } };
}

/* ---------- маршрутизація ---------- */
async function route() {
  const hash = location.hash || "#/projects";
  const [, r, arg] = hash.split("/");
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("on", a.dataset.r === (r === "project" ? "projects" : r)));
  try {
    if (r === "project") await viewProject(decodeURIComponent(arg));
    else if (r === "prompt") viewPrompt();
    else if (r === "settings") await viewSettings();
    else await viewProjects();
  } catch (e) { view.innerHTML = `<div class="card bad">${esc(e.message)}</div>`; }
}
window.addEventListener("hashchange", route);
route(); checkUpdate(false);
