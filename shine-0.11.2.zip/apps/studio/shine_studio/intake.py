"""Intake (M1): аналіз завантажених ілюстрацій.

Для кожного джерела (PNG/SVG): композит на білий -> перевірка за запитом (promptgen.check) -> розрізання листа
на об'єкти (sets.split_sheet) -> по кожному об'єкту: кроп у objects/, пошук очей, план оживлення з ПРИЧИНОЮ.
Принцип fail-closed: оживлення пропонується лише там, де очі впевнено знайдені; інакше - лише малювання.
"""
import json
from pathlib import Path
from typing import Any, Dict, List

import cv2
import numpy as np

from . import paths, project

MAX_SIDE = 3000      # більші зображення зменшуємо для аналізу (оригінал не змінюється)


def _engine():
    paths.add_engine_to_path()
    import promptgen, puppet, sets
    return promptgen, puppet, sets


def load_bgr(path: Path) -> np.ndarray:
    """PNG/SVG -> BGR uint8 на білому тлі (прозорість заливається білим)."""
    if path.suffix.lower() == ".svg":
        png = None
        try:                                         # resvg: без DLL, працює на Windows «з коробки»
            import resvg_py
            png = bytes(resvg_py.svg_to_bytes(svg_path=str(path), width=2000))
        except Exception:
            png = None
        if png is None:
            try:
                import cairosvg
                png = cairosvg.svg2png(url=str(path), output_width=2000, unsafe=False)
            except Exception:
                raise project.ProjectError("Не вдалося відкрити SVG (немає рендера). Завантажте PNG або оновіть програму.")
        buf = np.frombuffer(png, np.uint8)
    else:
        buf = np.fromfile(str(path), np.uint8)
    im = cv2.imdecode(buf, cv2.IMREAD_UNCHANGED)
    if im is None:
        raise project.ProjectError("Не вдалося прочитати зображення")
    if im.ndim == 2:
        im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
    if im.shape[2] == 4:
        a = im[:, :, 3:4].astype(np.float32) / 255
        im = (im[:, :, :3] * a + 255 * (1 - a)).astype(np.uint8)
    s = max(im.shape[:2])
    if s > MAX_SIDE:
        k = MAX_SIDE / s
        im = cv2.resize(im, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
    return im


def count_eyes(puppet, crop) -> int:
    try:
        ps = puppet.PuppetShow(cfg=dict(seconds=1.0, limbs=False, breathe=None, bounce_end=False), fps=30)
        ps.frame(0, crop)
        return len(ps.eyes)
    except Exception:
        return 0


def plan_for(kind: str, eyes: int) -> Dict[str, Any]:
    if kind != "object":
        return dict(draw=True, blink=False, reason="Дрібна деталь: лише малювання, без оживлення.")
    if eyes >= 1:
        return dict(draw=True, blink=True, reason=f"Очі впевнено знайдено ({eyes}): моргання безпечне.")
    return dict(draw=True, blink=False, reason="Очі не розпізнано: лише малювання (оживлення вимкнено, щоб не зіпсувати вигляд).")


def analyze(pid: str, layout: str = "auto") -> Dict[str, Any]:
    """layout: auto (об'єкти окремо, дрібниці лишаються з найближчим) | whole (увесь лист = один ролик) | split (як раніше)."""
    if layout not in ("auto", "whole", "split"):
        layout = "auto"
    promptgen, puppet, sets = _engine()
    pr = project.load(pid)
    root = project.project_path(pid)
    outdir = root / "objects"
    for f in outdir.glob("*.png"):
        f.unlink()
    objects: List[Dict[str, Any]] = []
    reports: List[Dict[str, Any]] = []
    for src in pr.sources:
        entry: Dict[str, Any] = dict(source=src.id)
        try:
            img = load_bgr(root / src.file)
        except Exception as e:
            entry["error"] = str(e)
            reports.append(entry)
            continue
        entry["size"] = [int(img.shape[1]), int(img.shape[0])]
        if pr.request:
            ok, rep = promptgen.check(pr.request, img)
            entry["check"] = rep
        objs = sets.split_sheet(img, mode=layout)
        for i, o in enumerate(objs):
            crop, box = o.crop(img)
            oid = f"{src.id}-o{i + 1:02d}"
            rel = f"objects/{oid}.png"
            cv2.imwrite(str(root / rel), crop)
            eyes = count_eyes(puppet, crop) if o.kind == "object" else 0
            objects.append(dict(id=oid, source=src.id, file=rel, kind=o.kind, bbox=list(box), area=o.area,
                                eyes=eyes, plan=plan_for(o.kind, eyes)))
        reports.append(entry)
    pr.objects = objects
    pr.emotions = {}                                  # кадри виразів прив'язані до старих об'єктів
    real = [o for o in objects if o["kind"] == "object"]
    pr.plan = dict(objects=len(real), animate=sum(1 for o in real if o["plan"]["blink"]),
                   draw_only=sum(1 for o in real if not o["plan"]["blink"]))
    project.save(pr)
    (root / "analysis" / "intake.json").write_text(json.dumps(dict(reports=reports, plan=pr.plan), ensure_ascii=False, indent=1), encoding="utf-8")
    return dict(reports=reports, objects=objects, plan=pr.plan)


EMOTION_NAMES = ("blink", "smile", "surprise", "sad", "angry", "laugh", "sleepy", "wink", "love", "scared")


def add_emotion(pid: str, oid: str, name: str, data: bytes) -> Dict[str, Any]:
    """Кадр виразу = ТА САМА ілюстрація (редагування в ChatGPT). Обрізається по рамці об'єкта, чуже поза об'єктом - білим."""
    if name not in EMOTION_NAMES:
        raise project.ProjectError("Невідомий вираз")
    pr = project.load(pid)
    o = next((x for x in pr.objects if x["id"] == oid and x["kind"] == "object"), None)
    if o is None:
        raise project.ProjectError("Об'єкт не знайдено — спершу проаналізуйте малюнок")
    root = project.project_path(pid)
    src = next(s for s in pr.sources if s.id == o["source"])
    base_full = load_bgr(root / src.file)
    tmp = root / "cache" / f"_emo_{oid}.png"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    tmp.write_bytes(data)
    try:
        var = load_bgr(tmp)
    finally:
        tmp.unlink(missing_ok=True)
    H, W = base_full.shape[:2]
    if var.shape[:2] != (H, W):
        if abs(var.shape[1] / var.shape[0] - W / H) > 0.02:
            raise project.ProjectError("Кадр виразу має інші пропорції, ніж оригінал: це має бути та сама картинка.")
        var = cv2.resize(var, (W, H), interpolation=cv2.INTER_AREA)
    x0, y0, x1, y1 = o["bbox"]
    crop = var[y0:y1, x0:x1].copy()
    base = cv2.imdecode(np.fromfile(str(root / o["file"]), np.uint8), cv2.IMREAD_COLOR)
    if base is not None and base.shape[:2] == crop.shape[:2]:
        non = (base.min(2) < 245).astype(np.uint8)
        non = cv2.morphologyEx(non, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
        cnt, _ = cv2.findContours(non, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        own = np.zeros_like(non)
        cv2.drawContours(own, cnt, -1, 1, -1)
        own = cv2.dilate(own, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))).astype(bool)
        out = np.full_like(crop, 255)
        out[own] = crop[own]
        crop = out
    rel = f"objects/{oid}.emo-{name}.png"
    cv2.imwrite(str(root / rel), crop)
    lst = [e for e in pr.emotions.get(oid, []) if e["name"] != name] + [dict(name=name, file=rel)]
    pr.emotions[oid] = lst
    project.save(pr)
    return dict(object=oid, emotions=lst)


def remove_emotion(pid: str, oid: str, name: str) -> Dict[str, Any]:
    pr = project.load(pid)
    root = project.project_path(pid)
    keep = []
    for e in pr.emotions.get(oid, []):
        if e["name"] == name:
            (root / e["file"]).unlink(missing_ok=True)
        else:
            keep.append(e)
    pr.emotions[oid] = keep
    project.save(pr)
    return dict(object=oid, emotions=keep)
