"""Попередній перегляд плану малювання: показує ПОРЯДОК і напрямок штрихів до довгого рендеру.

Контур - темні лінії з номером і стрілкою початку (від синього до червоного за порядком), заливка - світлі лінії.
Рахується на зменшеному кадрі (960x540), займає кілька секунд.
"""
from pathlib import Path
from typing import Any, Dict

import cv2
import numpy as np

from . import paths, project


def _col(t: float):
    """0..1 -> BGR від синього до червоного"""
    h = int(120 * (1 - t))
    return tuple(int(v) for v in cv2.cvtColor(np.uint8([[[h, 230, 230]]]), cv2.COLOR_HSV2BGR)[0, 0])


def make(pid: str, object_id: str) -> Dict[str, Any]:
    paths.add_engine_to_path()
    import planner as pl
    import render as rd
    from png_scene import PngScene
    pr = project.load(pid)
    o = next((x for x in pr.objects if x["id"] == object_id), None)
    if o is None:
        raise project.ProjectError("Об'єкт не знайдено — спершу проаналізуйте малюнок")
    root = project.project_path(pid)
    png = (root / o["file"]).resolve()
    if root.resolve() not in png.parents or not png.is_file():
        raise project.ProjectError("Файл об'єкта не знайдено")
    W, H = 960, 540
    sq = 0.9 * H
    sc = PngScene(str(png), W=W, H=H, target_box=((W - sq) / 2, 0.05 * H, (W + sq) / 2, 0.95 * H), k=4)
    plan = pl.build_plan(sc, ink_scale=1.5, color_width=int(round(24 * W / 1280)))
    ev, _, _ = rd.build_timeline(plan, W, 1.0)
    ink = [s for s in plan["strokes"] if s["kind"] == "ink"]
    col = [s for s in plan["strokes"] if s["kind"] != "ink"]
    S = 2
    canvas = cv2.resize(cv2.cvtColor(np.full((H, W), 255, np.uint8), cv2.COLOR_GRAY2BGR), None, fx=S, fy=S)
    ref = None
    try:
        from painter2 import Painter2
        tim = {}
        _, tim, _ = rd.build_timeline(plan, W, 1.0)
        ref = Painter2(sc, plan, tim).ref_bgr
        canvas = cv2.addWeighted(cv2.resize(ref, None, fx=S, fy=S), 0.35, canvas, 0.65, 0)
    except Exception:
        pass
    for s in col:
        p = (np.asarray(s["pts"]) * S).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(canvas, [p], False, (200, 200, 200), 1, cv2.LINE_AA)
    n = max(1, len(ink))
    for i, s in enumerate(ink):
        p = (np.asarray(s["pts"]) * S).astype(np.int32).reshape(-1, 1, 2)
        c = _col(i / n)
        cv2.polylines(canvas, [p], False, c, 3, cv2.LINE_AA)
        x, y = int(p[0, 0, 0]), int(p[0, 0, 1])
        cv2.circle(canvas, (x, y), 6, c, -1, cv2.LINE_AA)
        cv2.putText(canvas, str(i + 1), (x + 7, y - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (30, 30, 30), 2, cv2.LINE_AA)
        cv2.putText(canvas, str(i + 1), (x + 7, y - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    out = root / "cache" / f"plan_{object_id}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out), canvas)
    return dict(file=f"cache/plan_{object_id}.png", ink_strokes=len(ink), fill_strokes=len(col),
                seconds=round(float(ev[-1]["t1"]), 1))
