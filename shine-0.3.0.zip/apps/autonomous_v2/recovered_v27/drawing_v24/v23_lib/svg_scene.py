#!/usr/bin/env python3
"""SHINE SVG Scene Contract v23: non-destructive semantic import + generic Story Events.

Intentional limitations: supports flat vector primitives; complex SVG features/unnamed Recraft
objects are explicitly sent to a review queue. A 'ready' scene has semantic ink and colors.
No Dragon-specific path numbers or pixel positions are present in this engine.
"""
from __future__ import annotations
import copy
import hashlib
import io
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict

import cairosvg
import cv2
import numpy as np
from lxml import etree
from PIL import Image

SVG_NS = 'http://www.w3.org/2000/svg'
INK = {'visible-ink', 'outline', 'ink', 'contour', 'stroke'}
COLOUR = {'colour', 'color', 'fill', 'colour-art', 'color-art'}
DRAWABLE = {'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon'}
UNSAFE = {'script', 'foreignObject', 'iframe', 'video', 'audio', 'animate', 'animateMotion', 'animateTransform', 'set'}
EXTERNAL = re.compile(r'(?:https?:|file:|data:|javascript:|@import|url\(\s*[\"\']?\s*(?!#))', re.IGNORECASE)


def local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def clean_name(value):
    return re.sub(r'[^a-z0-9]+','_',str(value or '').lower()).strip('_')


def load_svg(path):
    path=Path(path)
    content=path.read_bytes()
    if len(content)>15_000_000: raise ValueError('SVG exceeds 15 MB safe import budget')
    if b'<!DOCTYPE' in content.upper() or b'<!ENTITY' in content.upper():
        raise ValueError('DOCTYPE/ENTITY is forbidden in SVG input')
    root=etree.fromstring(content, parser=etree.XMLParser(resolve_entities=False,no_network=True,remove_comments=True,huge_tree=False))
    if local(root.tag)!='svg':raise ValueError('File does not have an SVG root')
    for e in root.iter():
        if local(e.tag) in UNSAFE:raise ValueError(f'Unsupported/unsafe element: {local(e.tag)}')
        for a,v in e.attrib.items():
            key=local(a).lower()
            if key.startswith('on'):raise ValueError('Inline event handler forbidden')
            if key in {'href','src'} and v and not v.startswith('#'):raise ValueError('SVG external resource is forbidden')
            if key in {'style','filter','fill','stroke','clip-path','mask'} and EXTERNAL.search(v):
                raise ValueError('SVG external resource or URL style is forbidden')
    # Deterministic internal IDs for anonymous Recraft vector elements. Never write to source.
    used={e.get('id') for e in root.iter() if e.get('id')}
    for i,e in enumerate(drawable_nodes(root)):
        if e.get('id') is None:
            candidate=f'shine_el_{i:03d}'
            if candidate in used:raise ValueError('Stable generated SVG ID collision: '+candidate)
            e.set('id',candidate)
            used.add(candidate)
    return root,content


def size_of(root):
    vb=root.get('viewBox','').replace(',',' ').split()
    if len(vb)==4:
        try:
            x,y,w,h=map(float,vb)
            if w>0 and h>0 and all(math.isfinite(z) for z in [x,y,w,h]):return (x,y,w,h)
        except ValueError: pass
    def f(attr):
        val=root.get(attr,'')
        m=re.match(r'^\s*(\d+(?:\.\d+)?)(?:px)?\s*$',val)
        return float(m.group(1)) if m else None
    w,h=f('width'),f('height')
    if w and h and w>0 and h>0:return (0,0,w,h)
    raise ValueError('SVG requires a valid viewBox or pixel width/height')


def drawable_nodes(root):
    return [e for e in root.iter() if local(e.tag) in DRAWABLE and not any(local(p.tag) in {'defs','clipPath','mask','symbol','pattern','marker'} for p in e.iterancestors())]


def classify(node):
    paint=clean_name(node.get('data-shine-paint'))
    if paint in {'paper','hidden'}:return 'skip'   # v36 preparation: background paper / fully covered shapes are not drawn
    if paint in INK:return 'outline'
    if paint in COLOUR:return 'color'
    role=clean_name(node.get('data-shine-role'))
    if role in INK:return 'outline'
    if role in COLOUR:return 'color'
    for parent in node.iterancestors():
        if local(parent.tag)!='g': continue
        parent_role=clean_name(parent.get('data-shine-layer') or parent.get('data-shine-role'))
        if parent_role in INK:return 'outline'
        if parent_role in COLOUR:return 'color'
    node_id=clean_name(node.get('id'))
    if node_id.endswith('_visible_outline') or node_id.startswith('ink_') or node_id.endswith('_outline'):
        return 'outline'
    if node.get('stroke') not in (None,'none') and node.get('fill')=='none':return 'outline'
    # Other flat fills may be dark 'ink-shaped' polygons; never infer from darkness.
    return 'unclassified'


def semantic_group(node):
    val=node.get('data-shine-group')
    if val:return clean_name(val)
    for p in node.iterancestors():
        if local(p.tag)=='g':
            v=p.get('data-shine-role') or p.get('data-shine-group') or p.get('id')
            if v and clean_name(v) not in {'colour_art','visible_ink','color_art'}:
                return clean_name(v)
    return ''


def extract_manifest(svg_path,annotations=None):
    root,raw=load_svg(svg_path)
    bbox=size_of(root)
    shapes=drawable_nodes(root)
    groups=defaultdict(list)
    roles=defaultdict(int)
    annotations=annotations or {}
    if annotations and annotations.get('schema')!='SHINE.svg-annotation.v1':
        raise ValueError('Invalid annotation schema')
    if annotations and annotations.get('source_sha256')!=hashlib.sha256(raw).hexdigest():
        raise ValueError('SVG annotation SHA mismatch — annotation belongs to another file')
    forced={}
    for entry in annotations.get('groups',[]):
        g=clean_name(entry['name'])
        for ident in entry['element_ids']:
            if ident in forced:raise ValueError('Element assigned to two different semantic groups')
            forced[ident]=g
    all_ids={x.get('id') for x in shapes}
    if set(forced)-all_ids:raise ValueError('Annotation mentions unknown SVG element IDs')
    eye_roles=annotations.get('eye_roles',{})
    for side,ids in eye_roles.items():
        if side not in {'left','right'} or set(ids)-all_ids:
            raise ValueError('Annotation references invalid eye selector')
    painted=defaultdict(int)
    items=[]
    for i,node in enumerate(shapes):
        c=classify(node);g=semantic_group(node)
        ident=node.get('id') or f'shine_el_{i:03d}'
        item={'index':i,'id':ident,'tag':local(node.tag),'group':forced.get(ident,g),'paint':c}
        g=item['group']
        items.append(item)
        painted[c]+=1
        if g:groups[g].append(ident)
    separate=painted['outline']>0 and (painted['color']>0 or painted['unclassified']>0)
    sem=bool(groups)
    unsafe_tags=sorted({local(e.tag) for e in root.iter() if local(e.tag) in {'image','text','filter','mask','clipPath','use','pattern'}})
    return {
      'schema':'SHINE.svg-scene.v1','source':{'file':Path(svg_path).name,'sha256':hashlib.sha256(raw).hexdigest()},
      'viewBox':list(bbox),'element_count':len(items),'paint_counts':dict(painted),'groups':{k:v for k,v in groups.items()},
      'unsupported_features':unsafe_tags,'drawing_readiness':('READY_FOR_PATH_PLANNING' if separate else 'NEEDS_OUTLINE_PREPARATION'),
      'story_readiness':('SEMANTIC_GROUPS_AVAILABLE' if sem else 'REQUIRES_SEMANTIC_ANNOTATION'),
      'items':items,'semantic_eye_roles':eye_roles,'manual_annotations_applied':bool(annotations),
      'review_notes':(['Automatic outline detection is insufficient; visible ink regions must be supplied or reviewed.'] if not separate else [])
        + (['No named groups; do not guess eyes, wings, or character parts from path indices.'] if not sem else [])
        + ([f'Potentially complex SVG: {unsafe_tags}'] if unsafe_tags else [])
    }


def select_ids(manifest, target):
    if 'group' in target:
        group=clean_name(target['group'])
        matches={x['id'] for x in manifest['items'] if x['group']==group}
    elif 'eye' in target:
        which=clean_name(target['eye'])
        if which not in {'left','right'}:raise ValueError('eye must be left or right')
        matches=set(manifest.get('semantic_eye_roles',{}).get(which,[]))
        for item in manifest['items']:
            i=clean_name(item['id'])
            # Eye fill, eye shine and its visible ink from both named vector formats.
            if re.search(r'(?:^|_)eye_'+which+r'(?:_|$)',i) or re.search(r'(?:^|_)'+which+r'_eye(?:_|$)',i):
                matches.add(item['id'])
    else:raise ValueError('Event target requires a semantic group or eye selector')
    if not matches:raise ValueError('No semantic elements match target '+str(target))
    return matches


def filtered_svg_bytes(root, keep):
    cloned=copy.deepcopy(root)
    for e in drawable_nodes(cloned):
        if e.get('id') not in keep:
            e.getparent().remove(e)
    return etree.tostring(cloned,encoding='utf-8')


def raster(root, width, height, keep=None):
    raw=etree.tostring(root,encoding='utf-8') if keep is None else filtered_svg_bytes(root,keep)
    png=cairosvg.svg2png(bytestring=raw,output_width=width,output_height=height)
    return np.asarray(Image.open(io.BytesIO(png)).convert('RGBA')).copy()


def compose_rgba(bottom, top):
    a=top[:,:,3:4].astype(np.float32)/255.0
    b=bottom[:,:,3:4].astype(np.float32)/255.0
    out_a=a+b*(1-a)
    rgb=(top[:,:,:3].astype(np.float32)*a+bottom[:,:,:3].astype(np.float32)*b*(1-a))/np.maximum(out_a,1e-8)
    return np.dstack([np.clip(rgb,0,255),np.clip(out_a[:,:,0]*255,0,255)]).astype('uint8')


def onto_white(rgba):
    a=rgba[:,:,3:4].astype(np.float32)/255
    return np.clip(rgba[:,:,:3]*a+255*(1-a),0,255).astype(np.uint8)


def ease(u):
    v=min(1,max(0,float(u)))
    return v*v*(3-2*v)


def transform_sprite(sprite,pivot,dx=0,dy=0,rotation=0,scale=1):
    h,w=sprite.shape[:2]
    M=cv2.getRotationMatrix2D(tuple(map(float,pivot)),float(rotation),float(scale))
    M[:,2]+=np.array([dx,dy])
    return cv2.warpAffine(sprite,M,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))


def alpha_bbox(rgba):
    ys,xs=np.where(rgba[:,:,3]>24)
    if not len(xs):raise ValueError('Selected semantic object is not visible')
    return [int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]


def prepare_scene(svg_path,config,width=800,annotations=None):
    root,_=load_svg(svg_path)
    manifest=extract_manifest(svg_path,annotations)
    x,y,w,h=size_of(root)
    height=max(2,2*round(width*h/w/2))
    all_ids={i['id'] for i in manifest['items']}
    seen=set(); extracted=[]
    for ev in config['events']:
        target=ev['target']; selector=select_ids(manifest,target)
        if seen.intersection(selector):
            raise ValueError('Overlapping animated SVG targets not supported; keep independent layers')
        seen.update(selector)
        extracted.append((ev,selector))
    orig=raster(root,width,height)
    base=raster(root,width,height,keep=all_ids-seen)
    layers=[]
    rebuilt=base.copy()
    for ev,ids in extracted:
        layer=raster(root,width,height,keep=ids)
        b=alpha_bbox(layer)
        center=((b[0]+b[2])/2,(b[1]+b[3])/2)
        layers.append({'event':ev,'bbox':b,'pivot':center,'rgba':layer})
        rebuilt=compose_rgba(rebuilt,layer)
    o=onto_white(orig);r=onto_white(rebuilt)
    diff=np.abs(o.astype(np.int16)-r.astype(np.int16))
    mismatches=int(np.any(diff>40,axis=2).sum());total=width*height
    # Large reconstruction error means moving part occludes later elements; reject to avoid holes.
    fraction=mismatches/total
    if fraction>.001:
        raise ValueError(f'Semantic layer reconstruction failed QA: {mismatches} pixels / {total} (>0.1%); needs manual layer review')
    return {'manifest':manifest,'original':orig,'base':base,'layers':layers,'width':width,'height':height,
            'qa':{'max_color_delta':int(diff.max()),'pixels_gt_40':mismatches,'pixel_fraction_gt_40':round(fraction,7),
                  'source_sha256':manifest['source']['sha256'],'svg_remains_unchanged':True}}


def event_layer(layer,t,width,height):
    ev=layer['event'];a=float(ev['start']);b=float(ev['end']);kind=ev['type']
    rgba=layer['rgba']
    if kind=='hover':
        if not (a<=t<=b):return rgba
        span=max(b-a,1e-8)
        # exactly same position before and after episode (no frame jump)
        envelope=math.sin(math.pi*(t-a)/span)**2
        dx=ev.get('amplitude_px',8)*math.sin((t-a)*3.5)*envelope
        dy=-ev.get('lift_px',7)*envelope
        theta=ev.get('rotation_deg',6)*math.sin((t-a)*2.1)*envelope
        return transform_sprite(rgba,layer['pivot'],dx,dy,theta)
    if kind=='pulse':
        if not (a<=t<=b):return rgba
        span=max(b-a,1e-8)
        envelope=math.sin(math.pi*(t-a)/span)**2
        sf=1+ev.get('scale_amount',.1)*envelope*(.5+.5*math.sin((t-a)*12))
        return transform_sprite(rgba,layer['pivot'],scale=sf)
    if kind=='wink':
        if not (a<=t<=b):return rgba
        # Isolated eye(s) squash toward center; independent from face-background and geometry.
        p=math.sin(math.pi*(t-a)/(b-a))**2
        closure=ease((p-.1)/.65)
        b0=layer['bbox'];mid=(b0[1]+b0[3])/2
        scl=1-.93*closure
        mat=np.array([[1,0,0],[0,scl,(1-scl)*mid]],dtype=np.float32)
        return cv2.warpAffine(rgba,mat,(width,height),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
    raise ValueError('Unsupported event type: '+str(kind))


def frame_at(scene,t):
    bg=scene['base'].copy()
    for layer in scene['layers']:
        pic=event_layer(layer,t,scene['width'],scene['height'])
        bg=compose_rgba(bg,pic)
    return onto_white(bg)


def compile_config(manifest):
    groups=set(manifest['groups'])
    events=[]
    # Explicit semantic metadata only. No guessing from shape/color geometry.
    if 'butterfly' in groups:
        events.append({'id':'fly_01','type':'hover','target':{'group':'butterfly'},'start':.5,'end':3.0,'amplitude_px':6,'lift_px':7,'rotation_deg':5})
    elif 'sparkles' in groups:
        events.append({'id':'glints_01','type':'pulse','target':{'group':'sparkles'},'start':.6,'end':3.4,'scale_amount':.10})
    if manifest.get('semantic_eye_roles',{}).get('left') or any(re.search(r'(?:^|_)eye_left(?:_|$)|(?:^|_)left_eye(?:_|$)',clean_name(x['id'])) for x in manifest['items']):
        events.append({'id':'wink_01','type':'wink','target':{'eye':'left'},'start':1.4,'end':1.9})
    return {'schema':'SHINE.story-events.v2','source_sha256':manifest['source']['sha256'],
      'duration_s':4.0,'fps':30,'events':events,
      'status':'READY_FOR_REVIEW' if events else 'NEEDS_SEMANTIC_ANNOTATION',
      'note':'Event suggestions require review; no code or pixel coordinates tied to a specific character.'}


def validate_config(manifest,config):
    if config.get('schema')!='SHINE.story-events.v2':raise ValueError('Bad Story Events schema')
    if config.get('source_sha256')!=manifest['source']['sha256']:raise ValueError('Source SVG changed since event manifest was created')
    d=float(config['duration_s'])
    if not (0<d<=40):raise ValueError('Unsupported duration')
    for ev in config['events']:
        if ev['type'] not in {'wink','hover','pulse'}:raise ValueError('Unknown event type')
        if not (0<=float(ev['start'])<float(ev['end'])<=d):raise ValueError('Invalid event times')
        select_ids(manifest,ev['target'])
    return True


def drawing_plan_candidate(manifest):
    """Typed outline-first contract for existing geometry planner; not a stroke animation itself."""
    o=[i['id'] for i in manifest['items'] if i['paint']=='outline']
    f=[i['id'] for i in manifest['items'] if i['paint']=='color']
    ambiguous=[i['id'] for i in manifest['items'] if i['paint']=='unclassified']
    return {
      'schema':'SHINE.drawing-candidate.v1','source_sha256':manifest['source']['sha256'],
      'status':'READY_FOR_GEOMETRY_PLANNER' if o and f else 'REQUIRES_VISIBLE_INK_PREPARATION',
      'phases':[{'type':'trace_visible_outline','element_ids':o},
                {'type':'paint_color_regions','element_ids':f}],
      'unclassified_element_ids':ambiguous,
      'groups':{g:ids for g,ids in manifest['groups'].items()},
      'contract':{
        'pixel_visible_occlusion_required':True,
        'outlines_before_colors':True,
        'color_paths_not_equal_to_marker_travel_paths':True,
        'manual_direction_overrides_allowed':True,
        'actor_and_contact_audio_tracks_independent':True,
        'note':'This is a role-separated candidate, NOT a ready animated Drawing Plan. Geometry paths, stroke order and fill motions remain separate, validated work.'
      }
    }
