"""Набори ресурсів користувача: рука (фото-спрайти), звуки (записи), фон. Живуть у Документи/SHINE/packs/default,
поза програмою, тому оновлення їх не чіпають і вони НІКОЛИ не потрапляють у публічний канал оновлень.

Імпорт: із zip-архіву або папки (наприклад, SHINE_Dragon_Pilot_v21...zip). Читаємо лише потрібні файли за фіксованими
іменами і самі вирішуємо, куди їх записати (захист від zip-slip).
"""
import os
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

from . import paths

HAND_FILES = ["overhead_right", "overhead_right_alt", "overhead_bottomright", "overhead_high"]
WAVS = ["marker_active_passes.wav", "scribbling_continuous.wav"]


class PackError(ValueError):
    pass


def pack_dir() -> Path:
    p = paths.home() / "packs" / "default"
    (p / "hand").mkdir(parents=True, exist_ok=True)
    (p / "sound").mkdir(exist_ok=True)
    (p / "background").mkdir(exist_ok=True)
    return p


def hand_dir() -> Path:
    """Каталог, який чекає рушій: <dir>/assets.json і <dir>/../<file> (file = overhead_assets_v11/x.png)."""
    return pack_dir() / "hand" / "overhead_assets_v11"


def sound_dir() -> Path:
    return pack_dir() / "sound"


def backgrounds() -> List[Path]:
    return sorted(p for p in (pack_dir() / "background").glob("*.png"))


def status() -> Dict[str, object]:
    h = hand_dir()
    hand = (h / "assets.json").exists() and all((h / f"{n}.png").exists() for n in HAND_FILES)
    sound = all((sound_dir() / w).exists() for w in WAVS)
    return dict(hand=hand, sound=sound, backgrounds=[p.name for p in backgrounds()], ffmpeg=ffmpeg_exe() is not None)


# ---------------- ffmpeg (з pip-пакета imageio-ffmpeg; рушій викликає його за ім'ям 'ffmpeg') ----------------
def ffmpeg_exe() -> Optional[Path]:
    exe = shutil.which("ffmpeg")
    if exe:
        return Path(exe)
    try:
        import imageio_ffmpeg
        return Path(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        return None


def ensure_ffmpeg_on_path() -> Optional[Path]:
    exe = ffmpeg_exe()
    if exe is None:
        return None
    if exe.stem.lower() == "ffmpeg":
        d = exe.parent
    else:                                           # imageio-ffmpeg: файл зветься ffmpeg-win-x86_64-v7.1.exe
        d = paths.home() / "bin"
        d.mkdir(exist_ok=True)
        link = d / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
        if not link.exists() or link.stat().st_size != exe.stat().st_size:
            shutil.copy2(exe, link)
            link.chmod(0o755)
    os.environ["PATH"] = str(d) + os.pathsep + os.environ.get("PATH", "")
    return exe


# ---------------- імпорт ----------------
def _write(dst: Path, data: bytes) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, dst)


def _from_zip(z: zipfile.ZipFile) -> Dict[str, bytes]:
    """Шукаємо за суфіксом шляху; береться перший збіг (найкоротший шлях)."""
    names = sorted(z.namelist(), key=len)
    found: Dict[str, bytes] = {}

    def pick(suffix: str, key: str):
        for n in names:
            if n.replace("\\", "/").lower().endswith(suffix) and not n.endswith("/"):
                if z.getinfo(n).file_size > 60_000_000:
                    continue
                found[key] = z.read(n)
                return

    pick("overhead_assets_v11/assets.json", "assets.json")
    for n in HAND_FILES:
        pick(f"overhead_assets_v11/{n}.png", n + ".png")
    for w in WAVS:
        pick("/" + w, w)
    return found


def _from_dir(d: Path) -> Dict[str, bytes]:
    found: Dict[str, bytes] = {}

    def pick(rel: str, key: str, pattern: str):
        for p in sorted(d.rglob(pattern), key=lambda x: len(str(x))):
            if p.is_file() and p.as_posix().lower().endswith(rel):
                found[key] = p.read_bytes()
                return

    pick("overhead_assets_v11/assets.json", "assets.json", "assets.json")
    for n in HAND_FILES:
        pick(f"overhead_assets_v11/{n}.png", n + ".png", f"{n}.png")
    for w in WAVS:
        pick("/" + w, w, w)
    return found


def import_from(path: str) -> Dict[str, object]:
    p = Path(path.strip().strip('"'))
    if not p.exists():
        raise PackError("Шлях не знайдено")
    try:
        if p.is_file() and p.suffix.lower() == ".zip":
            with zipfile.ZipFile(p) as z:
                found = _from_zip(z)
        elif p.is_dir():
            found = _from_dir(p)
        else:
            raise PackError("Вкажіть zip-архів або папку")
    except zipfile.BadZipFile:
        raise PackError("Файл не є справжнім zip-архівом")
    got: List[str] = []
    if "assets.json" in found and all(n + ".png" in found for n in HAND_FILES):
        for n in HAND_FILES:
            _write(hand_dir() / f"{n}.png", found[n + ".png"])
        _write(hand_dir() / "assets.json", found["assets.json"])
        got.append("рука")
    if all(w in found for w in WAVS):
        for w in WAVS:
            _write(sound_dir() / w, found[w])
        got.append("звуки")
    if not got:
        raise PackError("У вказаному місці немає ні фото-рук (overhead_assets_v11), ні звуків (marker_active_passes.wav, scribbling_continuous.wav)")
    return dict(imported=got, status=status())


def find_candidates(limit: int = 12) -> List[str]:
    """Шукає архіви/папки з ресурсами у типових місцях (Завантаження, Робочий стіл, Документи, корені дисків)."""
    roots: List[Path] = []
    home = Path.home()
    for n in ("Downloads", "Desktop", "Documents", ""):
        roots.append(home / n if n else home)
    if os.name == "nt":
        for L in "CDEFGHIJ":
            r = Path(f"{L}:/")
            if r.exists():
                roots.append(r)
    out: List[str] = []
    seen = set()

    def consider(p: Path):
        s = str(p)
        if s not in seen and len(out) < limit:
            seen.add(s)
            out.append(s)

    for r in roots:
        try:
            for depth, base in ((0, [r]), (1, [c for c in r.iterdir() if c.is_dir() and not c.name.startswith((".", "$"))][:60])):
                for b in base:
                    for z in b.glob("*.zip"):
                        low = z.name.lower()
                        if "dragon_pilot" in low or "golden_recovery" in low or "audio_library" in low:
                            consider(z)
                    if (b / "overhead_assets_v11").is_dir():
                        consider(b)
        except (OSError, PermissionError):
            continue
    return out
