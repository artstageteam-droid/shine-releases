"""Intake (M1): аналіз завантажених ілюстрацій.

Для кожного джерела (PNG/SVG): композит на білий -> перевірка за запитом (promptgen.check) -> розрізання листа
на об'єкти (sets.split_sheet) -> по кожному об'єкту: кроп у objects/, пошук очей, план оживлення з ПРИЧИНОЮ.
Принцип fail-closed: оживлення пропонується лише там, де очі впевнено знайдені; інакше - лише малювання.
"""
import json
from pathlib import Path
from typing import Any, Dict, List

import cv2
import numpy as np

from . import paths, project

MAX_SIDE = 3000      # більші зображення зменшуємо для аналізу (оригінал не змінюється)


def _engine():
    paths.add_engine_to_path()
    import promptgen, puppet, sets
    return promptgen, puppet, sets


def load_bgr(path: Path) -> np.ndarray:
    """PNG/SVG -> BGR uint8 на білому тлі (прозорість заливається білим)."""
    if path.suffix.lower() == ".svg":
        import cairosvg
        png = cairosvg.svg2png(url=str(path), output_width=2000, unsafe=False)
        buf = np.frombuffer(png, np.uint8)
    else:
        buf = np.fromfile(str(path), np.uint8)
    im = cv2.imdecode(buf, cv2.IMREAD_UNCHANGED)
    if im is None:
        raise project.ProjectError("Не вдалося прочитати зображення")
    if im.ndim == 2:
        im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
    if im.shape[2] == 4:
        a = im[:, :, 3:4].astype(np.float32) / 255
        im = (im[:, :, :3] * a + 255 * (1 - a)).astype(np.uint8)
    s = max(im.shape[:2])
    if s > MAX_SIDE:
        k = MAX_SIDE / s
        im = cv2.resize(im, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
    return im


def count_eyes(puppet, crop) -> int:
    try:
        ps = puppet.PuppetShow(cfg=dict(seconds=1.0, limbs=False, breathe=None, bounce_end=False), fps=30)
        ps.frame(0, crop)
        return len(ps.eyes)
    except Exception:
        return 0


def plan_for(kind: str, eyes: int) -> Dict[str, Any]:
    if kind != "object":
        return dict(draw=True, blink=False, reason="Дрібна деталь: лише малювання, без оживлення.")
    if eyes >= 1:
        return dict(draw=True, blink=True, reason=f"Очі впевнено знайдено ({eyes}): моргання безпечне.")
    return dict(draw=True, blink=False, reason="Очі не розпізнано: лише малювання (оживлення вимкнено, щоб не зіпсувати вигляд).")


def analyze(pid: str) -> Dict[str, Any]:
    promptgen, puppet, sets = _engine()
    pr = project.load(pid)
    root = project.project_path(pid)
    outdir = root / "objects"
    for f in outdir.glob("*.png"):
        f.unlink()
    objects: List[Dict[str, Any]] = []
    reports: List[Dict[str, Any]] = []
    for src in pr.sources:
        entry: Dict[str, Any] = dict(source=src.id)
        try:
            img = load_bgr(root / src.file)
        except Exception as e:
            entry["error"] = str(e)
            reports.append(entry)
            continue
        entry["size"] = [int(img.shape[1]), int(img.shape[0])]
        if pr.request:
            ok, rep = promptgen.check(pr.request, img)
            entry["check"] = rep
        objs = sets.split_sheet(img)
        for i, o in enumerate(objs):
            crop, box = o.crop(img)
            oid = f"{src.id}-o{i + 1:02d}"
            rel = f"objects/{oid}.png"
            cv2.imwrite(str(root / rel), crop)
            eyes = count_eyes(puppet, crop) if o.kind == "object" else 0
            objects.append(dict(id=oid, source=src.id, file=rel, kind=o.kind, bbox=list(box), area=o.area,
                                eyes=eyes, plan=plan_for(o.kind, eyes)))
        reports.append(entry)
    pr.objects = objects
    real = [o for o in objects if o["kind"] == "object"]
    pr.plan = dict(objects=len(real), animate=sum(1 for o in real if o["plan"]["blink"]),
                   draw_only=sum(1 for o in real if not o["plan"]["blink"]))
    project.save(pr)
    (root / "analysis" / "intake.json").write_text(json.dumps(dict(reports=reports, plan=pr.plan), ensure_ascii=False, indent=1), encoding="utf-8")
    return dict(reports=reports, objects=objects, plan=pr.plan)
