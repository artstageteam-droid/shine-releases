"""Experimental ChatGPT Challenger outline planner. Opt-in; no stable behaviour changes.

It replaces only ink paths in a compatible v36 plan; original scene-owned colour
fill, hand, sound, timeline and asset ownership remain unchanged. No pixel is
silently revealed to improve metrics. The preview/reveal renderer must be tested
separately; this planner validates geometric brush coverage, not video truth.
"""
from __future__ import annotations

import math
import numpy as np
import cv2
from skimage.morphology import skeletonize

ENGINE = 'chatgpt-challenger-0.2.0-beta'


class ChallengerPlanError(RuntimeError):
    pass


def _graph_lines(mask):
    """Deterministic maximal degree-2 skeleton trails and isolated dots."""
    yy, xx = np.nonzero(skeletonize(mask.astype(bool)))
    if not len(xx):
        return []
    xy = np.column_stack((xx, yy)).astype(np.float32)
    labels = np.full(mask.shape, -1, np.int32)
    labels[yy, xx] = np.arange(len(xx))
    adj = [[] for _ in range(len(xx))]
    h, w = mask.shape
    for i, (x, y) in enumerate(xy.astype(int)):
        for dx, dy in ((1, 0), (0, 1), (1, 1), (-1, 1)):
            x2, y2 = x + dx, y + dy
            if not (0 <= x2 < w and 0 <= y2 < h) or labels[y2, x2] < 0:
                continue
            if dx and dy and ((0 <= x + dx < w and labels[y, x + dx] >= 0) or
                              (0 <= y + dy < h and labels[y + dy, x] >= 0)):
                continue
            j = int(labels[y2, x2])
            adj[i].append(j)
            adj[j].append(i)
    degrees = [len(x) for x in adj]
    used = set()
    lines = []

    def edge(a, b):
        return (a, b) if a < b else (b, a)

    def walk(a, b):
        ids = [a, b]
        used.add(edge(a, b))
        prev, cur = a, b
        while degrees[cur] == 2:
            nxt = adj[cur][0] if adj[cur][1] == prev else adj[cur][1]
            if edge(cur, nxt) in used:
                break
            used.add(edge(cur, nxt))
            ids.append(nxt)
            prev, cur = cur, nxt
        return xy[ids]

    for i, degree in enumerate(degrees):
        if degree != 2:
            for j in sorted(adj[i]):
                if edge(i, j) not in used:
                    lines.append(walk(i, j))
            if degree == 0:
                lines.append(xy[[i]])
    for i, neighbours in enumerate(adj):
        for j in sorted(neighbours):
            if edge(i, j) not in used:
                lines.append(walk(i, j))
    return lines


def _order(lines):
    """Deterministic longest-first then nearest-tip ordering; no hidden jumps."""
    if not lines:
        return []
    lengths = [float(np.linalg.norm(np.diff(a, axis=0), axis=1).sum()) if len(a) > 1 else 0.0
               for a in lines]
    remaining = set(range(len(lines)))
    ordered = []
    current = None
    while remaining:
        if current is None:
            i = max(sorted(remaining), key=lambda j: (lengths[j], -j))
        else:
            i = min(sorted(remaining), key=lambda j: (min(float(np.linalg.norm(lines[j][0] - current)),
                                                       float(np.linalg.norm(lines[j][-1] - current)))
                                                       - min(lengths[j], 150) * .08, j))
        remaining.remove(i)
        line = lines[i]
        if current is not None and len(line) > 1 and np.linalg.norm(line[-1] - current) < np.linalg.norm(line[0] - current):
            line = line[::-1].copy()
        ordered.append(line)
        current = line[-1]
    return ordered


def _footprint(shape, lines, width):
    out = np.zeros(shape, np.uint8)
    radius = max(1, int(round(width / 2)))
    for a in lines:
        q = np.rint(a).astype(np.int32).reshape(-1, 1, 2)
        if len(a) == 1:
            cv2.circle(out, tuple(q[0, 0]), radius, 255, -1, cv2.LINE_8)
        else:
            cv2.polylines(out, [q], False, 255, max(1, int(width)), cv2.LINE_8)
    return out > 0


def _ink_mask(scene):
    mask = np.zeros((scene.H, scene.W), bool)
    for i, member in enumerate(scene.members):
        if member['role'] in ('ink_rim', 'ink_stroke'):
            mask |= scene.mask(i).astype(bool)
    return mask


def build_challenger_plan(scene, baseline, *, max_side=960, minimum_coverage=.985):
    """Replace only ink strokes; preserve baseline colour semantics and all assets.

    Fails closed when underlying mask cannot be traced accurately enough.
    No automatic fallback or silent switch to the legacy engine.
    """
    if not hasattr(scene, 'ref'):
        raise ChallengerPlanError('Challenger beta supports PNG raster scenes only')
    mask_orig = _ink_mask(scene)
    if not mask_orig.any():
        raise ChallengerPlanError('No visible black outline to plan')
    legacy_ink = [s for s in baseline['strokes'] if s['kind'] == 'ink']
    if not legacy_ink:
        raise ChallengerPlanError('Legacy plan has no compatible ink phase')
    width_orig = float(np.median([s['width'] for s in legacy_ink]))
    if width_orig <= 0 or not math.isfinite(width_orig):
        raise ChallengerPlanError('Invalid baseline nib width')
    scale = min(1.0, float(max_side) / max(scene.W, scene.H))
    w = max(1, int(round(scene.W * scale)))
    h = max(1, int(round(scene.H * scale)))
    mask = cv2.resize(mask_orig.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST).astype(bool)
    width = max(2, int(round(width_orig * scale)))
    base = _order(_graph_lines(mask))
    if not base:
        raise ChallengerPlanError('Skeleton has no drawable graph')
    covered = _footprint(mask.shape, base, width)
    # Perform bounded, physical residual passes instead of a magical final reveal.
    residual = []
    for _ in range(2):
        missing = mask & ~covered
        if not missing.any():
            break
        additions = _order(_graph_lines(missing))
        if len(additions) > max(500, len(base) * 4):
            raise ChallengerPlanError('Residual too fragmented for beta; use Claude engine')
        residual.extend(additions)
        covered |= _footprint(mask.shape, additions, width)
    miss = int((mask & ~covered).sum())
    coverage = 1.0 - miss / max(1, int(mask.sum()))
    if coverage < minimum_coverage:
        raise ChallengerPlanError(f'Insufficient physical outline coverage: {coverage:.2%} < {minimum_coverage:.2%}')
    # Insert repairs near the nearest original line rather than as a late pass.
    groups = [[] for _ in base]
    for line in residual:
        mid = line[len(line) // 2]
        owner = min(range(len(base)), key=lambda j: (float(np.linalg.norm(base[j][len(base[j]) // 2] - mid)), j))
        groups[owner].append(line)
    ordered = []
    for i, line in enumerate(base):
        ordered.append((line, False))
        ordered.extend((part, True) for part in groups[i])
    ink_rgb = baseline.get('ink_rgb', legacy_ink[0]['fill'])
    outlines = [dict(kind='ink', fill=ink_rgb, width=width_orig,
                     pts=(line / np.array([w / scene.W, h / scene.H], dtype=np.float32)).astype(np.float32),
                     style='hatch', challenger_residual=residual_flag)
                for line, residual_flag in ordered]
    # Only ink changes. The established colour regions are untouched.
    strokes = outlines + [dict(s) for s in baseline['strokes'] if s['kind'] != 'ink']
    for i, s in enumerate(strokes):
        s['id'] = f"{s['kind']}_{i:04d}"
        p = np.asarray(s['pts'])
        s['length_px'] = round(float(np.linalg.norm(np.diff(p, axis=0), axis=1).sum()) if len(p) > 1 else 0.0, 1)
    # Preserve public schema expected by the timeline, renderer and preview.
    import planner as legacy_planner
    result = dict(baseline)
    result.update(strokes=strokes, chapters=legacy_planner._chapters(strokes),
                  engine=ENGINE, challenger_qa=dict(coverage=round(coverage, 6), missing_ink_pixels=miss,
                    total_ink_pixels=int(mask.sum()), primary_strokes=len(base), residual_strokes=len(residual),
                    raster=[w, h], width_px=width_orig, shared_colour_engine=True))
    return result
