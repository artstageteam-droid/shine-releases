"""Фонові задачі рендера. Рендер іде в ОКРЕМОМУ процесі (рушій) - вікно програми не підвисає, а збій рушія
не валить сервер. Прогрес береться з рядків 'PROGRESS i n' у виводі рушія. Стан пишеться в renders/<job>/job.json.
"""
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from . import packs, paths, project

_JOBS: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.Lock()
QUALITY = {"preview": dict(t_end=12.0, label="Швидкий тест (перші 12 с)"), "full": dict(t_end=None, label="Повне відео"),
           "alive_test": dict(t_end=None, label="Тест оживлення (кінець малювання + моргання)")}
ALIVE_SECONDS = 4.0
VIDEO = {   # розмір кадру, CRF (менше = краща якість), пресет x264
    "1080p": dict(size="1920x1080", crf=16, preset="medium", label="Full HD 1080p (краща якість)"),
    "720p": dict(size="1280x720", crf=18, preset="veryfast", label="HD 720p (швидше)"),
}


class JobError(ValueError):
    pass


def _save(job):
    d = Path(job["dir"])
    d.mkdir(parents=True, exist_ok=True)
    (d / "job.json").write_text(json.dumps({k: v for k, v in job.items() if k != "proc"}, ensure_ascii=False, indent=1), encoding="utf-8")


def _cmd(png: Path, out: Path, quality: str, bg: Optional[Path], alive: bool = False, video: str = "1080p", live: bool = False, emotions=None, engine: str = 'claude'):
    paths.add_engine_to_path()
    pipeline = paths.engine_dir() / "pipeline.py"
    hand = packs.hand_dir()
    cmd = [sys.executable, str(pipeline), str(png), str(out), "--assets", str(hand), "--audio", str(packs.sound_dir()),
           "--hand", "v2", "--sound", "golden"]
    v = VIDEO.get(video, VIDEO["1080p"])
    cmd += ["--size", v["size"], "--crf", str(v["crf"]), "--preset", v["preset"], "--ink-scale", "1.5"]
    if engine != 'claude':
        cmd += ['--engine', engine]
    if live:
        cmd += ["--live-blink"]
    if emotions:
        cmd += ["--emotions"] + [str(e) for e in emotions]
    if bg:
        cmd += ["--background", str(bg)]
    if alive or quality == "alive_test":
        cmd += ["--alive", str(ALIVE_SECONDS)]
        if quality == "alive_test":
            cmd += ["--alive-test"]
    te = QUALITY[quality]["t_end"]
    if te:
        cmd += ["--t-end", str(te)]
    return cmd


def preflight() -> Optional[str]:
    st = packs.status()
    if not st["hand"]:
        return "Немає набору «рука». Імпортуйте ресурси в Налаштуваннях → Ресурси."
    if not st["sound"]:
        return "Немає звуків. Імпортуйте ресурси в Налаштуваннях → Ресурси."
    if not st["ffmpeg"]:
        return "Не знайдено ffmpeg (його ставить інсталятор). Оновіть програму або перезапустіть інсталятор."
    return None


MUSIC_VOL = {"low": 0.10, "mid": 0.20}
_Q: "queue.Queue[Dict[str, Any]]" = queue.Queue()
_WORKER: Optional[threading.Thread] = None


def _ensure_worker():
    global _WORKER
    with _LOCK:
        if _WORKER is None or not _WORKER.is_alive():
            _WORKER = threading.Thread(target=_loop, daemon=True)
            _WORKER.start()


def _loop():
    while True:
        job = _Q.get()
        if job["state"] == "cancelled":
            continue
        try:
            _run_job(job)
        except Exception as e:  # noqa: BLE001
            job.update(state="error", error=str(e))
            _save(job)


def start(pid: str, object_id: str, quality: str = "preview", background: Optional[str] = None, alive: bool = False,
          video: str = "1080p", music: Optional[str] = None, music_volume: str = "low", live_blink: bool = True, emotions: bool = True, engine: str = 'claude') -> Dict[str, Any]:
    """object_id == '__all__' -> один ролик з усіх об'єктів набору (по черзі)."""
    if engine not in ('claude', 'challenger'):
        raise JobError('Невідомий рушій малювання')
    if quality not in QUALITY or video not in VIDEO or music_volume not in MUSIC_VOL:
        raise JobError("Невідома якість")
    err = preflight()
    if err:
        raise JobError(err)
    pr = project.load(pid)
    real = [o for o in pr.objects if o["kind"] == "object"]
    if object_id == "__all__":
        objs = real
        if not objs:
            raise JobError("Немає об'єктів — спершу проаналізуйте малюнок")
        if quality == "alive_test":
            raise JobError("«Тест оживлення» доступний лише для одного об'єкта")
    else:
        o = next((o for o in pr.objects if o["id"] == object_id), None)
        if o is None:
            raise JobError("Об'єкт не знайдено — спершу проаналізуйте малюнок")
        if quality == "alive_test" and not o["plan"].get("blink"):
            raise JobError("Для цього об'єкта оживлення вимкнено: очі не розпізнано впевнено.")
        objs = [o]
    root = project.project_path(pid)
    items = []
    for o in objs:
        png = (root / o["file"]).resolve()
        if root.resolve() not in png.parents or not png.is_file():
            raise JobError("Файл об'єкта не знайдено")
        items.append(dict(id=o["id"], file=o["file"], alive=bool(alive and o["plan"].get("blink")),
                          live=bool(live_blink and o["plan"].get("blink")),
                          emotions=[e["file"] for e in pr.emotions.get(o["id"], [])
                                    if (root / e["file"]).is_file()] if (emotions and quality != "alive_test") else []))   # fail-closed
    bgname = None
    if background:
        bgname = Path(background).name
        if not (packs.pack_dir() / "background" / bgname).is_file():
            raise JobError("Фон не знайдено")
    mname = None
    if music:
        mname = Path(music).name
        if not (packs.pack_dir() / "music" / mname).is_file():
            raise JobError("Музику не знайдено")
    jid = uuid.uuid4().hex[:8]
    title = items[0]["id"] if len(items) == 1 else f"набір ({len(items)})"
    out = root / "renders" / f"{time.strftime('%Y%m%d-%H%M%S')}-{quality}-{jid}"
    job = dict(id=jid, project=pid, title=title, items=items, quality=quality, engine=engine, video_q=video, background=bgname,
               music=mname, music_volume=music_volume, state="queued", progress=0.0, created=time.time(), started=None,
               dir=str(out), video=None, error=None, log=[], eta=None, part=0, parts=len(items))
    with _LOCK:
        _JOBS[jid] = job
    _save(job)
    _Q.put(job)
    _ensure_worker()
    return public(job)


def _run_one(job, item, sub: Path, base: float, share: float) -> bool:
    """Один об'єкт -> sub/SHINE_Creator_clip.mp4. Повертає True, якщо вдалося."""
    root = project.project_path(job["project"])
    png = root / item["file"]
    bg = (packs.pack_dir() / "background" / job["background"]) if job["background"] else None
    sub.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1")
    proc = subprocess.Popen(_cmd(png, sub, job["quality"], bg, item["alive"], job["video_q"], item.get("live", False), [root / f for f in item.get("emotions", [])], job.get('engine', 'claude')), stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=env, cwd=str(sub))
    job["proc"] = proc
    t0 = time.time()
    for line in proc.stdout:
        line = line.rstrip()
        m = re.match(r"PROGRESS (\d+) (\d+)", line)
        if m:
            i, n = int(m.group(1)), max(1, int(m.group(2)))
            frac = min(0.99, i / n)
            job["progress"] = min(0.99, base + share * frac)
            el = time.time() - job["started"]
            job["eta"] = round(el * (1 - job["progress"]) / max(job["progress"], 1e-3)) if el > 20 and job["progress"] > 0.01 else None
        elif line:
            job["log"] = (job["log"] + [line])[-40:]
    rc = proc.wait()
    job.pop("proc", None)
    return rc == 0 and (sub / "SHINE_Creator_clip.mp4").exists()


def _mix_music(video: Path, music: Path, vol: float, out: Path) -> None:
    packs.ensure_ffmpeg_on_path()
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", str(video), "-stream_loop", "-1", "-i", str(music), "-filter_complex",
           f"[1:a]volume={vol},afade=t=in:d=1.5[m];[0:a][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,"
           "alimiter=limit=0.95[a]", "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
           "-movflags", "+faststart", "-shortest", str(out)]
    subprocess.run(cmd, check=True, capture_output=True)


def _run_job(job):
    packs.ensure_ffmpeg_on_path()
    out = Path(job["dir"])
    job.update(state="running", started=time.time())
    _save(job)
    n = len(job["items"])
    clips = []
    try:
        for k, item in enumerate(job["items"]):
            if job["state"] == "cancelled":
                return
            job["part"] = k + 1
            sub = out / item["id"] if n > 1 else out
            ok = _run_one(job, item, sub, k / n, 1 / n)
            if job["state"] == "cancelled":
                return
            if not ok:
                job.update(state="error", error=f"Рендер не вдався на об'єкті {item['id']}. Останні рядки журналу нижче.")
                return
            clips.append(sub / "SHINE_Creator_clip.mp4")
        final = out / "SHINE_Creator_clip.mp4"
        if n > 1:
            lst = out / "concat.txt"
            lst.write_text("".join(f"file '{c.as_posix()}'\n" for c in clips), encoding="utf-8")
            final = out / "SHINE_set.mp4"
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy",
                            "-movflags", "+faststart", str(final)], check=True, capture_output=True)
        if job.get("music"):
            mixed = out / "SHINE_with_music.mp4"
            _mix_music(final, packs.pack_dir() / "music" / job["music"], MUSIC_VOL[job["music_volume"]], mixed)
            final = mixed
        job.update(state="done", progress=1.0, video=final.name, eta=0)
        qas = []
        for c in clips:
            q = c.parent / "QA.json"
            if q.exists():
                qas.append(json.loads(q.read_text()))
        if qas:
            job["qa"] = dict(duration_s=round(sum(x.get("duration_s", 0) for x in qas), 1),
                             unsafe_hand_frames=sum(x.get("unsafe_hand_frames", 0) for x in qas),
                             offscreen_visible_frames=sum(x.get("offscreen_visible_frames", 0) for x in qas))
        job["size_mb"] = round((out / job["video"]).stat().st_size / 1e6, 1)
    except subprocess.CalledProcessError as e:
        job.update(state="error", error="Не вдалося зібрати ролик (ffmpeg): " + (e.stderr or b"").decode("utf-8", "replace")[-300:])
    except Exception as e:  # noqa: BLE001
        job.update(state="error", error=str(e))
    finally:
        job.pop("proc", None)
        _save(job)


def public(job) -> Dict[str, Any]:
    return {k: v for k, v in job.items() if k not in ("proc", "dir", "items")}


def get(jid: str) -> Dict[str, Any]:
    j = _JOBS.get(jid)
    if not j:
        raise JobError("Задачу не знайдено")
    return public(j)


def cancel(jid: str) -> Dict[str, Any]:
    j = _JOBS.get(jid)
    if not j:
        raise JobError("Задачу не знайдено")
    if j["state"] in ("queued", "running"):
        p = j.get("proc")
        j["state"] = "cancelled"
        if p:
            p.terminate()
        _save(j)
    return public(j)


def list_renders(pid: str) -> list:
    """Готові ролики проєкту (читаємо з диска - переживають перезапуск програми)."""
    d = project.project_path(pid) / "renders"
    out = []
    if d.is_dir():
        for jf in sorted(d.glob("*/job.json"), reverse=True):
            try:
                j = json.loads(jf.read_text(encoding="utf-8"))
            except ValueError:
                continue
            if j.get("state") == "done" and j.get("video") and (jf.parent / j["video"]).is_file():
                out.append(dict(id=j["id"], dir=jf.parent.name, title=j.get("title"), quality=j.get("quality"),
                                video_q=j.get("video_q"), engine=j.get("engine", "claude"), created=j.get("created"), size_mb=j.get("size_mb"),
                                music=j.get("music"), duration_s=(j.get("qa") or {}).get("duration_s")))
    return out


def render_file(pid: str, dirname: str) -> Path:
    base = (project.project_path(pid) / "renders").resolve()
    jf = (base / dirname / "job.json").resolve()
    if base not in jf.parents or not jf.is_file():
        raise JobError("Ролик не знайдено")
    j = json.loads(jf.read_text(encoding="utf-8"))
    f = (jf.parent / str(j.get("video") or "")).resolve()
    if jf.parent.resolve() not in f.parents or not f.is_file():
        raise JobError("Файл відео не знайдено")
    return f


def video_path(jid: str) -> Path:
    j = _JOBS.get(jid)
    if not j or not j.get("video"):
        raise JobError("Відео ще не готове")
    p = Path(j["dir"]) / j["video"]
    if not p.is_file():
        raise JobError("Файл відео не знайдено")
    return p
