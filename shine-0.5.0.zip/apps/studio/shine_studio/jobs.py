"""Фонові задачі рендера. Рендер іде в ОКРЕМОМУ процесі (рушій) - вікно програми не підвисає, а збій рушія
не валить сервер. Прогрес береться з рядків 'PROGRESS i n' у виводі рушія. Стан пишеться в renders/<job>/job.json.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from . import packs, paths, project

_JOBS: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.Lock()
QUALITY = {"preview": dict(t_end=12.0, label="Швидкий тест (перші 12 с)"), "full": dict(t_end=None, label="Повне відео"),
           "alive_test": dict(t_end=None, label="Тест оживлення (кінець малювання + моргання)")}
ALIVE_SECONDS = 4.0
VIDEO = {   # розмір кадру, CRF (менше = краща якість), пресет x264
    "1080p": dict(size="1920x1080", crf=16, preset="medium", label="Full HD 1080p (краща якість)"),
    "720p": dict(size="1280x720", crf=18, preset="veryfast", label="HD 720p (швидше)"),
}


class JobError(ValueError):
    pass


def _save(job):
    d = Path(job["dir"])
    d.mkdir(parents=True, exist_ok=True)
    (d / "job.json").write_text(json.dumps({k: v for k, v in job.items() if k != "proc"}, ensure_ascii=False, indent=1), encoding="utf-8")


def _cmd(png: Path, out: Path, quality: str, bg: Optional[Path], alive: bool = False, video: str = "1080p"):
    paths.add_engine_to_path()
    pipeline = paths.engine_dir() / "pipeline.py"
    hand = packs.hand_dir()
    cmd = [sys.executable, str(pipeline), str(png), str(out), "--assets", str(hand), "--audio", str(packs.sound_dir()),
           "--hand", "v2", "--sound", "golden"]
    v = VIDEO.get(video, VIDEO["1080p"])
    cmd += ["--size", v["size"], "--crf", str(v["crf"]), "--preset", v["preset"], "--ink-scale", "1.5"]
    if bg:
        cmd += ["--background", str(bg)]
    if alive or quality == "alive_test":
        cmd += ["--alive", str(ALIVE_SECONDS)]
        if quality == "alive_test":
            cmd += ["--alive-test"]
    te = QUALITY[quality]["t_end"]
    if te:
        cmd += ["--t-end", str(te)]
    return cmd


def preflight() -> Optional[str]:
    st = packs.status()
    if not st["hand"]:
        return "Немає набору «рука». Імпортуйте ресурси в Налаштуваннях → Ресурси."
    if not st["sound"]:
        return "Немає звуків. Імпортуйте ресурси в Налаштуваннях → Ресурси."
    if not st["ffmpeg"]:
        return "Не знайдено ffmpeg (його ставить інсталятор). Оновіть програму або перезапустіть інсталятор."
    return None


def start(pid: str, object_id: str, quality: str = "preview", background: Optional[str] = None, alive: bool = False, video: str = "1080p") -> Dict[str, Any]:
    if quality not in QUALITY or video not in VIDEO:
        raise JobError("Невідома якість")
    err = preflight()
    if err:
        raise JobError(err)
    pr = project.load(pid)
    obj = next((o for o in pr.objects if o["id"] == object_id), None)
    if obj is None:
        raise JobError("Об'єкт не знайдено — спершу проаналізуйте малюнок")
    if (alive or quality == "alive_test") and not obj["plan"].get("blink"):
        if quality == "alive_test":
            raise JobError("Для цього об'єкта оживлення вимкнено: очі не розпізнано впевнено.")
        alive = False                                  # fail-closed: де очей немає - лише малювання
    root = project.project_path(pid)
    png = (root / obj["file"]).resolve()
    if root.resolve() not in png.parents or not png.is_file():
        raise JobError("Файл об'єкта не знайдено")
    bg = None
    if background:
        bg = packs.pack_dir() / "background" / Path(background).name
        if not bg.is_file():
            raise JobError("Фон не знайдено")
    with _LOCK:
        if any(j["state"] == "running" for j in _JOBS.values()):
            raise JobError("Вже йде інший рендер. Дочекайтесь завершення.")
        jid = uuid.uuid4().hex[:8]
        out = root / "renders" / f"{object_id}-{quality}-{jid}"
        job = dict(id=jid, project=pid, object=object_id, quality=quality, alive=alive, video_q=video, state="running", progress=0.0, started=time.time(),
                   dir=str(out), video=None, error=None, log=[], eta=None)
        _JOBS[jid] = job
    _save(job)
    threading.Thread(target=_run, args=(job, png, out, bg, quality, alive, video), daemon=True).start()
    return public(job)


def _run(job, png, out, bg, quality, alive=False, video="1080p"):
    packs.ensure_ffmpeg_on_path()
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1")
    try:
        out.mkdir(parents=True, exist_ok=True)
        proc = subprocess.Popen(_cmd(png, out, quality, bg, alive, video), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                encoding="utf-8", errors="replace", env=env, cwd=str(out))
        job["proc"] = proc
        for line in proc.stdout:
            line = line.rstrip()
            m = re.match(r"PROGRESS (\d+) (\d+)", line)
            if m:
                i, n = int(m.group(1)), max(1, int(m.group(2)))
                job["progress"] = min(0.99, i / n)
                el = time.time() - job["started"]
                job["eta"] = round(el / max(i, 1) * (n - i)) if i > 30 else None
            elif line:
                job["log"] = (job["log"] + [line])[-40:]
        rc = proc.wait()
        if job["state"] == "cancelled":
            return
        mp4 = out / "SHINE_Creator_clip.mp4"
        if rc == 0 and mp4.exists():
            job.update(state="done", progress=1.0, video=mp4.name, eta=0)
            qa = out / "QA.json"
            if qa.exists():
                job["qa"] = {k: v for k, v in json.loads(qa.read_text()).items()
                             if k in ("duration_s", "unsafe_hand_frames", "offscreen_visible_frames", "tip_anchor_error_max_px",
                                      "final_vs_reference_gt40_ratio")}
        else:
            job.update(state="error", error="Рендер не вдався (код %s). Останні рядки журналу нижче." % rc)
    except Exception as e:  # noqa: BLE001
        job.update(state="error", error=str(e))
    finally:
        job.pop("proc", None)
        _save(job)


def public(job) -> Dict[str, Any]:
    return {k: v for k, v in job.items() if k not in ("proc", "dir")}


def get(jid: str) -> Dict[str, Any]:
    j = _JOBS.get(jid)
    if not j:
        raise JobError("Задачу не знайдено")
    return public(j)


def cancel(jid: str) -> Dict[str, Any]:
    j = _JOBS.get(jid)
    if not j:
        raise JobError("Задачу не знайдено")
    p = j.get("proc")
    if p and j["state"] == "running":
        j["state"] = "cancelled"
        p.terminate()
    return public(j)


def video_path(jid: str) -> Path:
    j = _JOBS.get(jid)
    if not j or not j.get("video"):
        raise JobError("Відео ще не готове")
    p = Path(j["dir"]) / j["video"]
    if not p.is_file():
        raise JobError("Файл відео не знайдено")
    return p
