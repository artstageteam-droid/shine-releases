#!/usr/bin/env python3
"""Hand v2 - поверх Golden Actor (той самий фотографічний спрайт, та сама калібровка наконечника).

Що додано (кожне перевіряється A/B-кадрами, Golden лишається запасним варіантом: hand_kind='golden'):
  * м'яка тінь руки/маркера на папері (розмиття + зсув; при підйомі тінь віддаляється, блідне й розмивається);
  * другий порядок інерції повороту навколо наконечника (пружина-демпфер): рука «слідує» за траєкторією, а не
    миттєво розвертається; наконечник завжди рівно на кінчику штриха;
  * мікрорух зап'ястя (повільні несинхронні коливання < 0.5 град) і ледь помітне «дихання» підйому;
  * вибір пози по розділах: 4 оригінальні фото-пози; перемикання ЛИШЕ під час заміни маркера (рука поза кадром),
    щоб не було «примарного» перехресного розмивання; кожна пара поза+траєкторія перевіряється на безпеку країв.
"""
import json
import math
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from render import tint_marker, premul

POSES = ['overhead_right_alt', 'overhead_right', 'overhead_high', 'overhead_bottomright']


class HandV2:
    def __init__(self, asset_dir, W, H, shadow=True, inertia=True, tremor=True, hand_scale=0.34):
        self.W, self.H, self.S = W, H, W / 800.0
        self.src_scale = hand_scale * self.S                 # масштаб спрайта відносно оригіналу
        self.scale = 1.0                                       # спрайти вже зменшені (INTER_AREA) - тут лише поворот
        meta = {a['id']: a for a in json.loads((Path(asset_dir) / 'assets.json').read_text())['actors']}
        self.img, self.nib, self.edge = {}, {}, {}
        for pid in POSES:
            if pid not in meta:
                continue
            a = meta[pid]
            im = Image.open(Path(asset_dir).parent / a['file']).convert('RGBA')
            im, nib = self._prep(im, tuple(a['nib_px']))
            self.img[pid], self.nib[pid] = im, nib
            m = np.asarray(im)[:, :, 3] > 125
            b = np.zeros_like(m)
            b[:2, :] = b[-2:, :] = True
            b[:, :2] = b[:, -2:] = True
            yy, xx = np.where(b & m)
            self.edge[pid] = np.column_stack((xx, yy)).astype(np.float32)
        self.cache = {}
        self.shadow, self.inertia, self.tremor = shadow, inertia, tremor
        self.theta = 0.0
        self.omega = 0.0
        self.sh_cache = {}

    def _prep(self, im, nib):
        """чистий край: легка ерозія + нормована згортка кольору (без світлої облямівки), зменшення INTER_AREA"""
        a = np.asarray(im).astype(np.float32)
        al = a[:, :, 3] / 255.0
        hard = (al > 0.5).astype(np.uint8)
        inner = cv2.erode(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))).astype(np.float32)
        num = cv2.GaussianBlur(a[:, :, :3] * inner[:, :, None], (0, 0), 4.0)
        den = cv2.GaussianBlur(inner, (0, 0), 4.0)[:, :, None]
        bleed = num / np.maximum(den, 1e-4)
        edge = (inner < 1.0)[:, :, None]
        rgb = np.where(edge & (den > 1e-3), bleed, a[:, :, :3])
        alpha = cv2.GaussianBlur(cv2.erode(hard, np.ones((3, 3), np.uint8)).astype(np.float32), (0, 0), 1.6)
        out = np.dstack([rgb, alpha * 255.0]).clip(0, 255).astype(np.uint8)
        # продовження рукава за межі спрайта (реплікація краю): рука завжди «йде» за край кадру, а не обривається в ньому
        pad = 900
        out = cv2.copyMakeBorder(out, pad, pad, pad, pad, cv2.BORDER_REPLICATE)
        nib = (nib[0] + pad, nib[1] + pad)
        k = self.src_scale
        w, h = int(round(out.shape[1] * k)), int(round(out.shape[0] * k))
        small = cv2.resize(out, (w, h), interpolation=cv2.INTER_AREA)
        return Image.fromarray(small, 'RGBA'), (nib[0] * k, nib[1] * k)

    # --- спрайти ---------------------------------------------------------------------------------
    def variant(self, pid, color, tinted):
        key = (pid, color if tinted else None)
        if key not in self.cache:
            im = self.img[pid]
            if tinted:
                r, g, b = (int(x) for x in color[4:-1].split(','))
                im = tint_marker(im, self.nib[pid], (r, g, b), tip_r=16.0 * self.src_scale)
            self.cache[key] = premul(im)
        return self.cache[key]

    def edge_inside(self, pid, tip, ang, lift):
        nib = self.nib[pid]
        a = math.radians(ang)
        c, s = self.scale * math.cos(a), self.scale * math.sin(a)
        e = self.edge[pid]
        xx = tip[0] + c * (e[:, 0] - nib[0]) - s * (e[:, 1] - nib[1])
        yy = tip[1] + s * (e[:, 0] - nib[0]) + c * (e[:, 1] - nib[1]) - lift
        return int(np.count_nonzero((xx > 4) & (xx < self.W - 4) & (yy > 4) & (yy < self.H - 4)))

    def visible_anywhere(self, pid, color, tinted, tip, ang, lift):
        alpha = self.variant(pid, color, tinted)[:, :, 3]
        ys, xs = np.where(alpha[::20, ::20] > 160)
        if len(xs) == 0:
            return False
        x, y = xs * 20., ys * 20.
        nib = self.nib[pid]
        a = math.radians(ang)
        c, s = self.scale * math.cos(a), self.scale * math.sin(a)
        xx = tip[0] + c * (x - nib[0]) - s * (y - nib[1])
        yy = tip[1] + s * (x - nib[0]) + c * (y - nib[1]) - lift
        return bool(np.any((xx >= 0) & (xx < self.W) & (yy >= 0) & (yy < self.H)))

    # --- вибір пози для розділу (безпека країв уздовж усіх штрихів розділу) ---------------------------
    def safe_for(self, pid, pts, worst_ang=4.5, lift=12.0):
        if pid not in self.img:
            return False
        p = np.asarray(pts, float)
        sample = p[::max(1, len(p) // 60)]
        for ang in (-worst_ang, 0.0, worst_ang):
            for tip in sample:
                if self.edge_inside(pid, tip, ang, 0.0) or self.edge_inside(pid, tip, ang, lift * self.S):
                    return False
        return True

    # --- динаміка повороту ----------------------------------------------------------------------------
    def step(self, target, dt, t, contact):
        if self.inertia:
            k, zeta = (2 * math.pi * 2.4) ** 2, 0.8
            acc = k * (target - self.theta) - 2 * zeta * math.sqrt(k) * self.omega
            self.omega += acc * dt
            self.omega = float(np.clip(self.omega, -35, 35))              # град/с
            self.theta += self.omega * dt
        else:
            self.theta += float(np.clip((1 - math.exp(-dt / .135)) * (target - self.theta), -.2, .2))
        self.theta = float(np.clip(self.theta, -5.0, 5.0))
        wob = 0.0
        if self.tremor:
            wob = 0.26 * math.sin(2 * math.pi * 0.61 * t + 0.7) + 0.17 * math.sin(2 * math.pi * 1.37 * t + 2.1)
        return self.theta + wob

    # --- малювання ------------------------------------------------------------------------------------
    def draw(self, frame, pid, color, tinted, tip, ang, lift, t=0.0, contact=True):
        nib = self.nib[pid]
        ra = math.radians(ang)
        c, s = self.scale * math.cos(ra), self.scale * math.sin(ra)
        jit = 0.0 if contact or not self.tremor else 0.7 * self.S * math.sin(2 * math.pi * 1.9 * t)
        tx = tip[0] - c * nib[0] + s * nib[1]
        ty = tip[1] - s * nib[0] - c * nib[1] - lift - jit
        M = np.asarray([[c, -s, tx], [s, c, ty]], np.float32)
        spr = self.variant(pid, color, tinted)
        sh, sw = spr.shape[:2]
        L = max(0.0, lift) / self.S
        sig = (6.0 + 0.30 * L) * self.S
        dxs, dys = (7 + 0.55 * L) * self.S, (10 + 0.9 * L) * self.S
        # ROI: рамка спрайта (+ тінь) - усе рахуємо лише в ній, а не на всьому кадрі (у 1080p це ~5x швидше, піксель-у-піксель те саме)
        cs = np.float32([[0, 0, 1], [sw, 0, 1], [0, sh, 1], [sw, sh, 1]]) @ M.T
        m = int(3 * sig + 3) if self.shadow else 2
        x0 = max(0, int(math.floor(cs[:, 0].min())) - m)
        y0 = max(0, int(math.floor(cs[:, 1].min())) - m)
        x1 = min(self.W, int(math.ceil(cs[:, 0].max() + dxs)) + m)
        y1 = min(self.H, int(math.ceil(cs[:, 1].max() + dys)) + m)
        if x1 > x0 and y1 > y0:
            Mr = M.copy()
            Mr[0, 2] -= x0
            Mr[1, 2] -= y0
            rw, rh = x1 - x0, y1 - y0
            fg = cv2.warpAffine(spr, Mr, (rw, rh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
            alpha = fg[:, :, 3:4].astype(np.float32) / 255.
            roi = frame[y0:y1, x0:x1].astype(np.float32)
            if self.shadow:
                off = np.float32([[1, 0, dxs], [0, 1, dys]])
                a2 = cv2.warpAffine(alpha[:, :, 0], off, (rw, rh), flags=cv2.INTER_LINEAR)
                if sig > 5:                                   # м'яка тінь: розмиваємо на половинній роздільності (4x швидше)
                    sm = cv2.resize(a2, (max(1, rw // 2), max(1, rh // 2)), interpolation=cv2.INTER_AREA)
                    sm = cv2.GaussianBlur(sm, (0, 0), sig / 2)
                    a2 = cv2.resize(sm, (rw, rh), interpolation=cv2.INTER_LINEAR)
                else:
                    a2 = cv2.GaussianBlur(a2, (0, 0), sig)
                op = 0.26 * (1.0 - min(0.6, L / 30.0))
                roi = roi * (1.0 - op * a2[:, :, None])
                roi = np.clip(roi, 0, 255).astype(np.uint8).astype(np.float32)
            frame[y0:y1, x0:x1] = np.uint8(np.clip(fg[:, :, :3].astype(np.float32) + roi * (1 - alpha), 0, 255))
        return math.hypot(c * nib[0] - s * nib[1] + tx - tip[0], s * nib[0] + c * nib[1] + ty + lift + jit - tip[1])
